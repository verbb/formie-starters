-- MySQL dump 10.13  Distrib 8.0.46, for Linux (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `administrativeArea` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `locality` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dependentLocality` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `postalCode` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sortingCode` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `addressLine1` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `addressLine2` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `addressLine3` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organization` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationTaxId` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `fullName` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `latitude` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_hduofbqigtgixptwacdcgtboerkiiqqmbuzm` (`primaryOwnerId`),
  CONSTRAINT `fk_hduofbqigtgixptwacdcgtboerkiiqqmbuzm` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zbehkdmlpfctmpplijdmfwiqdaxiglxqrleh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sbpsekvzzkhoxebravsqenywtzrgaaeewzkr` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_wfwcdxlotvaucrzfbfpgfklrfiimnzdffsbo` (`dateRead`),
  KEY `fk_owxukpfpglersvzkdczlvrozlipgxtabmbqc` (`pluginId`),
  CONSTRAINT `fk_emwazptwmeqfymmphoqbrlcszfunpqogxfgs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_owxukpfpglersvzkdczlvrozlipgxtabmbqc` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text COLLATE utf8mb4_unicode_520_ci,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yctyprajwtbveyaorcicodxpsbaourzrdpwq` (`sessionId`,`volumeId`),
  KEY `idx_xchbnucsqecasebjymhmungxsiakyhuhglxx` (`volumeId`),
  CONSTRAINT `fk_jjjirndumxbyywsvomcqclfydxogbjmqjjqs` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oiukwmxjulzbevyoiqrbhkealujbdnxlbhhz` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text COLLATE utf8mb4_unicode_520_ci,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `mimeType` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `kind` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'unknown',
  `alt` text COLLATE utf8mb4_unicode_520_ci,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hgemtliewtyrgbdbmphpeqrcqlwcfzknylmo` (`filename`,`folderId`),
  KEY `idx_smurhzoatlifgjphbcroqmttrdwpouegmkiq` (`folderId`),
  KEY `idx_merdnwhjkrxnboknfziibjqlrmassnotnssp` (`volumeId`),
  KEY `fk_yhzjstepnxlkhrfthecgsrrualnszfeaojwm` (`uploaderId`),
  CONSTRAINT `fk_bcbuhrmsrrlcotqskoqpdqqimgepkdaudxxs` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pkgnqttsmtygvjdcmkrfztvooefiqqwqfkmi` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xkxwebjgyrsudjhdtcukqysccitjbidpmiyd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yhzjstepnxlkhrfthecgsrrualnszfeaojwm` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_vnddklcsykqxzccbqtmpicppkqadqsvewpxq` (`siteId`),
  CONSTRAINT `fk_lfnsnuabehrphwqbehhgrkbbzygqemblvzkw` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vnddklcsykqxzccbqtmpicppkqadqsvewpxq` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_oauth_tokens`
--

DROP TABLE IF EXISTS `auth_oauth_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_oauth_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ownerHandle` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `providerType` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tokenType` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accessToken` text COLLATE utf8mb4_unicode_520_ci,
  `secret` text COLLATE utf8mb4_unicode_520_ci,
  `expires` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `refreshToken` text COLLATE utf8mb4_unicode_520_ci,
  `resourceOwnerId` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `values` text COLLATE utf8mb4_unicode_520_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_oauth_tokens`
--

LOCK TABLES `auth_oauth_tokens` WRITE;
/*!40000 ALTER TABLE `auth_oauth_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_oauth_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_saijcqbcrtuajzbfexiibfbjurqdjzfbbgpg` (`userId`),
  CONSTRAINT `fk_saijcqbcrtuajzbfexiibfbjurqdjzfbbgpg` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bulkopevents`
--

DROP TABLE IF EXISTS `bulkopevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulkopevents` (
  `key` char(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `senderClass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `eventName` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`key`,`senderClass`,`eventName`),
  KEY `idx_fccagdosvibrkmarsstkldrgvhuvnbikehre` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulkopevents`
--

LOCK TABLES `bulkopevents` WRITE;
/*!40000 ALTER TABLE `bulkopevents` DISABLE KEYS */;
/*!40000 ALTER TABLE `bulkopevents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gjrzpeliayfaoapjhgdcyvtzzwhzxqzpvtgb` (`groupId`),
  KEY `fk_nucpkrbmieesrtedzccmkbpiduxhfxokqvom` (`parentId`),
  CONSTRAINT `fk_jkecjqhnnceqcrdgwrcljywbjrwsilztdltu` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nucpkrbmieesrtedzccmkbpiduxhfxokqvom` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wgullbdyqzvckucxwvpexpisasdrhknajdqd` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `defaultPlacement` enum('beginning','end') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nmvkqjamksyziwmuiznhszrpplxzqmjroaqa` (`name`),
  KEY `idx_nyfqkykwdupwemliiylenlxzlmqidcmpcxeo` (`handle`),
  KEY `idx_plgnvmjvhcsnzglxpdxjycpnwglwirwnlctr` (`structureId`),
  KEY `idx_urrfvezmwzeawqgdxtbracceszrgqsjtuklk` (`fieldLayoutId`),
  KEY `idx_xlckgrentcjoswzxvkkjbahlztsqyibmxaqm` (`dateDeleted`),
  CONSTRAINT `fk_rgujvhzpdjobzamkxjemlacxtbpgzsohvteu` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ukkbqttyyijaqrvrccuvdoqfrbbvutismuyh` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text COLLATE utf8mb4_unicode_520_ci,
  `template` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qbxtwgwbutykvduydjibfcfiguyscsjuohrw` (`groupId`,`siteId`),
  KEY `idx_cuxzvlugmrdanlbhiwecrwoqtdurafumnmwt` (`siteId`),
  CONSTRAINT `fk_euplaeeauleyedqumivnttwrdczklzvuzvju` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tgxoinocqkeyvkfpqrobyeoyncximtpfxgyl` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_tuykcrvmvynjboxwvksfgrnbomzpnuhoypgp` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_tkpjsqehhhpzdixsnbsbbgiowqatvrufueut` (`siteId`),
  KEY `fk_jrdciayuvqttemshbmmysfffavmgohqaasaz` (`userId`),
  CONSTRAINT `fk_jrdciayuvqttemshbmmysfffavmgohqaasaz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tkpjsqehhhpzdixsnbsbbgiowqatvrufueut` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zhqmpazjugcpvpeiqmhtgekrbzyiiylowifb` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_yruvyogbjhaajzhpbglyclmrommerkeezzxg` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_owqjljauxodimtgnvujbyzrrmaxollrjjzzx` (`siteId`),
  KEY `fk_dtygmwbugypfylxkdqxzruuyaddykvdztiee` (`fieldId`),
  KEY `fk_aadsexvfxzgelhfyllxgqgpzhmjklnxtqipt` (`userId`),
  CONSTRAINT `fk_aadsexvfxzgelhfyllxgqgpzhmjklnxtqipt` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_dtygmwbugypfylxkdqxzruuyaddykvdztiee` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_owqjljauxodimtgnvujbyzrrmaxollrjjzzx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_phnkbmasdfghxldkchjorfqrfyiixwxmkzbd` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contentblocks`
--

DROP TABLE IF EXISTS `contentblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contentblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ovpnlnxlidgnsleqqbxkxiksrqbxikxmhaki` (`primaryOwnerId`),
  KEY `idx_agxbroeqmmrabnubmnctppfbesljprlqgefy` (`fieldId`),
  CONSTRAINT `fk_opzglahocaitujaaxxnfuuoffltgeilrmfcq` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uocuzbnvlymflzthvnzkozfwfhquhhffaniq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vholckhetxwfjukgepxbcrxuelgtpzweiszl` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contentblocks`
--

LOCK TABLES `contentblocks` WRITE;
/*!40000 ALTER TABLE `contentblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `contentblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_gblbmonejxuvlfyrfrlgzbuyasihjvtelijw` (`userId`),
  CONSTRAINT `fk_gblbmonejxuvlfyrfrlgzbuyasihjvtelijw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `fingerprint` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ocxuonzvfxonqebcldzmdifmzraslrhiocay` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_520_ci,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_xfyeectqjpxmhdwzutjmgstoxqfwtdasbexn` (`creatorId`,`provisional`),
  KEY `idx_hsoqhowybnhjxhvrcjcvvtovabbesedjffqw` (`saved`),
  KEY `fk_vvkddqiwohapmrqydbbccssnsssjffcszaiy` (`canonicalId`),
  CONSTRAINT `fk_gspnuovpurefzszbwmnhshnywkyzgsuvjwpl` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vvkddqiwohapmrqydbbccssnsssjffcszaiy` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_ottudzoenaaqaskiqnscsuakpfvyrcwbgmdb` (`elementId`,`timestamp`,`userId`),
  KEY `fk_ceomxahihwogvczimzugjtvnolghggatycud` (`userId`),
  KEY `fk_zkirdcdlfpgcyphxtefeartyszmpkkqvczcj` (`siteId`),
  KEY `fk_kmsgyujgivlrrrriofjismtwyjcjklpwmmlh` (`draftId`),
  CONSTRAINT `fk_ceomxahihwogvczimzugjtvnolghggatycud` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ymbasysgsbggrftqvruibfkdccziqlaxgyhd` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zkirdcdlfpgcyphxtefeartyszmpkkqvczcj` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_umzeemcyzkdzunnkrfsijyjqkyzkjadaljhs` (`dateDeleted`),
  KEY `idx_uuifmxvayxpnrfgjtjfpegcqzcrognbetche` (`fieldLayoutId`),
  KEY `idx_qofelegnumyqqnownafjpimbmifieupsmfzh` (`type`),
  KEY `idx_jqlisafdzvkwzlhoeomtxelbibuymktfbhor` (`enabled`),
  KEY `idx_nupktupwvgemuqessxwsabofceotrhaaxedc` (`canonicalId`),
  KEY `idx_rkluajbwvbwbdooqvlfsnduphamjukmgmjkj` (`archived`,`dateCreated`),
  KEY `idx_okmvmkefdjprfaewsyvauyylldwjmbzntsvv` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_iysdbievxfnwfgyhcxsifcahnkdqfggepljj` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_dtjsbzeyyvmjdhmlpgvlhkwzfiirezusyqzy` (`draftId`),
  KEY `fk_kddtzqmgvdmbcwpgfojwtlvezplwccdmifft` (`revisionId`),
  CONSTRAINT `fk_dtjsbzeyyvmjdhmlpgvlhkwzfiirezusyqzy` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dwbwrumkbuznldgssrpiqteoeyrhjhulnsza` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_kddtzqmgvdmbcwpgfojwtlvezplwccdmifft` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_miotmsyhfhlnfflnenzirlfnyygfupttjxiw` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2026-06-02 11:28:30','2026-06-02 11:28:30',NULL,NULL,NULL,'6fda2a1e-401c-41ec-b5ad-422d87e9b800'),(2,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Form',1,0,'2026-06-02 11:29:10','2026-06-02 11:29:10',NULL,NULL,NULL,'12aa6eec-c901-4699-80f9-e6f413beaead'),(3,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Form',1,0,'2026-06-02 11:29:10','2026-06-02 11:29:10',NULL,NULL,NULL,'b1b429a8-08c1-426c-9f3a-8b2aa1104d7b'),(4,NULL,NULL,NULL,NULL,'verbb\\formie\\elements\\Form',1,0,'2026-06-02 11:29:10','2026-06-02 11:29:10',NULL,NULL,NULL,'0b73e4e4-56ec-4c3b-b12e-cc8d3cc46d9f');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_zbylmajqutrfwtypmpsbvbbkxzpxiaklrkwf` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `idx_asexuyvuzntwhtgnielrtddnxosbiimcvtsq` (`sortOrder`),
  KEY `fk_nhyywoiysgtxqsiwkrulzsxnquofpnalavzg` (`ownerId`),
  CONSTRAINT `fk_nhyywoiysgtxqsiwkrulzsxnquofpnalavzg` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_suzksbltabegjqmqvcrkgeisqlehyvauakrg` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ijepszwcchqhmbsxunfovwsgeulsxeezekfe` (`elementId`,`siteId`),
  KEY `idx_klzoayrorrjonljnfdodwtazjpkblycphbqp` (`siteId`),
  KEY `idx_zspoalsijhiwvztgnvpyegzdakmhupvnveok` (`title`,`siteId`),
  KEY `idx_tnieejmhthqpfgatcamrlmhkpzxwgrqgypwr` (`slug`,`siteId`),
  KEY `idx_ncmztbdvatpuxjxptcwxxmrgxblrfpopfxeq` (`enabled`),
  KEY `idx_gjqmquqrosmitwdfnrlcyiqiblellrcjuhra` (`uri`,`siteId`),
  CONSTRAINT `fk_icfmlcobixkqrwykmnwpgknbsjufhcyuybsm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tmryxdelvdpemnkamupsojgwypytbswwnygw` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2026-06-02 11:28:30','2026-06-02 11:28:30','52b31cef-14c0-4d8b-8a9d-91c9258901d5'),(2,2,1,'Single Page',NULL,NULL,NULL,1,'2026-06-02 11:29:10','2026-06-02 11:29:10','c7ce6920-be76-484e-8681-78311db5c835'),(3,3,1,'Multi Page',NULL,NULL,NULL,1,'2026-06-02 11:29:10','2026-06-02 11:29:10','586e9548-59c6-4f2d-b029-b676f89dc5fe'),(4,4,1,'Advanced',NULL,NULL,NULL,1,'2026-06-02 11:29:10','2026-06-02 11:29:10','5de7109f-1dae-4f7f-ab5e-b6bbcdc2d727');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `status` enum('live','pending','expired') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'live',
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `deletedWithSection` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_nyqmhangwdcekshrjjgcykxtclgtbqthlbhi` (`postDate`),
  KEY `idx_vfcnskzmnoqaoihspymocvmgeozrhactarbl` (`expiryDate`),
  KEY `idx_wbxwobkiwutklvcziedyvfdrkvdejdkghmlv` (`status`),
  KEY `idx_cycchwlxzdnijmjkqyqvaerhoeeckbmizqrn` (`sectionId`),
  KEY `idx_lvvtcmfyoxmsirhpvaewdfjnbiivdwxztihl` (`typeId`),
  KEY `idx_yxdactxvhwwxfrguecmafekrpcfqfnshjkxx` (`primaryOwnerId`),
  KEY `idx_nicmivhilkchtwlokqhqofdiqcnesspzehpv` (`fieldId`),
  KEY `fk_osejwgezkxpxhrhzeaolvkgifsqphmnagbbn` (`parentId`),
  CONSTRAINT `fk_ggcdkvhjfezglqdubdfkxbfciiytkbmshluk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jaxvqvnlnzzxnhopkgklmtrrgusjqojquxpo` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lsebsbahbkjcazmyootfobgpauqbbgtatjen` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_osejwgezkxpxhrhzeaolvkgifsqphmnagbbn` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_txjwqazzikrhqmakxpfbntuyirrlzqexhylv` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uohnrkouswsgmidtwzyljiurgsofxyeblcnw` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_hnwmbdfyxxvxgqiigaydzfygmyfuzgoiyjxv` (`authorId`),
  KEY `idx_ndghypkceuctdmicawlqwakbukyjvgomhkjw` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_bojsvrsapfqoyacascfyjrpbidxekmvkhjla` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nsqqpqerqqrzeeqzjabaoozowmnqwfnheolk` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci,
  `icon` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `uiLabelFormat` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '{title}',
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text COLLATE utf8mb4_unicode_520_ci,
  `titleFormat` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `allowLineBreaksInTitles` tinyint(1) NOT NULL DEFAULT '0',
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text COLLATE utf8mb4_unicode_520_ci,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_idxqtbfeduyvzhtuznjsudlncjqhsrjdqonq` (`fieldLayoutId`),
  KEY `idx_pkwiilqpiigbprfvocfvdpgjtzjtkmfxzfgy` (`dateDeleted`),
  CONSTRAINT `fk_mlxdrvllxkmihezelcxidpkmlgzafcpdvtvv` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zcogssxfmifsjiwkfbehwlqphredkxvancbl` (`dateDeleted`),
  KEY `idx_wfuyeeetdtnwudvusjtdoxukuxgaxitaetev` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `instructions` text COLLATE utf8mb4_unicode_520_ci,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'none',
  `translationKeyFormat` text COLLATE utf8mb4_unicode_520_ci,
  `type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `settings` text COLLATE utf8mb4_unicode_520_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_atnrhxlumxffjqdktaindhcbcoymwyknsgmv` (`handle`,`context`),
  KEY `idx_iuxvevsswekqwafxnurxxroedmwtuamaztqg` (`context`),
  KEY `idx_rmwkpznxqhbsuqgvcwhnknbhtcicgshtsmqu` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_captcha_providers`
--

DROP TABLE IF EXISTS `formie_captcha_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_captcha_providers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(64) NOT NULL,
  `type` varchar(255) NOT NULL,
  `scope` varchar(16) NOT NULL DEFAULT 'project',
  `enabled` varchar(255) NOT NULL DEFAULT 'false',
  `saveSpam` tinyint(1) DEFAULT NULL,
  `settings` mediumtext,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qjqlcakavumycjrfhdbwfdyncwenntkwrfkb` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_captcha_providers`
--

LOCK TABLES `formie_captcha_providers` WRITE;
/*!40000 ALTER TABLE `formie_captcha_providers` DISABLE KEYS */;
INSERT INTO `formie_captcha_providers` VALUES (1,'akismet','verbb\\formie\\integrations\\captchas\\Akismet','project','false',NULL,'[]','2026-10-13 20:13:11','2026-10-13 20:13:11','46bc4400-2cc3-41c3-aa44-2fcde74e6487'),(2,'captchaEu','verbb\\formie\\integrations\\captchas\\CaptchaEu','project','false',NULL,'[]','2026-10-13 20:13:11','2026-10-13 20:13:11','07a55090-07f9-4a4c-a442-5de88bced592'),(3,'cleantalk','verbb\\formie\\integrations\\captchas\\CleanTalk','project','false',NULL,'[]','2026-10-13 20:13:11','2026-10-13 20:13:11','d6e8da06-ba4b-4be2-8bbd-7199dfe4101f'),(4,'turnstile','verbb\\formie\\integrations\\captchas\\Turnstile','project','false',NULL,'[]','2026-10-13 20:13:11','2026-10-13 20:13:11','71e16fcd-2732-4819-854b-952f1593c58c'),(5,'friendlyCaptcha','verbb\\formie\\integrations\\captchas\\FriendlyCaptcha','project','false',NULL,'[]','2026-10-13 20:13:11','2026-10-13 20:13:11','f6345ef9-1a63-4e4d-a96b-aaec2c9c89a7'),(6,'hcaptcha','verbb\\formie\\integrations\\captchas\\Hcaptcha','project','false',NULL,'[]','2026-10-13 20:13:11','2026-10-13 20:13:11','ea246d3b-8599-4ec2-8c0d-8f7c451fc0df'),(7,'OopSpam','verbb\\formie\\integrations\\captchas\\OopSpam','project','false',NULL,'[]','2026-10-13 20:13:11','2026-10-13 20:13:11','0ac86aef-3256-4ce8-86af-967c725d3571'),(8,'question','verbb\\formie\\integrations\\captchas\\Question','project','false',NULL,'[]','2026-10-13 20:13:11','2026-10-13 20:13:11','2a79ae05-6bfc-444f-90a2-665946fb68c1'),(9,'recaptcha','verbb\\formie\\integrations\\captchas\\Recaptcha','project','false',NULL,'[]','2026-10-13 20:13:11','2026-10-13 20:13:11','1d19e1ee-e5c6-462d-ae8a-2839ffb2b062');
/*!40000 ALTER TABLE `formie_captcha_providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_delivery_attempts`
--

DROP TABLE IF EXISTS `formie_delivery_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_delivery_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` char(36) NOT NULL DEFAULT '0',
  `identity` varchar(64) NOT NULL,
  `submissionId` int NOT NULL,
  `formId` int NOT NULL,
  `binding` varchar(255) NOT NULL,
  `step` varchar(255) NOT NULL,
  `parentUid` varchar(36) DEFAULT NULL,
  `executionUid` varchar(255) NOT NULL,
  `execution` varchar(16) NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'pending',
  `payloadHash` varchar(64) DEFAULT NULL,
  `requestKey` char(36) NOT NULL DEFAULT '0',
  `result` text,
  `data` mediumtext,
  `response` mediumtext,
  `startedAt` datetime DEFAULT NULL,
  `completedAt` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bxrbcqgtjbbrmusfydutgiefgngrtraddmoh` (`uid`),
  UNIQUE KEY `idx_iovgkcdmbfeymbhtgzkjwfqxssynewcxeqyg` (`identity`),
  KEY `idx_basoyfxikvjedygshzfadexfyivocnoobtnf` (`submissionId`,`executionUid`),
  KEY `idx_cpyzndemaxprmejrcxnnjblavkeyvuefikbq` (`parentUid`),
  CONSTRAINT `fk_mdoxtulvbkfudavxpqdgduswnwwhncjdolei` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_delivery_attempts`
--

LOCK TABLES `formie_delivery_attempts` WRITE;
/*!40000 ALTER TABLE `formie_delivery_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_delivery_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_delivery_diagnostics`
--

DROP TABLE IF EXISTS `formie_delivery_diagnostics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_delivery_diagnostics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `attemptId` int NOT NULL,
  `checkpoint` varchar(64) NOT NULL,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_byluoywwcumvkdyzoesplnrwhwtacivtrrhi` (`attemptId`,`id`),
  CONSTRAINT `fk_qazkwmkggxqsunfzcfmavtxbkqqtnbmexsmu` FOREIGN KEY (`attemptId`) REFERENCES `formie_delivery_attempts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_delivery_diagnostics`
--

LOCK TABLES `formie_delivery_diagnostics` WRITE;
/*!40000 ALTER TABLE `formie_delivery_diagnostics` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_delivery_diagnostics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_emailtemplates`
--

DROP TABLE IF EXISTS `formie_emailtemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_emailtemplates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `template` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_emailtemplates`
--

LOCK TABLES `formie_emailtemplates` WRITE;
/*!40000 ALTER TABLE `formie_emailtemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_emailtemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_encryption_settings`
--

DROP TABLE IF EXISTS `formie_encryption_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_encryption_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contentVersion` smallint NOT NULL DEFAULT '1',
  `expectedKeyId` varchar(18) DEFAULT NULL,
  `reencryptCursor` int DEFAULT NULL,
  `reencryptTargetKeyId` varchar(18) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_encryption_settings`
--

LOCK TABLES `formie_encryption_settings` WRITE;
/*!40000 ALTER TABLE `formie_encryption_settings` DISABLE KEYS */;
INSERT INTO `formie_encryption_settings` VALUES (1,1,NULL,NULL,NULL,'2026-10-13 20:16:35','2026-10-13 20:16:35');
/*!40000 ALTER TABLE `formie_encryption_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_field_site_overrides`
--

DROP TABLE IF EXISTS `formie_field_site_overrides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_field_site_overrides` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `overrides` json NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ploqaywjhztgnbodwvurkpsrrihqhbcbanna` (`fieldId`,`siteId`),
  KEY `idx_ggmlewbzwoyljjbhkwrnjcsowcjjhhxodktj` (`siteId`),
  CONSTRAINT `fk_avsdpodmifkglppsjdzqgzybdhqpiweuqhzm` FOREIGN KEY (`fieldId`) REFERENCES `formie_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jbxursxavlobabuccbbsarnkorvnxvmynsqf` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_field_site_overrides`
--

LOCK TABLES `formie_field_site_overrides` WRITE;
/*!40000 ALTER TABLE `formie_field_site_overrides` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_field_site_overrides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_fieldlayout_pages`
--

DROP TABLE IF EXISTS `formie_fieldlayout_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_fieldlayout_pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `label` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `settings` text COLLATE utf8mb4_unicode_520_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wpvtwxnphxtaqzltujnirqycztxsggyhikxz` (`layoutId`),
  CONSTRAINT `fk_pvhuxhizrabnjlbsovdbuumqfrafbheefifb` FOREIGN KEY (`layoutId`) REFERENCES `formie_fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_fieldlayout_pages`
--

LOCK TABLES `formie_fieldlayout_pages` WRITE;
/*!40000 ALTER TABLE `formie_fieldlayout_pages` DISABLE KEYS */;
INSERT INTO `formie_fieldlayout_pages` VALUES (1,1,'Your details',0,'{\"submitButtonLabel\":\"Next\",\"backButtonLabel\":\"Back\",\"showBackButton\":false,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-16 13:21:56','2026-03-17 03:36:23','1e82c06b-86f8-4e94-90e9-5ef9b3b32f6a'),(2,2,'Page 1',0,'{\"submitButtonLabel\":\"Submit\",\"backButtonLabel\":\"Back\",\"showBackButton\":false,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 02:17:36','2026-03-17 02:17:36','ec0bf314-553c-4962-825a-6d23df82a627'),(3,3,'Contact details',0,'{\"submitButtonLabel\":\"Submit\",\"backButtonLabel\":\"Back\",\"showBackButton\":false,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 02:17:42','2026-03-17 03:50:17','3861478f-9677-470b-9038-d6219123ffba'),(4,4,'Page 1',0,'{\"submitButtonLabel\":\"Submit\",\"backButtonLabel\":\"Back\",\"showBackButton\":false,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 03:17:58','2026-03-17 03:17:58','fd4ff3d3-3d7c-4a76-a266-2646d39d24c0'),(5,1,'Project details',1,'{\"submitButtonLabel\":\"Next\",\"backButtonLabel\":\"Back\",\"showBackButton\":true,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 03:28:50','2026-03-17 03:36:23','787948e3-f947-4f6a-9c1e-308c300f5b8e'),(6,1,'Final details',2,'{\"submitButtonLabel\":\"Submit\",\"backButtonLabel\":\"Back\",\"showBackButton\":true,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 03:28:50','2026-03-17 03:32:02','aee8d094-36bb-4b7d-b244-b7df9e9410d0'),(7,5,'Page 1',0,'{\"submitButtonLabel\":\"Submit\",\"backButtonLabel\":\"Back\",\"showBackButton\":false,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 03:32:01','2026-03-17 03:32:01','e73ce615-5e27-4656-a700-50ccf0f72915'),(8,6,'Page 1',0,'{\"submitButtonLabel\":\"Submit\",\"backButtonLabel\":\"Back\",\"showBackButton\":false,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 03:50:17','2026-03-17 03:50:17','21e594fb-0bfb-4efa-9e69-c17abd7c966c'),(9,3,'Service details',1,'{\"submitButtonLabel\":\"Submit\",\"backButtonLabel\":\"Back\",\"showBackButton\":true,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 03:50:17','2026-03-17 03:50:17','2cb638aa-2463-4d6d-b59b-caa302429a7b'),(10,7,'Page 1',0,'{\"submitButtonLabel\":\"Submit\",\"backButtonLabel\":\"Back\",\"showBackButton\":false,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 03:50:17','2026-03-17 03:50:17','1fd070b1-dc33-4d71-8520-ff4a967bfe56'),(11,3,'Extra detail',2,'{\"submitButtonLabel\":\"Submit\",\"backButtonLabel\":\"Back\",\"showBackButton\":true,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 03:50:17','2026-03-17 03:50:17','607d4fc6-96ba-4fce-aaaf-478b6cd72dce'),(12,3,'Approval',3,'{\"submitButtonLabel\":\"Submit\",\"backButtonLabel\":\"Back\",\"showBackButton\":true,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 03:50:17','2026-03-17 03:50:17','65eb191d-26d9-44b5-a687-d02f402dd429'),(13,8,'Page 1',0,'{\"submitButtonLabel\":\"Submit\",\"backButtonLabel\":\"Back\",\"showBackButton\":false,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 03:51:39','2026-03-17 03:51:39','e0172d3a-6338-43fd-8124-271b8f59ed99'),(14,9,'Page 1',0,'{\"submitButtonLabel\":\"Submit\",\"backButtonLabel\":\"Back\",\"showBackButton\":false,\"saveButtonLabel\":\"Save\",\"showSaveButton\":false,\"saveButtonStyle\":\"link\",\"buttonsPosition\":\"left\",\"cssClasses\":null,\"containerAttributes\":null,\"inputAttributes\":null,\"enableNextButtonConditions\":false,\"nextButtonConditions\":[],\"enablePageConditions\":false,\"pageConditions\":[],\"enableJsEvents\":false,\"jsGtmEventOptions\":[]}','2026-03-17 03:54:57','2026-03-17 03:54:57','e7c055ce-fe68-4c80-89e4-8b0762648033');
/*!40000 ALTER TABLE `formie_fieldlayout_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_fieldlayout_rows`
--

DROP TABLE IF EXISTS `formie_fieldlayout_rows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_fieldlayout_rows` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `pageId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nfsfgslizgchywxikoctigadykesadrdgjpq` (`layoutId`),
  KEY `idx_rigadbfcszzcichflxnrdbfzhqzmlvlzoqda` (`pageId`),
  CONSTRAINT `fk_hofdujcxsqjqlqwuffgiruvtfkmpblgqlfxp` FOREIGN KEY (`pageId`) REFERENCES `formie_fieldlayout_pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ldekbojupfyftyfszdrptoyjqgexgeetjgbc` FOREIGN KEY (`layoutId`) REFERENCES `formie_fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_fieldlayout_rows`
--

LOCK TABLES `formie_fieldlayout_rows` WRITE;
/*!40000 ALTER TABLE `formie_fieldlayout_rows` DISABLE KEYS */;
INSERT INTO `formie_fieldlayout_rows` VALUES (2,1,1,1,'2026-03-16 13:22:14','2026-03-16 13:22:14','53ce4ed9-1a4c-458b-b732-f82ebb708d6a'),(3,2,2,0,'2026-03-17 03:17:58','2026-03-17 03:17:58','24c35f62-f6d8-458e-968a-d945bf229882'),(4,4,4,0,'2026-03-17 03:17:58','2026-03-17 03:17:58','236c68cc-3467-4f27-9e61-3a1f6dba2847'),(5,2,2,1,'2026-03-17 03:19:14','2026-03-17 03:19:14','37731921-28fa-4a87-848b-f4c77dac9d73'),(6,2,2,2,'2026-03-17 03:19:14','2026-03-17 03:19:14','0a1f99fb-1aa8-41ae-a16c-611afa760f17'),(7,1,1,0,'2026-03-17 03:32:01','2026-03-17 03:32:01','f102d318-6274-4f34-ab58-42eca6255855'),(8,5,7,0,'2026-03-17 03:32:01','2026-03-17 03:32:01','4cbd6a9c-3656-4040-8b15-48ee1a2f380c'),(9,1,1,2,'2026-03-17 03:32:02','2026-03-17 03:32:02','fb404ea4-33db-4ecd-8961-d8ec4c4c9b31'),(10,1,5,0,'2026-03-17 03:33:28','2026-03-17 03:33:28','aa7756d3-085f-4b2b-933e-b442e6136535'),(11,1,5,1,'2026-03-17 03:35:13','2026-03-17 03:35:13','98f251ad-0388-4788-97e9-3c44e8fe1695'),(12,1,5,2,'2026-03-17 03:35:13','2026-03-17 03:35:13','f70f5ca6-4b7d-4dd3-a2d1-23ccbc65ab8e'),(13,1,6,0,'2026-03-17 03:36:00','2026-03-17 03:36:00','95a4adf8-3405-4948-90c7-695eebc149a0'),(14,3,3,0,'2026-03-17 03:50:17','2026-03-17 03:50:17','3d5cac82-c3a4-416f-8483-a1fd0a54e40f'),(15,6,8,0,'2026-03-17 03:50:17','2026-03-17 03:50:17','d03869cc-0224-44df-91b8-b98c42a4ddeb'),(16,3,3,1,'2026-03-17 03:50:17','2026-03-17 03:50:17','772e76cb-b260-4906-8424-ba9f4b2e75da'),(17,3,9,0,'2026-03-17 03:50:17','2026-03-17 03:50:17','5aad64b7-d978-4ebc-a3e4-006eb7e59818'),(18,7,10,0,'2026-03-17 03:50:17','2026-03-17 03:50:17','59c38c45-5b19-4518-b7b6-5e6c81b873ba'),(19,3,9,1,'2026-03-17 03:51:39','2026-03-17 03:51:39','5b88ded0-3352-411e-a75d-08df6ae29c37'),(20,8,13,0,'2026-03-17 03:51:39','2026-03-17 03:51:39','2000588f-84eb-4b90-93c4-8a1ea82dc4dc'),(21,8,13,1,'2026-03-17 03:51:39','2026-03-17 03:51:39','8d43cb90-5ddb-4b54-a8e8-6e11c10f7039'),(22,8,13,2,'2026-03-17 03:51:39','2026-03-17 03:51:39','00b9c965-db55-48c6-9f6e-f9ccfd7ab422'),(23,8,13,3,'2026-03-17 03:51:39','2026-03-17 03:51:39','113bfc27-5a03-4a43-88ae-22ae0a4e5577'),(24,8,13,4,'2026-03-17 03:51:39','2026-03-17 03:51:39','e6223aed-2e89-4b3a-b441-98dbb767e80c'),(25,3,9,2,'2026-03-17 03:51:39','2026-03-17 03:51:39','8cfa70d7-1e4f-42c9-89e5-da7a96020075'),(26,3,12,0,'2026-03-17 03:52:46','2026-03-17 03:52:46','7c6016ee-33d2-4115-9266-ccb45d582ea2'),(27,3,11,0,'2026-03-17 03:54:57','2026-03-17 03:54:57','527da714-3228-438b-90b1-4d1d7a8bd338'),(28,9,14,0,'2026-03-17 03:54:57','2026-03-17 03:54:57','8f5fe5d9-b109-48e4-bf15-14823d07c447'),(29,3,9,3,'2026-03-17 04:00:12','2026-03-17 04:00:12','4639e51f-29f2-4406-b87e-6687e9371f98');
/*!40000 ALTER TABLE `formie_fieldlayout_rows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_fieldlayouts`
--

DROP TABLE IF EXISTS `formie_fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_fieldlayouts`
--

LOCK TABLES `formie_fieldlayouts` WRITE;
/*!40000 ALTER TABLE `formie_fieldlayouts` DISABLE KEYS */;
INSERT INTO `formie_fieldlayouts` VALUES (1,'2026-03-16 13:21:56','2026-03-16 13:21:56','8af97de1-1f61-4c43-b34b-7b39dc30e0a9'),(2,'2026-03-17 02:17:36','2026-03-17 02:17:36','7767e2b3-a0d5-4c87-9fde-eaf254294a42'),(3,'2026-03-17 02:17:42','2026-03-17 02:17:42','a3e8ea6c-20f7-43cd-b41f-1a05eff97cad'),(4,'2026-03-17 03:17:58','2026-03-17 03:17:58','878846f9-acb3-4686-a52a-2ba1f3aae5ff'),(5,'2026-03-17 03:32:01','2026-03-17 03:32:01','aa2a5800-8fdc-4789-8de9-0235b3a126c8'),(6,'2026-03-17 03:50:17','2026-03-17 03:50:17','00c5342a-20af-4714-b08e-4644d203f3f3'),(7,'2026-03-17 03:50:17','2026-03-17 03:50:17','3ce379d8-a521-4091-9577-050e464b12b5'),(8,'2026-03-17 03:51:39','2026-03-17 03:51:39','892459d2-0ea6-4dec-99ab-93acd89356ba'),(9,'2026-03-17 03:54:57','2026-03-17 03:54:57','fd4786ac-dc95-473f-9609-35740ddf6581');
/*!40000 ALTER TABLE `formie_fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_fields`
--

DROP TABLE IF EXISTS `formie_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `label` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `settings` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pvmhgcyqvgkfetcjbvstlzhlhoypyjjmqxgx` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_fields`
--

LOCK TABLES `formie_fields` WRITE;
/*!40000 ALTER TABLE `formie_fields` DISABLE KEYS */;
INSERT INTO `formie_fields` VALUES (2,'verbb\\formie\\fields\\Email','Email','email','{\"enabled\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"We’ll use this to reply with next steps or questions.\",\"labelPosition\":null,\"blockedDomains\":[],\"includeInEmail\":true,\"validateDomain\":false,\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-16 13:22:14','2026-10-13 20:14:32','c90b6971-04ae-4b20-bb86-acd0b55771a6'),(3,'verbb\\formie\\fields\\subfields\\NamePrefix','Prefix','prefix','{\"max\":null,\"min\":null,\"multi\":false,\"layout\":null,\"enabled\":false,\"options\":[{\"label\":\"Select an option\",\"value\":\"\"},{\"label\":\"Mr.\",\"value\":\"mr\"},{\"label\":\"Mrs.\",\"value\":\"mrs\"},{\"label\":\"Ms.\",\"value\":\"ms\"},{\"label\":\"Miss.\",\"value\":\"miss\"},{\"label\":\"Mx.\",\"value\":\"mx\"},{\"label\":\"Dr.\",\"value\":\"dr\"},{\"label\":\"Prof.\",\"value\":\"prof\"}],\"optgroups\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":\"label\",\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"limitOptions\":false,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"honorific-prefix\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:17:58','2026-10-13 20:14:32','f93d0790-0b3d-437d-bf62-f9f90e95043a'),(4,'verbb\\formie\\fields\\subfields\\NameFirst','First Name','firstName','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":\"e.g. Peter\",\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"given-name\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:17:58','2026-10-13 20:14:32','e8525540-6d68-4b64-97c1-1ddb330f0ee5'),(5,'verbb\\formie\\fields\\subfields\\NameMiddle','Middle Name','middleName','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":false,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"additional-name\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:17:58','2026-10-13 20:14:32','20e3268e-0775-4950-bc94-355dafe5a0c6'),(6,'verbb\\formie\\fields\\subfields\\NameLast','Last Name','lastName','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":\"e.g. Sherman\",\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"family-name\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:17:58','2026-10-13 20:14:32','8e26a582-68fa-445e-a3df-b1cfdac1a7f9'),(7,'verbb\\formie\\fields\\Name','Your Name','yourName','{\"enabled\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"contentTable\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Please enter your full name.\",\"labelPosition\":null,\"includeInEmail\":true,\"nestedLayoutId\":4,\"inputAttributes\":null,\"enableConditions\":false,\"useMultipleFields\":true,\"containerAttributes\":null,\"instructionsPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"subFieldLabelPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:17:58','2026-10-13 20:14:32','480522ee-f248-482d-9350-aa5a8cd82088'),(8,'verbb\\formie\\fields\\Email','Email Address','emailAddress','{\"enabled\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":\"e.g. psherman@wallaby.com\",\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Please enter your email so we can get in touch.\",\"labelPosition\":null,\"blockedDomains\":[],\"includeInEmail\":true,\"validateDomain\":false,\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:19:14','2026-10-13 20:14:32','88c96b36-9ccc-4ed4-8266-0b67f3e45a18'),(9,'verbb\\formie\\fields\\MultiLineText','Message','message','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":\"e.g. The reason for my enquiry is...\",\"uniqueValue\":false,\"useRichText\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Please enter your comments.\",\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":null,\"richTextButtons\":[\"bold\",\"italic\"],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:19:14','2026-10-13 20:14:32','4338a024-2a51-4761-be21-07c1022f07d0'),(10,'verbb\\formie\\fields\\subfields\\NamePrefix','Prefix','prefix','{\"max\":null,\"min\":null,\"multi\":false,\"layout\":null,\"enabled\":false,\"options\":[{\"label\":\"Select an option\",\"value\":\"\"},{\"label\":\"Mr.\",\"value\":\"mr\"},{\"label\":\"Mrs.\",\"value\":\"mrs\"},{\"label\":\"Ms.\",\"value\":\"ms\"},{\"label\":\"Miss.\",\"value\":\"miss\"},{\"label\":\"Mx.\",\"value\":\"mx\"},{\"label\":\"Dr.\",\"value\":\"dr\"},{\"label\":\"Prof.\",\"value\":\"prof\"}],\"optgroups\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":\"label\",\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"limitOptions\":false,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"honorific-prefix\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:32:01','2026-10-13 20:14:32','7f1d278c-40b2-42bb-aa25-cedf1f64b4a4'),(11,'verbb\\formie\\fields\\subfields\\NameFirst','First Name','firstName','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"given-name\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:32:01','2026-10-13 20:14:32','8f66d7a8-647b-46eb-99b4-1455b989d947'),(12,'verbb\\formie\\fields\\subfields\\NameMiddle','Middle Name','middleName','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":false,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"additional-name\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:32:01','2026-10-13 20:14:32','cb61e911-3f77-4dcd-9c66-797f637f63b2'),(13,'verbb\\formie\\fields\\subfields\\NameLast','Last Name','lastName','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"family-name\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:32:02','2026-10-13 20:14:32','7514d18a-486d-4612-a539-f0e89bdf9bd4'),(14,'verbb\\formie\\fields\\Name','Name','name1','{\"enabled\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"contentTable\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Tell us who we should contact about this enquiry.\",\"labelPosition\":null,\"includeInEmail\":true,\"nestedLayoutId\":5,\"inputAttributes\":null,\"enableConditions\":false,\"useMultipleFields\":true,\"containerAttributes\":null,\"instructionsPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"subFieldLabelPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:32:02','2026-10-13 20:14:32','cb8c60a2-a8ef-4bac-a3a7-bbd5c2189671'),(15,'verbb\\formie\\fields\\SingleLineText','Company','company','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Company or organisation name, if relevant.\",\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:32:02','2026-10-13 20:14:32','356102d2-873f-49f5-881f-95a9e5b11f36'),(16,'verbb\\formie\\fields\\Dropdown','Project Type','projectType','{\"max\":null,\"min\":null,\"multi\":false,\"layout\":null,\"enabled\":true,\"options\":[{\"label\":\"Select an option\",\"value\":\"\",\"default\":true},{\"label\":\"Website redesign\",\"value\":\"Website redesign\"},{\"label\":\"New website build\",\"value\":\"New website build\"},{\"label\":\"E-commerce\",\"value\":\"E-commerce\"},{\"label\":\"Campaign or landing page\",\"value\":\"Campaign or landing page\"},{\"label\":\"Ongoing support\",\"value\":\"Ongoing support\"},{\"label\":\"Something else\",\"value\":\"Something else\"}],\"optgroups\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":\"label\",\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Choose the option that best matches the work you need.\",\"limitOptions\":false,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:33:28','2026-10-13 20:14:32','298187a9-6fbc-4990-a4a0-b24f7fa116ad'),(17,'verbb\\formie\\fields\\Radio','Budget','budget','{\"multi\":false,\"layout\":\"vertical\",\"enabled\":true,\"options\":[{\"label\":\"$1k-$5k\",\"value\":\"$1k-$5k\"},{\"label\":\"$5k-$10k\",\"value\":\"$5k-$10k\"},{\"label\":\"$10k-$25k\",\"value\":\"$10k-$25k\"},{\"label\":\"$25k+\",\"value\":\"$25k+\"}],\"conditions\":null,\"cssClasses\":null,\"emailValue\":\"label\",\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:35:13','2026-10-13 20:14:32','94859897-032c-4a3b-a868-8f283db77dd3'),(18,'verbb\\formie\\fields\\MultiLineText','Project Summary','projectSummary','{\"max\":200,\"min\":null,\"limit\":true,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"useRichText\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"A short overview of what you’re trying to achieve.\",\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":null,\"richTextButtons\":[\"bold\",\"italic\"],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:35:13','2026-10-13 20:14:32','c027e4e0-f160-49f2-95f4-dace67fdb8ec'),(19,'verbb\\formie\\fields\\Agree','Consent','consent','{\"enabled\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"description\":[{\"type\":\"paragraph\",\"attrs\":{\"textAlign\":\"start\"},\"content\":[{\"text\":\"I understand this demo form stores my submission for review.\",\"type\":\"text\"}]}],\"placeholder\":null,\"checkedValue\":\"Yes\",\"defaultValue\":false,\"errorMessage\":null,\"instructions\":\"You must confirm before submitting.\",\"labelPosition\":\"verbb\\\\formie\\\\positions\\\\Hidden\",\"includeInEmail\":true,\"uncheckedValue\":\"No\",\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:36:00','2026-10-13 20:14:32','61c6b623-8945-4057-adb0-ba0a616b8eff'),(20,'verbb\\formie\\fields\\subfields\\NamePrefix','Prefix','prefix','{\"max\":null,\"min\":null,\"multi\":false,\"layout\":null,\"enabled\":false,\"options\":[{\"label\":\"Select an option\",\"value\":\"\"},{\"label\":\"Mr.\",\"value\":\"mr\"},{\"label\":\"Mrs.\",\"value\":\"mrs\"},{\"label\":\"Ms.\",\"value\":\"ms\"},{\"label\":\"Miss.\",\"value\":\"miss\"},{\"label\":\"Mx.\",\"value\":\"mx\"},{\"label\":\"Dr.\",\"value\":\"dr\"},{\"label\":\"Prof.\",\"value\":\"prof\"}],\"optgroups\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":\"label\",\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"limitOptions\":false,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"honorific-prefix\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:50:17','2026-10-13 20:14:32','4d215330-a1a1-454a-b900-02936c803aa9'),(21,'verbb\\formie\\fields\\subfields\\NameFirst','First Name','firstName','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"given-name\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:50:17','2026-10-13 20:14:32','8bf346c1-f28d-4b77-a4d1-238aa9e4d660'),(22,'verbb\\formie\\fields\\subfields\\NameMiddle','Middle Name','middleName','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":false,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"additional-name\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:50:17','2026-10-13 20:14:32','8bbb6913-ca8a-49c8-8cbc-dd7c5e7d6fb4'),(23,'verbb\\formie\\fields\\subfields\\NameLast','Last Name','lastName','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"family-name\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:50:17','2026-10-13 20:14:32','43e2310c-89ac-4ced-a2d8-c653a3664696'),(24,'verbb\\formie\\fields\\Name','Name','name','{\"enabled\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"contentTable\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Who should we contact about this request?\",\"labelPosition\":null,\"includeInEmail\":true,\"nestedLayoutId\":6,\"inputAttributes\":null,\"enableConditions\":false,\"useMultipleFields\":true,\"containerAttributes\":null,\"instructionsPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"subFieldLabelPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:50:17','2026-10-13 20:14:32','f126f917-3c1e-4e67-b60a-60d8be4bef3b'),(25,'verbb\\formie\\fields\\Phone','Phone','phone','{\"enabled\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Best number for scheduling or follow-up.\",\"labelPosition\":null,\"countryAllowed\":[],\"countryEnabled\":true,\"includeInEmail\":true,\"countryLanguage\":\"auto\",\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"countryDefaultValue\":\"US\",\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:50:17','2026-10-13 20:14:32','a5a4e204-8f0c-476a-b62c-3e3d8ce1811c'),(26,'verbb\\formie\\fields\\subfields\\DateDate','Date','date','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":\"verbb\\\\formie\\\\positions\\\\Hidden\",\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"type\",\"value\":\"date\"},{\"label\":\"autocomplete\",\"value\":\"off\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:50:17','2026-10-13 20:14:32','f290ebaa-c691-4c8d-b913-5f7abd701450'),(27,'verbb\\formie\\fields\\subfields\\DateTime','Time','time','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":false,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":\"verbb\\\\formie\\\\positions\\\\Hidden\",\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"type\",\"value\":\"time\"},{\"label\":\"autocomplete\",\"value\":\"off\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:50:17','2026-10-13 20:14:32','3131dab5-87f4-4f2f-8b8f-3dc3763b343d'),(28,'verbb\\formie\\fields\\Date','Service Date','serviceDate','{\"enabled\":true,\"layouts\":{\"inputs\":[{\"fields\":[{\"max\":2126,\"min\":1926,\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateYearNumber\",\"label\":\"Year\",\"limit\":true,\"handle\":\"year\",\"enabled\":true,\"labelPosition\":null},{\"max\":12,\"min\":1,\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateMonthNumber\",\"label\":\"Month\",\"limit\":true,\"handle\":\"month\",\"enabled\":true,\"labelPosition\":null},{\"max\":31,\"min\":1,\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateDayNumber\",\"label\":\"Day\",\"limit\":true,\"handle\":\"day\",\"enabled\":true,\"labelPosition\":null},{\"max\":23,\"min\":0,\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateHourNumber\",\"label\":\"Hour\",\"limit\":true,\"handle\":\"hour\",\"enabled\":true,\"labelPosition\":null},{\"max\":59,\"min\":0,\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateMinuteNumber\",\"label\":\"Minute\",\"limit\":true,\"handle\":\"minute\",\"enabled\":true,\"labelPosition\":null},{\"max\":59,\"min\":0,\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateSecondNumber\",\"label\":\"Second\",\"limit\":true,\"handle\":\"second\",\"enabled\":true,\"labelPosition\":null},{\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateAmPmDropdown\",\"label\":\"AM\\/PM\",\"handle\":\"ampm\",\"enabled\":false,\"options\":[{\"label\":\"AM\",\"value\":\"AM\"},{\"label\":\"PM\",\"value\":\"PM\"}],\"labelPosition\":null}]}],\"calendar\":[{\"id\":18,\"fields\":[{\"id\":26,\"max\":null,\"min\":null,\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateDate\",\"label\":\"Date\",\"limit\":false,\"rowId\":18,\"handle\":\"date\",\"pageId\":10,\"syncId\":null,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"layoutId\":7,\"required\":true,\"reference\":\"4ff1e5c3-060f-4520-bf76-2487732573cc\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":\"verbb\\\\formie\\\\positions\\\\Hidden\",\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"type\",\"value\":\"date\"},{\"label\":\"autocomplete\",\"value\":\"off\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null},{\"id\":27,\"max\":null,\"min\":null,\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateTime\",\"label\":\"Time\",\"limit\":false,\"rowId\":18,\"handle\":\"time\",\"pageId\":10,\"syncId\":null,\"enabled\":false,\"maxType\":\"characters\",\"minType\":\"characters\",\"layoutId\":7,\"required\":false,\"reference\":\"04f33f88-745f-4453-a6c7-9305d5c571fd\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":\"verbb\\\\formie\\\\positions\\\\Hidden\",\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"type\",\"value\":\"time\"},{\"label\":\"autocomplete\",\"value\":\"off\"}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}],\"pageId\":10,\"layoutId\":7}],\"dropdowns\":[{\"fields\":[{\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateYearDropdown\",\"label\":\"Year\",\"handle\":\"year\",\"enabled\":true,\"options\":[],\"labelPosition\":null},{\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateMonthDropdown\",\"label\":\"Month\",\"handle\":\"month\",\"enabled\":true,\"options\":[{\"label\":null,\"value\":\"\",\"disabled\":true},{\"label\":\"January\",\"value\":1},{\"label\":\"February\",\"value\":2},{\"label\":\"March\",\"value\":3},{\"label\":\"April\",\"value\":4},{\"label\":\"May\",\"value\":5},{\"label\":\"June\",\"value\":6},{\"label\":\"July\",\"value\":7},{\"label\":\"August\",\"value\":8},{\"label\":\"September\",\"value\":9},{\"label\":\"October\",\"value\":10},{\"label\":\"November\",\"value\":11},{\"label\":\"December\",\"value\":12}],\"labelPosition\":null},{\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateDayDropdown\",\"label\":\"Day\",\"handle\":\"day\",\"enabled\":true,\"options\":[{\"label\":null,\"value\":\"\",\"disabled\":true},{\"label\":1,\"value\":1},{\"label\":2,\"value\":2},{\"label\":3,\"value\":3},{\"label\":4,\"value\":4},{\"label\":5,\"value\":5},{\"label\":6,\"value\":6},{\"label\":7,\"value\":7},{\"label\":8,\"value\":8},{\"label\":9,\"value\":9},{\"label\":10,\"value\":10},{\"label\":11,\"value\":11},{\"label\":12,\"value\":12},{\"label\":13,\"value\":13},{\"label\":14,\"value\":14},{\"label\":15,\"value\":15},{\"label\":16,\"value\":16},{\"label\":17,\"value\":17},{\"label\":18,\"value\":18},{\"label\":19,\"value\":19},{\"label\":20,\"value\":20},{\"label\":21,\"value\":21},{\"label\":22,\"value\":22},{\"label\":23,\"value\":23},{\"label\":24,\"value\":24},{\"label\":25,\"value\":25},{\"label\":26,\"value\":26},{\"label\":27,\"value\":27},{\"label\":28,\"value\":28},{\"label\":29,\"value\":29},{\"label\":30,\"value\":30},{\"label\":31,\"value\":31}],\"labelPosition\":null},{\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateHourDropdown\",\"label\":\"Hour\",\"handle\":\"hour\",\"enabled\":true,\"options\":[{\"label\":null,\"value\":\"\",\"disabled\":true},{\"label\":0,\"value\":0},{\"label\":1,\"value\":1},{\"label\":2,\"value\":2},{\"label\":3,\"value\":3},{\"label\":4,\"value\":4},{\"label\":5,\"value\":5},{\"label\":6,\"value\":6},{\"label\":7,\"value\":7},{\"label\":8,\"value\":8},{\"label\":9,\"value\":9},{\"label\":10,\"value\":10},{\"label\":11,\"value\":11},{\"label\":12,\"value\":12},{\"label\":13,\"value\":13},{\"label\":14,\"value\":14},{\"label\":15,\"value\":15},{\"label\":16,\"value\":16},{\"label\":17,\"value\":17},{\"label\":18,\"value\":18},{\"label\":19,\"value\":19},{\"label\":20,\"value\":20},{\"label\":21,\"value\":21},{\"label\":22,\"value\":22},{\"label\":23,\"value\":23}],\"labelPosition\":null},{\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateMinuteDropdown\",\"label\":\"Minute\",\"handle\":\"minute\",\"enabled\":true,\"options\":[{\"label\":null,\"value\":\"\",\"disabled\":true},{\"label\":0,\"value\":0},{\"label\":1,\"value\":1},{\"label\":2,\"value\":2},{\"label\":3,\"value\":3},{\"label\":4,\"value\":4},{\"label\":5,\"value\":5},{\"label\":6,\"value\":6},{\"label\":7,\"value\":7},{\"label\":8,\"value\":8},{\"label\":9,\"value\":9},{\"label\":10,\"value\":10},{\"label\":11,\"value\":11},{\"label\":12,\"value\":12},{\"label\":13,\"value\":13},{\"label\":14,\"value\":14},{\"label\":15,\"value\":15},{\"label\":16,\"value\":16},{\"label\":17,\"value\":17},{\"label\":18,\"value\":18},{\"label\":19,\"value\":19},{\"label\":20,\"value\":20},{\"label\":21,\"value\":21},{\"label\":22,\"value\":22},{\"label\":23,\"value\":23},{\"label\":24,\"value\":24},{\"label\":25,\"value\":25},{\"label\":26,\"value\":26},{\"label\":27,\"value\":27},{\"label\":28,\"value\":28},{\"label\":29,\"value\":29},{\"label\":30,\"value\":30},{\"label\":31,\"value\":31},{\"label\":32,\"value\":32},{\"label\":33,\"value\":33},{\"label\":34,\"value\":34},{\"label\":35,\"value\":35},{\"label\":36,\"value\":36},{\"label\":37,\"value\":37},{\"label\":38,\"value\":38},{\"label\":39,\"value\":39},{\"label\":40,\"value\":40},{\"label\":41,\"value\":41},{\"label\":42,\"value\":42},{\"label\":43,\"value\":43},{\"label\":44,\"value\":44},{\"label\":45,\"value\":45},{\"label\":46,\"value\":46},{\"label\":47,\"value\":47},{\"label\":48,\"value\":48},{\"label\":49,\"value\":49},{\"label\":50,\"value\":50},{\"label\":51,\"value\":51},{\"label\":52,\"value\":52},{\"label\":53,\"value\":53},{\"label\":54,\"value\":54},{\"label\":55,\"value\":55},{\"label\":56,\"value\":56},{\"label\":57,\"value\":57},{\"label\":58,\"value\":58},{\"label\":59,\"value\":59}],\"labelPosition\":null},{\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateSecondDropdown\",\"label\":\"Second\",\"handle\":\"second\",\"enabled\":true,\"options\":[{\"label\":null,\"value\":\"\",\"disabled\":true},{\"label\":0,\"value\":0},{\"label\":1,\"value\":1},{\"label\":2,\"value\":2},{\"label\":3,\"value\":3},{\"label\":4,\"value\":4},{\"label\":5,\"value\":5},{\"label\":6,\"value\":6},{\"label\":7,\"value\":7},{\"label\":8,\"value\":8},{\"label\":9,\"value\":9},{\"label\":10,\"value\":10},{\"label\":11,\"value\":11},{\"label\":12,\"value\":12},{\"label\":13,\"value\":13},{\"label\":14,\"value\":14},{\"label\":15,\"value\":15},{\"label\":16,\"value\":16},{\"label\":17,\"value\":17},{\"label\":18,\"value\":18},{\"label\":19,\"value\":19},{\"label\":20,\"value\":20},{\"label\":21,\"value\":21},{\"label\":22,\"value\":22},{\"label\":23,\"value\":23},{\"label\":24,\"value\":24},{\"label\":25,\"value\":25},{\"label\":26,\"value\":26},{\"label\":27,\"value\":27},{\"label\":28,\"value\":28},{\"label\":29,\"value\":29},{\"label\":30,\"value\":30},{\"label\":31,\"value\":31},{\"label\":32,\"value\":32},{\"label\":33,\"value\":33},{\"label\":34,\"value\":34},{\"label\":35,\"value\":35},{\"label\":36,\"value\":36},{\"label\":37,\"value\":37},{\"label\":38,\"value\":38},{\"label\":39,\"value\":39},{\"label\":40,\"value\":40},{\"label\":41,\"value\":41},{\"label\":42,\"value\":42},{\"label\":43,\"value\":43},{\"label\":44,\"value\":44},{\"label\":45,\"value\":45},{\"label\":46,\"value\":46},{\"label\":47,\"value\":47},{\"label\":48,\"value\":48},{\"label\":49,\"value\":49},{\"label\":50,\"value\":50},{\"label\":51,\"value\":51},{\"label\":52,\"value\":52},{\"label\":53,\"value\":53},{\"label\":54,\"value\":54},{\"label\":55,\"value\":55},{\"label\":56,\"value\":56},{\"label\":57,\"value\":57},{\"label\":58,\"value\":58},{\"label\":59,\"value\":59}],\"labelPosition\":null},{\"type\":\"verbb\\\\formie\\\\fields\\\\subfields\\\\DateAmPmDropdown\",\"label\":\"AM\\/PM\",\"handle\":\"ampm\",\"enabled\":false,\"options\":[{\"label\":\"AM\",\"value\":\"AM\"},{\"label\":\"PM\",\"value\":\"PM\"}],\"labelPosition\":null}]}]},\"maxDate\":null,\"minDate\":null,\"conditions\":null,\"cssClasses\":null,\"dateFormat\":\"Y-m-d\",\"emailValue\":null,\"matchField\":null,\"timeFormat\":\"H:i\",\"visibility\":null,\"displayType\":\"datePicker\",\"placeholder\":null,\"contentTable\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Preferred booking or visit date.\",\"defaultOption\":null,\"labelPosition\":null,\"maxDateOffset\":\"add\",\"maxDateOption\":\"\",\"minDateOffset\":\"add\",\"minDateOption\":\"today\",\"includeInEmail\":true,\"nestedLayoutId\":7,\"inputAttributes\":null,\"enableConditions\":false,\"datePickerOptions\":[],\"maxDateOffsetType\":\"days\",\"minDateOffsetType\":\"days\",\"availableDaysOfWeek\":[1,2,3,4,5],\"containerAttributes\":null,\"maxDateOffsetNumber\":0,\"minDateOffsetNumber\":2,\"instructionsPosition\":null,\"subFieldLabelPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:50:17','2026-10-13 20:14:32','2cdfc715-1ff6-4547-a582-80027a6167c0'),(29,'verbb\\formie\\fields\\subfields\\Address1','Address 1','address1','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"address-line1\"},{\"label\":\"data-address1\",\"value\":true}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:51:39','2026-10-13 20:14:32','02c0f551-e19c-4763-a6d1-9be98700c99a'),(30,'verbb\\formie\\fields\\subfields\\Address2','Address 2','address2','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":false,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"address-line2\"},{\"label\":\"data-address2\",\"value\":true}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:51:39','2026-10-13 20:14:32','d721dcc5-06d7-48b7-bd3f-262148ed460b'),(31,'verbb\\formie\\fields\\subfields\\Address3','Address 3','address3','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":false,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"address-line3\"},{\"label\":\"data-address3\",\"value\":true}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:51:39','2026-10-13 20:14:32','902c642a-c03a-4f9b-bc00-e79169961559'),(32,'verbb\\formie\\fields\\subfields\\AddressCity','City','city','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"address-level2\"},{\"label\":\"data-city\",\"value\":true}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:51:39','2026-10-13 20:14:32','eeae8b69-0b8a-4fea-ad69-c51508515cf9'),(33,'verbb\\formie\\fields\\subfields\\AddressZip','ZIP / Postal Code','zip','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"postal-code\"},{\"label\":\"data-zip\",\"value\":true}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:51:39','2026-10-13 20:14:32','666835d6-d105-4641-9fea-dbef6645e0c1'),(34,'verbb\\formie\\fields\\subfields\\AddressState','State / Province','state','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"address-level1\"},{\"label\":\"data-state\",\"value\":true}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:51:39','2026-10-13 20:14:32','ace84e2f-3b7d-4798-8d8a-65eef4087cca'),(35,'verbb\\formie\\fields\\subfields\\AddressCountry','Country','country','{\"max\":null,\"min\":null,\"multi\":false,\"layout\":null,\"enabled\":true,\"options\":[{\"label\":\"Afghanistan\",\"value\":\"AF\"},{\"label\":\"Åland Islands\",\"value\":\"AX\"},{\"label\":\"Albania\",\"value\":\"AL\"},{\"label\":\"Algeria\",\"value\":\"DZ\"},{\"label\":\"American Samoa\",\"value\":\"AS\"},{\"label\":\"Andorra\",\"value\":\"AD\"},{\"label\":\"Angola\",\"value\":\"AO\"},{\"label\":\"Anguilla\",\"value\":\"AI\"},{\"label\":\"Antarctica\",\"value\":\"AQ\"},{\"label\":\"Antigua & Barbuda\",\"value\":\"AG\"},{\"label\":\"Argentina\",\"value\":\"AR\"},{\"label\":\"Armenia\",\"value\":\"AM\"},{\"label\":\"Aruba\",\"value\":\"AW\"},{\"label\":\"Ascension Island\",\"value\":\"AC\"},{\"label\":\"Australia\",\"value\":\"AU\"},{\"label\":\"Austria\",\"value\":\"AT\"},{\"label\":\"Azerbaijan\",\"value\":\"AZ\"},{\"label\":\"Bahamas\",\"value\":\"BS\"},{\"label\":\"Bahrain\",\"value\":\"BH\"},{\"label\":\"Bangladesh\",\"value\":\"BD\"},{\"label\":\"Barbados\",\"value\":\"BB\"},{\"label\":\"Belarus\",\"value\":\"BY\"},{\"label\":\"Belgium\",\"value\":\"BE\"},{\"label\":\"Belize\",\"value\":\"BZ\"},{\"label\":\"Benin\",\"value\":\"BJ\"},{\"label\":\"Bermuda\",\"value\":\"BM\"},{\"label\":\"Bhutan\",\"value\":\"BT\"},{\"label\":\"Bolivia\",\"value\":\"BO\"},{\"label\":\"Bosnia & Herzegovina\",\"value\":\"BA\"},{\"label\":\"Botswana\",\"value\":\"BW\"},{\"label\":\"Bouvet Island\",\"value\":\"BV\"},{\"label\":\"Brazil\",\"value\":\"BR\"},{\"label\":\"British Indian Ocean Territory\",\"value\":\"IO\"},{\"label\":\"British Virgin Islands\",\"value\":\"VG\"},{\"label\":\"Brunei\",\"value\":\"BN\"},{\"label\":\"Bulgaria\",\"value\":\"BG\"},{\"label\":\"Burkina Faso\",\"value\":\"BF\"},{\"label\":\"Burundi\",\"value\":\"BI\"},{\"label\":\"Cambodia\",\"value\":\"KH\"},{\"label\":\"Cameroon\",\"value\":\"CM\"},{\"label\":\"Canada\",\"value\":\"CA\"},{\"label\":\"Canary Islands\",\"value\":\"IC\"},{\"label\":\"Cape Verde\",\"value\":\"CV\"},{\"label\":\"Caribbean Netherlands\",\"value\":\"BQ\"},{\"label\":\"Cayman Islands\",\"value\":\"KY\"},{\"label\":\"Central African Republic\",\"value\":\"CF\"},{\"label\":\"Ceuta & Melilla\",\"value\":\"EA\"},{\"label\":\"Chad\",\"value\":\"TD\"},{\"label\":\"Chile\",\"value\":\"CL\"},{\"label\":\"China\",\"value\":\"CN\"},{\"label\":\"Christmas Island\",\"value\":\"CX\"},{\"label\":\"Clipperton Island\",\"value\":\"CP\"},{\"label\":\"Cocos (Keeling) Islands\",\"value\":\"CC\"},{\"label\":\"Colombia\",\"value\":\"CO\"},{\"label\":\"Comoros\",\"value\":\"KM\"},{\"label\":\"Congo - Brazzaville\",\"value\":\"CG\"},{\"label\":\"Congo - Kinshasa\",\"value\":\"CD\"},{\"label\":\"Cook Islands\",\"value\":\"CK\"},{\"label\":\"Costa Rica\",\"value\":\"CR\"},{\"label\":\"Côte d’Ivoire\",\"value\":\"CI\"},{\"label\":\"Croatia\",\"value\":\"HR\"},{\"label\":\"Cuba\",\"value\":\"CU\"},{\"label\":\"Curaçao\",\"value\":\"CW\"},{\"label\":\"Cyprus\",\"value\":\"CY\"},{\"label\":\"Czechia\",\"value\":\"CZ\"},{\"label\":\"Denmark\",\"value\":\"DK\"},{\"label\":\"Diego Garcia\",\"value\":\"DG\"},{\"label\":\"Djibouti\",\"value\":\"DJ\"},{\"label\":\"Dominica\",\"value\":\"DM\"},{\"label\":\"Dominican Republic\",\"value\":\"DO\"},{\"label\":\"Ecuador\",\"value\":\"EC\"},{\"label\":\"Egypt\",\"value\":\"EG\"},{\"label\":\"El Salvador\",\"value\":\"SV\"},{\"label\":\"Equatorial Guinea\",\"value\":\"GQ\"},{\"label\":\"Eritrea\",\"value\":\"ER\"},{\"label\":\"Estonia\",\"value\":\"EE\"},{\"label\":\"Eswatini\",\"value\":\"SZ\"},{\"label\":\"Ethiopia\",\"value\":\"ET\"},{\"label\":\"Falkland Islands\",\"value\":\"FK\"},{\"label\":\"Faroe Islands\",\"value\":\"FO\"},{\"label\":\"Fiji\",\"value\":\"FJ\"},{\"label\":\"Finland\",\"value\":\"FI\"},{\"label\":\"France\",\"value\":\"FR\"},{\"label\":\"French Guiana\",\"value\":\"GF\"},{\"label\":\"French Polynesia\",\"value\":\"PF\"},{\"label\":\"French Southern Territories\",\"value\":\"TF\"},{\"label\":\"Gabon\",\"value\":\"GA\"},{\"label\":\"Gambia\",\"value\":\"GM\"},{\"label\":\"Georgia\",\"value\":\"GE\"},{\"label\":\"Germany\",\"value\":\"DE\"},{\"label\":\"Ghana\",\"value\":\"GH\"},{\"label\":\"Gibraltar\",\"value\":\"GI\"},{\"label\":\"Greece\",\"value\":\"GR\"},{\"label\":\"Greenland\",\"value\":\"GL\"},{\"label\":\"Grenada\",\"value\":\"GD\"},{\"label\":\"Guadeloupe\",\"value\":\"GP\"},{\"label\":\"Guam\",\"value\":\"GU\"},{\"label\":\"Guatemala\",\"value\":\"GT\"},{\"label\":\"Guernsey\",\"value\":\"GG\"},{\"label\":\"Guinea\",\"value\":\"GN\"},{\"label\":\"Guinea-Bissau\",\"value\":\"GW\"},{\"label\":\"Guyana\",\"value\":\"GY\"},{\"label\":\"Haiti\",\"value\":\"HT\"},{\"label\":\"Heard & McDonald Islands\",\"value\":\"HM\"},{\"label\":\"Honduras\",\"value\":\"HN\"},{\"label\":\"Hong Kong SAR China\",\"value\":\"HK\"},{\"label\":\"Hungary\",\"value\":\"HU\"},{\"label\":\"Iceland\",\"value\":\"IS\"},{\"label\":\"India\",\"value\":\"IN\"},{\"label\":\"Indonesia\",\"value\":\"ID\"},{\"label\":\"Iran\",\"value\":\"IR\"},{\"label\":\"Iraq\",\"value\":\"IQ\"},{\"label\":\"Ireland\",\"value\":\"IE\"},{\"label\":\"Isle of Man\",\"value\":\"IM\"},{\"label\":\"Israel\",\"value\":\"IL\"},{\"label\":\"Italy\",\"value\":\"IT\"},{\"label\":\"Jamaica\",\"value\":\"JM\"},{\"label\":\"Japan\",\"value\":\"JP\"},{\"label\":\"Jersey\",\"value\":\"JE\"},{\"label\":\"Jordan\",\"value\":\"JO\"},{\"label\":\"Kazakhstan\",\"value\":\"KZ\"},{\"label\":\"Kenya\",\"value\":\"KE\"},{\"label\":\"Kiribati\",\"value\":\"KI\"},{\"label\":\"Kosovo\",\"value\":\"XK\"},{\"label\":\"Kuwait\",\"value\":\"KW\"},{\"label\":\"Kyrgyzstan\",\"value\":\"KG\"},{\"label\":\"Laos\",\"value\":\"LA\"},{\"label\":\"Latvia\",\"value\":\"LV\"},{\"label\":\"Lebanon\",\"value\":\"LB\"},{\"label\":\"Lesotho\",\"value\":\"LS\"},{\"label\":\"Liberia\",\"value\":\"LR\"},{\"label\":\"Libya\",\"value\":\"LY\"},{\"label\":\"Liechtenstein\",\"value\":\"LI\"},{\"label\":\"Lithuania\",\"value\":\"LT\"},{\"label\":\"Luxembourg\",\"value\":\"LU\"},{\"label\":\"Macao SAR China\",\"value\":\"MO\"},{\"label\":\"Madagascar\",\"value\":\"MG\"},{\"label\":\"Malawi\",\"value\":\"MW\"},{\"label\":\"Malaysia\",\"value\":\"MY\"},{\"label\":\"Maldives\",\"value\":\"MV\"},{\"label\":\"Mali\",\"value\":\"ML\"},{\"label\":\"Malta\",\"value\":\"MT\"},{\"label\":\"Marshall Islands\",\"value\":\"MH\"},{\"label\":\"Martinique\",\"value\":\"MQ\"},{\"label\":\"Mauritania\",\"value\":\"MR\"},{\"label\":\"Mauritius\",\"value\":\"MU\"},{\"label\":\"Mayotte\",\"value\":\"YT\"},{\"label\":\"Mexico\",\"value\":\"MX\"},{\"label\":\"Micronesia\",\"value\":\"FM\"},{\"label\":\"Moldova\",\"value\":\"MD\"},{\"label\":\"Monaco\",\"value\":\"MC\"},{\"label\":\"Mongolia\",\"value\":\"MN\"},{\"label\":\"Montenegro\",\"value\":\"ME\"},{\"label\":\"Montserrat\",\"value\":\"MS\"},{\"label\":\"Morocco\",\"value\":\"MA\"},{\"label\":\"Mozambique\",\"value\":\"MZ\"},{\"label\":\"Myanmar (Burma)\",\"value\":\"MM\"},{\"label\":\"Namibia\",\"value\":\"NA\"},{\"label\":\"Nauru\",\"value\":\"NR\"},{\"label\":\"Nepal\",\"value\":\"NP\"},{\"label\":\"Netherlands\",\"value\":\"NL\"},{\"label\":\"New Caledonia\",\"value\":\"NC\"},{\"label\":\"New Zealand\",\"value\":\"NZ\"},{\"label\":\"Nicaragua\",\"value\":\"NI\"},{\"label\":\"Niger\",\"value\":\"NE\"},{\"label\":\"Nigeria\",\"value\":\"NG\"},{\"label\":\"Niue\",\"value\":\"NU\"},{\"label\":\"Norfolk Island\",\"value\":\"NF\"},{\"label\":\"North Korea\",\"value\":\"KP\"},{\"label\":\"North Macedonia\",\"value\":\"MK\"},{\"label\":\"Northern Mariana Islands\",\"value\":\"MP\"},{\"label\":\"Norway\",\"value\":\"NO\"},{\"label\":\"Oman\",\"value\":\"OM\"},{\"label\":\"Pakistan\",\"value\":\"PK\"},{\"label\":\"Palau\",\"value\":\"PW\"},{\"label\":\"Palestinian Territories\",\"value\":\"PS\"},{\"label\":\"Panama\",\"value\":\"PA\"},{\"label\":\"Papua New Guinea\",\"value\":\"PG\"},{\"label\":\"Paraguay\",\"value\":\"PY\"},{\"label\":\"Peru\",\"value\":\"PE\"},{\"label\":\"Philippines\",\"value\":\"PH\"},{\"label\":\"Pitcairn Islands\",\"value\":\"PN\"},{\"label\":\"Poland\",\"value\":\"PL\"},{\"label\":\"Portugal\",\"value\":\"PT\"},{\"label\":\"Puerto Rico\",\"value\":\"PR\"},{\"label\":\"Qatar\",\"value\":\"QA\"},{\"label\":\"Réunion\",\"value\":\"RE\"},{\"label\":\"Romania\",\"value\":\"RO\"},{\"label\":\"Russia\",\"value\":\"RU\"},{\"label\":\"Rwanda\",\"value\":\"RW\"},{\"label\":\"Samoa\",\"value\":\"WS\"},{\"label\":\"San Marino\",\"value\":\"SM\"},{\"label\":\"São Tomé & Príncipe\",\"value\":\"ST\"},{\"label\":\"Saudi Arabia\",\"value\":\"SA\"},{\"label\":\"Senegal\",\"value\":\"SN\"},{\"label\":\"Serbia\",\"value\":\"RS\"},{\"label\":\"Seychelles\",\"value\":\"SC\"},{\"label\":\"Sierra Leone\",\"value\":\"SL\"},{\"label\":\"Singapore\",\"value\":\"SG\"},{\"label\":\"Sint Maarten\",\"value\":\"SX\"},{\"label\":\"Slovakia\",\"value\":\"SK\"},{\"label\":\"Slovenia\",\"value\":\"SI\"},{\"label\":\"Solomon Islands\",\"value\":\"SB\"},{\"label\":\"Somalia\",\"value\":\"SO\"},{\"label\":\"South Africa\",\"value\":\"ZA\"},{\"label\":\"South Georgia & South Sandwich Islands\",\"value\":\"GS\"},{\"label\":\"South Korea\",\"value\":\"KR\"},{\"label\":\"South Sudan\",\"value\":\"SS\"},{\"label\":\"Spain\",\"value\":\"ES\"},{\"label\":\"Sri Lanka\",\"value\":\"LK\"},{\"label\":\"St. Barthélemy\",\"value\":\"BL\"},{\"label\":\"St. Helena\",\"value\":\"SH\"},{\"label\":\"St. Kitts & Nevis\",\"value\":\"KN\"},{\"label\":\"St. Lucia\",\"value\":\"LC\"},{\"label\":\"St. Martin\",\"value\":\"MF\"},{\"label\":\"St. Pierre & Miquelon\",\"value\":\"PM\"},{\"label\":\"St. Vincent & Grenadines\",\"value\":\"VC\"},{\"label\":\"Sudan\",\"value\":\"SD\"},{\"label\":\"Suriname\",\"value\":\"SR\"},{\"label\":\"Svalbard & Jan Mayen\",\"value\":\"SJ\"},{\"label\":\"Sweden\",\"value\":\"SE\"},{\"label\":\"Switzerland\",\"value\":\"CH\"},{\"label\":\"Syria\",\"value\":\"SY\"},{\"label\":\"Taiwan\",\"value\":\"TW\"},{\"label\":\"Tajikistan\",\"value\":\"TJ\"},{\"label\":\"Tanzania\",\"value\":\"TZ\"},{\"label\":\"Thailand\",\"value\":\"TH\"},{\"label\":\"Timor-Leste\",\"value\":\"TL\"},{\"label\":\"Togo\",\"value\":\"TG\"},{\"label\":\"Tokelau\",\"value\":\"TK\"},{\"label\":\"Tonga\",\"value\":\"TO\"},{\"label\":\"Trinidad & Tobago\",\"value\":\"TT\"},{\"label\":\"Tristan da Cunha\",\"value\":\"TA\"},{\"label\":\"Tunisia\",\"value\":\"TN\"},{\"label\":\"Türkiye\",\"value\":\"TR\"},{\"label\":\"Turkmenistan\",\"value\":\"TM\"},{\"label\":\"Turks & Caicos Islands\",\"value\":\"TC\"},{\"label\":\"Tuvalu\",\"value\":\"TV\"},{\"label\":\"U.S. Outlying Islands\",\"value\":\"UM\"},{\"label\":\"U.S. Virgin Islands\",\"value\":\"VI\"},{\"label\":\"Uganda\",\"value\":\"UG\"},{\"label\":\"Ukraine\",\"value\":\"UA\"},{\"label\":\"United Arab Emirates\",\"value\":\"AE\"},{\"label\":\"United Kingdom\",\"value\":\"GB\"},{\"label\":\"United States\",\"value\":\"US\"},{\"label\":\"Uruguay\",\"value\":\"UY\"},{\"label\":\"Uzbekistan\",\"value\":\"UZ\"},{\"label\":\"Vanuatu\",\"value\":\"VU\"},{\"label\":\"Vatican City\",\"value\":\"VA\"},{\"label\":\"Venezuela\",\"value\":\"VE\"},{\"label\":\"Vietnam\",\"value\":\"VN\"},{\"label\":\"Wallis & Futuna\",\"value\":\"WF\"},{\"label\":\"Western Sahara\",\"value\":\"EH\"},{\"label\":\"Yemen\",\"value\":\"YE\"},{\"label\":\"Zambia\",\"value\":\"ZM\"},{\"label\":\"Zimbabwe\",\"value\":\"ZW\"}],\"optgroups\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":\"label\",\"matchField\":null,\"visibility\":null,\"optionLabel\":\"full\",\"optionValue\":\"short\",\"placeholder\":\"Select an option\",\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"limitOptions\":false,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":[{\"label\":\"autocomplete\",\"value\":\"country\"},{\"label\":\"data-country\",\"value\":true}],\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:51:39','2026-10-13 20:14:32','b7cecc07-f1a6-4f4f-8cb9-60226c7991c0'),(36,'verbb\\formie\\fields\\Address','Service Address','serviceAddress','{\"enabled\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"contentTable\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Where should the service take place?\",\"labelPosition\":null,\"includeInEmail\":true,\"nestedLayoutId\":8,\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"subFieldLabelPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:51:39','2026-10-13 20:14:32','f9ff335d-8d49-40ce-8218-6106f556dd6e'),(37,'verbb\\formie\\fields\\Checkboxes','Service Types','serviceTypes','{\"max\":null,\"min\":null,\"multi\":true,\"layout\":\"vertical\",\"enabled\":true,\"options\":[{\"label\":\"Inspection\",\"value\":\"Inspection\"},{\"label\":\"Installation\",\"value\":\"Installation\"},{\"label\":\"Repair\",\"value\":\"Repair\"},{\"label\":\"Follow-up\",\"value\":\"Follow-up\"}],\"conditions\":null,\"cssClasses\":null,\"emailValue\":\"label\",\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Select all services that apply.\",\"limitOptions\":false,\"labelPosition\":null,\"includeInEmail\":true,\"toggleCheckbox\":\"top\",\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"toggleCheckboxLabel\":\"All\",\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:51:39','2026-10-13 20:14:32','716529ac-c076-44de-8621-d8d78ab76790'),(38,'verbb\\formie\\fields\\Signature','Signature','signature','{\"enabled\":true,\"penColor\":\"#000000\",\"penWeight\":\"2\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Sign to confirm the request details are correct.\",\"labelPosition\":null,\"includeInEmail\":true,\"backgroundColor\":\"#ffffff\",\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:52:46','2026-10-13 20:14:32','2341e505-37eb-4f65-a6f2-f047c7bfc09a'),(39,'verbb\\formie\\fields\\Dropdown','Item Type','itemType','{\"max\":null,\"min\":null,\"multi\":false,\"layout\":null,\"enabled\":true,\"options\":[{\"label\":\"Select an option\",\"value\":\"\",\"default\":true},{\"label\":\"Inspection\",\"value\":\"Inspection\"},{\"label\":\"Repair\",\"value\":\"Repair\"},{\"label\":\"Installation\",\"value\":\"Installation\"},{\"label\":\"Other\",\"value\":\"Other\"}],\"optgroups\":true,\"conditions\":null,\"cssClasses\":null,\"emailValue\":\"label\",\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"limitOptions\":false,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:54:57','2026-10-13 20:14:32','0e2f7f74-9038-4915-beaa-3fadc06bb23a'),(40,'verbb\\formie\\fields\\SingleLineText','Item Notes','itemNotes','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":null,\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:54:57','2026-10-13 20:14:32','950c38dc-5a92-43be-aac7-69d9a46bbeb9'),(41,'verbb\\formie\\fields\\Repeater','Service Items','serviceItems','{\"enabled\":true,\"maxRows\":null,\"minRows\":null,\"addLabel\":\"Add another row\",\"conditions\":null,\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"contentTable\":null,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Add one or more items that need attention.\",\"labelPosition\":null,\"includeInEmail\":true,\"nestedLayoutId\":9,\"inputAttributes\":null,\"enableConditions\":false,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 03:54:57','2026-10-13 20:14:32','c1740122-ea8d-4a6d-bacc-c6d4b6fef8ec'),(42,'verbb\\formie\\fields\\SingleLineText','Service Type Detail','serviceTypeDetail','{\"max\":null,\"min\":null,\"limit\":false,\"enabled\":true,\"maxType\":\"characters\",\"minType\":\"characters\",\"conditions\":{\"showRule\":\"show\",\"conditions\":[{\"field\":\"{field:efbdfc1a-a716-4d65-977c-ac194048f8a3}\",\"value\":\"Repair\",\"condition\":\"=\",\"legacyForward\":true},{\"field\":\"{field:efbdfc1a-a716-4d65-977c-ac194048f8a3}\",\"value\":\"Follow-up\",\"condition\":\"=\",\"legacyForward\":true}],\"conditionRule\":\"any\",\"version\":1},\"cssClasses\":null,\"emailValue\":null,\"matchField\":null,\"visibility\":null,\"placeholder\":null,\"uniqueValue\":false,\"defaultValue\":null,\"errorMessage\":null,\"instructions\":\"Provide some further detail about the service.\",\"labelPosition\":null,\"includeInEmail\":true,\"inputAttributes\":null,\"enableConditions\":true,\"containerAttributes\":null,\"instructionsPosition\":null,\"enableContentEncryption\":false,\"prefillQueryParam\":null}','2026-03-17 04:00:12','2026-10-13 20:14:33','dc4fb927-0e5c-46f9-beae-2692da60b556');
/*!40000 ALTER TABLE `formie_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_form_fields`
--

DROP TABLE IF EXISTS `formie_form_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_form_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `layoutId` int NOT NULL,
  `pageId` int NOT NULL,
  `rowId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `settings` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `reference` varchar(36) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xyogiywqnmgsmisteowyvcdxndtzakqqusri` (`reference`),
  KEY `idx_enkekztujjnchfmjflkpwnenwmcjyhtquhlv` (`fieldId`),
  KEY `idx_emdxmzptoumnmygfgqebybguxukmacrwtrll` (`layoutId`),
  KEY `idx_bzhohzkazkzooxlhsgufjkgbnvhtqpgwibal` (`pageId`),
  KEY `idx_jsbxmnjqzweptnbrytqlbvroaujojsevtsal` (`rowId`),
  CONSTRAINT `fk_bklgveeiwlnjbmqyrpemgrkpzgeamnhtvxdi` FOREIGN KEY (`pageId`) REFERENCES `formie_fieldlayout_pages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ppzbttbavzoklhukbjfojzepgopqgfshvwsn` FOREIGN KEY (`rowId`) REFERENCES `formie_fieldlayout_rows` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rjdemknzxayrcgakwnvscctqzivzkfygkwvv` FOREIGN KEY (`layoutId`) REFERENCES `formie_fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_utrryukxwlynyoumycptsogcxriejxegygsf` FOREIGN KEY (`fieldId`) REFERENCES `formie_fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_form_fields`
--

LOCK TABLES `formie_form_fields` WRITE;
/*!40000 ALTER TABLE `formie_form_fields` DISABLE KEYS */;
INSERT INTO `formie_form_fields` VALUES (2,2,1,1,2,0,'{\"required\": 1}','8f8eeb25-e701-4112-907d-563aad1f03cd','2026-03-16 13:22:14','2026-03-17 03:33:28','c90b6971-04ae-4b20-bb86-acd0b55771a6'),(3,3,4,4,4,0,'{\"required\": 0}','addb7c63-1cb4-4404-a630-7256483077d6','2026-03-17 03:17:58','2026-03-17 03:17:58','f93d0790-0b3d-437d-bf62-f9f90e95043a'),(4,4,4,4,4,1,'{\"required\": 1}','635c73d3-7bcf-4884-bf6e-f7f34f1375f4','2026-03-17 03:17:58','2026-03-17 03:23:35','e8525540-6d68-4b64-97c1-1ddb330f0ee5'),(5,5,4,4,4,2,'{\"required\": 0}','9ad6aa35-c6fb-41fc-a12d-94d827908144','2026-03-17 03:17:58','2026-03-17 03:17:58','20e3268e-0775-4950-bc94-355dafe5a0c6'),(6,6,4,4,4,3,'{\"required\": 1}','7c47062d-b3f3-4edc-aa91-98864b687337','2026-03-17 03:17:58','2026-03-17 03:23:35','8e26a582-68fa-445e-a3df-b1cfdac1a7f9'),(7,7,2,2,3,0,'{\"required\": 0}','e960ec6f-fd0a-4470-bbf3-7251244c46ff','2026-03-17 03:17:58','2026-03-17 03:17:58','480522ee-f248-482d-9350-aa5a8cd82088'),(8,8,2,2,5,0,'{\"required\": 1}','6beab49e-e3d4-423b-b5e6-549ef02cb900','2026-03-17 03:19:14','2026-03-17 03:23:35','88c96b36-9ccc-4ed4-8266-0b67f3e45a18'),(9,9,2,2,6,0,'{\"required\": 1}','81819aa6-dd73-4da5-9054-0d9ea7f76a6b','2026-03-17 03:19:14','2026-03-17 03:23:35','4338a024-2a51-4761-be21-07c1022f07d0'),(10,10,5,7,8,0,'{\"required\": 0}','b2c4fe38-19bf-4672-ae32-8c2f3ff47f3c','2026-03-17 03:32:01','2026-03-17 03:32:01','7f1d278c-40b2-42bb-aa25-cedf1f64b4a4'),(11,11,5,7,8,1,'{\"required\": 1}','1516f62e-21dc-4313-9418-f7a643787a24','2026-03-17 03:32:01','2026-03-17 03:32:01','8f66d7a8-647b-46eb-99b4-1455b989d947'),(12,12,5,7,8,2,'{\"required\": 0}','274b0bc5-8dc0-4fdc-8d40-47ebbfff6196','2026-03-17 03:32:01','2026-03-17 03:32:01','cb61e911-3f77-4dcd-9c66-797f637f63b2'),(13,13,5,7,8,3,'{\"required\": 1}','16722084-54b2-44d9-860e-1724c9d2495b','2026-03-17 03:32:02','2026-03-17 03:32:02','7514d18a-486d-4612-a539-f0e89bdf9bd4'),(14,14,1,1,7,0,'{\"required\": 0}','c780b5ec-8ecd-4c5c-9087-ce3ec60d4488','2026-03-17 03:32:02','2026-03-17 03:32:02','cb8c60a2-a8ef-4bac-a3a7-bbd5c2189671'),(15,15,1,1,9,0,'{\"required\": 0}','ef2e615d-606c-4343-aef1-b8d1ecfcc325','2026-03-17 03:32:02','2026-03-17 03:33:28','356102d2-873f-49f5-881f-95a9e5b11f36'),(16,16,1,5,10,0,'{\"required\": 1}','0294e400-911d-4b52-bf81-ca8a561045e0','2026-03-17 03:33:28','2026-03-17 03:35:13','298187a9-6fbc-4990-a4a0-b24f7fa116ad'),(17,17,1,5,11,0,'{\"required\": 1}','e8276b8c-9bb4-4399-9f0c-7df3c4c3c486','2026-03-17 03:35:13','2026-03-17 03:35:13','94859897-032c-4a3b-a868-8f283db77dd3'),(18,18,1,5,12,0,'{\"required\": 1}','19b0ce3a-cfb8-447d-a874-ce71264a798a','2026-03-17 03:35:13','2026-03-17 03:35:13','c027e4e0-f160-49f2-95f4-dace67fdb8ec'),(19,19,1,6,13,0,'{\"required\": 0}','80c30671-b0bb-4096-aa9d-f97b96408c21','2026-03-17 03:36:00','2026-03-17 03:36:00','61c6b623-8945-4057-adb0-ba0a616b8eff'),(20,20,6,8,15,0,'{\"required\": 0}','a42c1588-e918-4652-9f51-71ed942484d6','2026-03-17 03:50:17','2026-03-17 03:50:17','4d215330-a1a1-454a-b900-02936c803aa9'),(21,21,6,8,15,1,'{\"required\": 1}','e980b2e7-4794-4776-bf40-853fa5efbbd1','2026-03-17 03:50:17','2026-03-17 03:50:17','8bf346c1-f28d-4b77-a4d1-238aa9e4d660'),(22,22,6,8,15,2,'{\"required\": 0}','79bbd2d3-d533-45bd-82d2-975cb3b8379c','2026-03-17 03:50:17','2026-03-17 03:50:17','8bbb6913-ca8a-49c8-8cbc-dd7c5e7d6fb4'),(23,23,6,8,15,3,'{\"required\": 1}','37a76505-0df6-403c-8bae-c36d0bd4f558','2026-03-17 03:50:17','2026-03-17 03:50:17','43e2310c-89ac-4ced-a2d8-c653a3664696'),(24,24,3,3,14,0,'{\"required\": 0}','a77c65a0-8679-4ca6-aca3-0321ba46b3d9','2026-03-17 03:50:17','2026-03-17 03:50:17','f126f917-3c1e-4e67-b60a-60d8be4bef3b'),(25,25,3,3,16,0,'{\"required\": 0}','9c425fbe-12a9-4fd1-9e94-a20c43ed511d','2026-03-17 03:50:17','2026-03-17 03:55:49','a5a4e204-8f0c-476a-b62c-3e3d8ce1811c'),(26,26,7,10,18,0,'{\"required\": 1}','4ff1e5c3-060f-4520-bf76-2487732573cc','2026-03-17 03:50:17','2026-03-17 03:53:09','f290ebaa-c691-4c8d-b913-5f7abd701450'),(27,27,7,10,18,1,'{\"required\": 0}','04f33f88-745f-4453-a6c7-9305d5c571fd','2026-03-17 03:50:17','2026-03-17 03:53:09','3131dab5-87f4-4f2f-8b8f-3dc3763b343d'),(28,28,3,9,17,0,'{\"required\": 0}','23c302c5-f6ca-4e96-8e31-99d4a5b9df36','2026-03-17 03:50:17','2026-03-17 03:53:09','2cdfc715-1ff6-4547-a582-80027a6167c0'),(29,29,8,13,20,0,'{\"required\": 1}','0a6ec60d-24ee-4cac-9dbd-0b36c776ee25','2026-03-17 03:51:39','2026-03-17 03:53:10','02c0f551-e19c-4763-a6d1-9be98700c99a'),(30,30,8,13,21,0,'{\"required\": 0}','47941293-5363-4653-8d97-b2888b0521bc','2026-03-17 03:51:39','2026-03-17 03:51:39','d721dcc5-06d7-48b7-bd3f-262148ed460b'),(31,31,8,13,22,0,'{\"required\": 0}','c7d4755e-66a4-408e-ba8e-dd66238d4d82','2026-03-17 03:51:39','2026-03-17 03:51:39','902c642a-c03a-4f9b-bc00-e79169961559'),(32,32,8,13,23,0,'{\"required\": 1}','166c1c24-e26e-4438-b88a-dbe52bc988ae','2026-03-17 03:51:39','2026-03-17 03:53:10','eeae8b69-0b8a-4fea-ad69-c51508515cf9'),(33,33,8,13,23,1,'{\"required\": 1}','4e3ff2a2-a06c-447a-b353-771ab0392dec','2026-03-17 03:51:39','2026-03-17 03:53:10','666835d6-d105-4641-9fea-dbef6645e0c1'),(34,34,8,13,24,0,'{\"required\": 0}','daf735b0-39d0-42ee-86bb-d801da424fda','2026-03-17 03:51:39','2026-03-17 03:51:39','ace84e2f-3b7d-4798-8d8a-65eef4087cca'),(35,35,8,13,24,1,'{\"required\": 1}','23607391-898f-4615-b550-c8c862a68321','2026-03-17 03:51:39','2026-03-17 03:53:10','b7cecc07-f1a6-4f4f-8cb9-60226c7991c0'),(36,36,3,9,19,0,'{\"required\": 0}','f9e5984d-35b6-406a-b2c2-73caa7090800','2026-03-17 03:51:39','2026-03-17 03:51:39','f9ff335d-8d49-40ce-8218-6106f556dd6e'),(37,37,3,9,25,0,'{\"required\": 1}','efbdfc1a-a716-4d65-977c-ac194048f8a3','2026-03-17 03:51:39','2026-03-17 03:53:19','716529ac-c076-44de-8621-d8d78ab76790'),(38,38,3,12,26,0,'{\"required\": 1}','a2d97396-9c41-4fb7-b929-61e71a2468d2','2026-03-17 03:52:46','2026-03-17 03:52:46','2341e505-37eb-4f65-a6f2-f047c7bfc09a'),(39,39,9,14,28,0,'{\"required\": 0}','cea6964c-17cb-4277-af5c-a52ca11ec848','2026-03-17 03:54:57','2026-03-17 03:54:57','0e2f7f74-9038-4915-beaa-3fadc06bb23a'),(40,40,9,14,28,1,'{\"required\": 0}','dba314fd-ca0a-46f9-97b3-491e4c9706df','2026-03-17 03:54:57','2026-03-17 03:54:57','950c38dc-5a92-43be-aac7-69d9a46bbeb9'),(41,41,3,11,27,0,'{\"required\": 0}','e0238fee-583a-41d6-93c3-5553f5393c16','2026-03-17 03:54:57','2026-03-17 03:54:57','c1740122-ea8d-4a6d-bacc-c6d4b6fef8ec'),(42,42,3,9,29,0,'{\"required\": 0}','26173ecf-eb03-42e4-8278-36e0725a45f4','2026-03-17 04:00:12','2026-03-17 04:00:12','dc4fb927-0e5c-46f9-beae-2692da60b556');
/*!40000 ALTER TABLE `formie_form_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_form_site_overrides`
--

DROP TABLE IF EXISTS `formie_form_site_overrides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_form_site_overrides` (
  `id` int NOT NULL AUTO_INCREMENT,
  `formId` int NOT NULL,
  `siteId` int NOT NULL,
  `overrides` json NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zbpvkbbwqmjymwceirssryaspqjhioqkuzih` (`formId`,`siteId`),
  KEY `idx_xmkoajkdevttvmrfedndpkiavwxpmhtchwys` (`siteId`),
  CONSTRAINT `fk_vbsbsrfkhmikjqvgvnwsfckuyozntbdpfmwq` FOREIGN KEY (`formId`) REFERENCES `formie_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zruybtrypicjjpdvflztqnolryqmglyzdklo` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_form_site_overrides`
--

LOCK TABLES `formie_form_site_overrides` WRITE;
/*!40000 ALTER TABLE `formie_form_site_overrides` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_form_site_overrides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_form_statuses`
--

DROP TABLE IF EXISTS `formie_form_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_form_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `color` enum('green','orange','red','blue','yellow','pink','purple','turquoise','light','grey','black') NOT NULL DEFAULT 'green',
  `description` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `isDefault` tinyint(1) DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_form_statuses`
--

LOCK TABLES `formie_form_statuses` WRITE;
/*!40000 ALTER TABLE `formie_form_statuses` DISABLE KEYS */;
INSERT INTO `formie_form_statuses` VALUES (1,'Active','active','turquoise',NULL,1,1,NULL,'2026-10-13 20:13:29','2026-10-13 20:13:29','614368ed-97b8-481a-a515-a102fb8f0537'),(2,'Draft','draft','orange',NULL,2,0,NULL,'2026-10-13 20:13:29','2026-10-13 20:13:29','4654273e-e095-4a0f-8fd7-f02f57a0174a'),(3,'Archived','archived','grey',NULL,3,0,NULL,'2026-10-13 20:13:29','2026-10-13 20:13:29','2b0409e9-cb72-417d-b656-da63f03f9c04');
/*!40000 ALTER TABLE `formie_form_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_formgroups`
--

DROP TABLE IF EXISTS `formie_formgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_formgroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_formgroups`
--

LOCK TABLES `formie_formgroups` WRITE;
/*!40000 ALTER TABLE `formie_formgroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_formgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_forms`
--

DROP TABLE IF EXISTS `formie_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_forms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `settings` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `layoutId` int DEFAULT NULL,
  `templateId` int DEFAULT NULL,
  `groupId` int DEFAULT NULL,
  `formStatusId` int DEFAULT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `redirectEntryId` int DEFAULT NULL,
  `redirectEntrySiteId` int DEFAULT NULL,
  `defaultStatusId` int DEFAULT NULL,
  `dataRetention` enum('forever','minutes','hours','days','weeks','months','years') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'forever',
  `dataRetentionValue` int DEFAULT NULL,
  `userDeletedAction` enum('retain','delete') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'retain',
  `fileUploadsAction` enum('retain','delete') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'retain',
  `createdById` int DEFAULT NULL,
  `updatedById` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mmfuzwyxzbukzlqzhxvgzhjhohwrgiociavj` (`layoutId`),
  KEY `idx_jgbwkylcssiaxkjlpcjxznwypclfxymyahoj` (`templateId`),
  KEY `idx_ehmpoangyvtpmdcqymckigyxxpyhahqnpubm` (`defaultStatusId`),
  KEY `idx_ivzuacpzpsiwbjlpokwedwggvctxatwbriyz` (`redirectEntryId`),
  KEY `idx_gkfrdumdsajtjsygdjbcldtvnutrtgfxlodg` (`redirectEntrySiteId`),
  KEY `idx_vkvutyttljmzqkazlgbkikfrkzbvmtfelqux` (`createdById`),
  KEY `idx_bpklwooolniiecxewchxbvcygtmwtrcewxkv` (`updatedById`),
  KEY `idx_btphwpqeopjhnpqvlxsdykujfxyptvzhredj` (`groupId`),
  KEY `idx_jhytuwudmgqnrxcdrjpjfvklyoejtjjkehuz` (`sourceSiteId`),
  KEY `idx_gzaviqrejlwafytpnxhhvrkdeaplmcsynobc` (`formStatusId`),
  CONSTRAINT `fk_brsphsutnwrheilnpgwwaxcaclgoiqdmgolg` FOREIGN KEY (`createdById`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ehjwdnrttbflyijbjtkpaokxiehfctrvkrgc` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_gobdwcbddieojbaeobxtuqamslhzxzeoxobf` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gocpbwvjpskwgnguqbjaydihhfavrdhfohyg` FOREIGN KEY (`redirectEntryId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hzyonbzufxckeeprjthhlzyttrtmdonfekfr` FOREIGN KEY (`templateId`) REFERENCES `formie_formtemplates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_loqqgzxvhggkyymbnwpziebknaeneaiyupzd` FOREIGN KEY (`groupId`) REFERENCES `formie_formgroups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ovafytuxppoxwzhjbkttktimamtsdyugwomk` FOREIGN KEY (`formStatusId`) REFERENCES `formie_form_statuses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qpdheltqftzdxrctnqxhhukiwylnicywqeyt` FOREIGN KEY (`updatedById`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vxuwvivcmzripxrbzwdsndgynckkprxzdvkm` FOREIGN KEY (`layoutId`) REFERENCES `formie_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yamskhhskaocozjbxasyfvejyaonaraonaof` FOREIGN KEY (`defaultStatusId`) REFERENCES `formie_submission_statuses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_forms`
--

LOCK TABLES `formie_forms` WRITE;
/*!40000 ALTER TABLE `formie_forms` DISABLE KEYS */;
INSERT INTO `formie_forms` VALUES (2,'singlePage','{\"displayFormTitle\":false,\"displayCurrentPageTitle\":false,\"displayPageTabs\":false,\"displayPageProgress\":false,\"scrollToTop\":true,\"progressCalculation\":\"completion\",\"progressPosition\":\"end\",\"progressValuePosition\":\"inside-center\",\"defaultLabelPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"defaultInstructionsPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"requiredIndicator\":\"asterisk\",\"submitMethod\":\"ajax\",\"automaticSubmissionState\":true,\"loadingIndicator\":\"spinner\",\"loadingIndicatorText\":null,\"validationOnSubmit\":true,\"validationOnFocus\":false,\"errorMessage\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Couldn’t save submission due to errors.\"}]}],\"errorMessagePosition\":\"top-form\",\"requireUser\":false,\"requireUserMessage\":[],\"scheduleForm\":false,\"scheduleFormStart\":null,\"scheduleFormEnd\":null,\"scheduleFormPendingMessage\":[],\"scheduleFormExpiredMessage\":[],\"limitSubmissions\":null,\"limitSubmissionsNumber\":null,\"limitSubmissionsType\":\"total\",\"limitSubmissionsMessage\":[],\"limitSubmissionsIpAddressNumber\":null,\"limitSubmissionsIpAddressType\":null,\"limitSubmissionsIpAddressMessage\":[],\"integrations\":[],\"submissionTitleFormat\":\"{timestamp}\",\"collectIp\":false,\"collectUser\":false,\"dataRetention\":null,\"dataRetentionValue\":null,\"fileUploadsAction\":null,\"redirectUrl\":null,\"pageRedirectUrl\":null,\"defaultEmailTemplateId\":null,\"disableCaptchas\":false,\"redirectTarget\":\"same-tab\",\"hideFormAfterSubmit\":false,\"successMessage\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Submission saved.\"}]}],\"successMessageTimeout\":null,\"successMessagePosition\":\"top-form\",\"completionBehavior\":\"message\",\"completionRedirectSource\":\"url\"}',2,NULL,NULL,1,NULL,NULL,NULL,1,'forever',NULL,'retain','retain',NULL,NULL,'2026-06-02 11:29:10','2026-10-13 20:14:31','323a64f4-9186-4182-ab2d-c84c4e51738c'),(3,'multiPage','{\"displayFormTitle\":true,\"displayCurrentPageTitle\":true,\"displayPageTabs\":true,\"displayPageProgress\":true,\"scrollToTop\":true,\"progressCalculation\":\"completion\",\"progressPosition\":\"end\",\"progressValuePosition\":\"inside-center\",\"defaultLabelPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"defaultInstructionsPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"requiredIndicator\":\"asterisk\",\"submitMethod\":\"ajax\",\"automaticSubmissionState\":true,\"loadingIndicator\":\"spinner\",\"loadingIndicatorText\":null,\"validationOnSubmit\":true,\"validationOnFocus\":false,\"errorMessage\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Couldn’t save submission due to errors.\"}]}],\"errorMessagePosition\":\"top-form\",\"requireUser\":false,\"requireUserMessage\":[],\"scheduleForm\":false,\"scheduleFormStart\":null,\"scheduleFormEnd\":null,\"scheduleFormPendingMessage\":[],\"scheduleFormExpiredMessage\":[],\"limitSubmissions\":null,\"limitSubmissionsNumber\":null,\"limitSubmissionsType\":\"total\",\"limitSubmissionsMessage\":[],\"limitSubmissionsIpAddressNumber\":null,\"limitSubmissionsIpAddressType\":null,\"limitSubmissionsIpAddressMessage\":[],\"integrations\":[],\"submissionTitleFormat\":\"{timestamp}\",\"collectIp\":false,\"collectUser\":false,\"dataRetention\":null,\"dataRetentionValue\":null,\"fileUploadsAction\":null,\"redirectUrl\":null,\"pageRedirectUrl\":null,\"defaultEmailTemplateId\":null,\"disableCaptchas\":false,\"redirectTarget\":\"same-tab\",\"hideFormAfterSubmit\":false,\"successMessage\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Submission saved.\"}]}],\"successMessageTimeout\":null,\"successMessagePosition\":\"top-form\",\"completionBehavior\":\"message\",\"completionRedirectSource\":\"url\"}',1,NULL,NULL,1,NULL,NULL,NULL,1,'forever',NULL,'retain','retain',NULL,NULL,'2026-06-02 11:29:10','2026-10-13 20:14:31','2c000ec1-d33a-4059-9736-8aa6f5c1c944'),(4,'advanced','{\"displayFormTitle\":false,\"displayCurrentPageTitle\":false,\"displayPageTabs\":true,\"displayPageProgress\":true,\"scrollToTop\":true,\"progressCalculation\":\"completion\",\"progressPosition\":\"start\",\"progressValuePosition\":\"inside-center\",\"defaultLabelPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"defaultInstructionsPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"requiredIndicator\":\"asterisk\",\"submitMethod\":\"ajax\",\"automaticSubmissionState\":true,\"loadingIndicator\":\"spinner\",\"loadingIndicatorText\":null,\"validationOnSubmit\":true,\"validationOnFocus\":false,\"errorMessage\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Couldn’t save submission due to errors.\"}]}],\"errorMessagePosition\":\"top-form\",\"requireUser\":false,\"requireUserMessage\":[],\"scheduleForm\":false,\"scheduleFormStart\":null,\"scheduleFormEnd\":null,\"scheduleFormPendingMessage\":[],\"scheduleFormExpiredMessage\":[],\"limitSubmissions\":null,\"limitSubmissionsNumber\":null,\"limitSubmissionsType\":\"total\",\"limitSubmissionsMessage\":[],\"limitSubmissionsIpAddressNumber\":null,\"limitSubmissionsIpAddressType\":null,\"limitSubmissionsIpAddressMessage\":[],\"integrations\":[],\"submissionTitleFormat\":\"{timestamp}\",\"collectIp\":false,\"collectUser\":false,\"dataRetention\":null,\"dataRetentionValue\":null,\"fileUploadsAction\":null,\"redirectUrl\":null,\"pageRedirectUrl\":null,\"defaultEmailTemplateId\":null,\"disableCaptchas\":false,\"redirectTarget\":\"same-tab\",\"hideFormAfterSubmit\":false,\"successMessage\":[{\"type\":\"paragraph\",\"content\":[{\"type\":\"text\",\"text\":\"Submission saved.\"}]}],\"successMessageTimeout\":null,\"successMessagePosition\":\"top-form\",\"completionBehavior\":\"message\",\"completionRedirectSource\":\"url\"}',3,NULL,NULL,1,NULL,NULL,NULL,1,'forever',NULL,'retain','retain',NULL,NULL,'2026-06-02 11:29:10','2026-10-13 20:14:31','b2d618a5-b7be-4593-9aae-67c812fd0417');
/*!40000 ALTER TABLE `formie_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_formtemplates`
--

DROP TABLE IF EXISTS `formie_formtemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_formtemplates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `template` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `useCustomTemplates` tinyint(1) DEFAULT '1',
  `outputCss` tinyint(1) DEFAULT '1',
  `outputJs` tinyint(1) DEFAULT '1',
  `outputCssLocation` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `outputJsLocation` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gquuypwykkyjpinbjklohnslpdgepibuglga` (`fieldLayoutId`),
  CONSTRAINT `fk_hprhxlgdrwlpkwibwcwawpniknolkzvpwmhb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_formtemplates`
--

LOCK TABLES `formie_formtemplates` WRITE;
/*!40000 ALTER TABLE `formie_formtemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_formtemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_instance_configs`
--

DROP TABLE IF EXISTS `formie_instance_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_instance_configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tokenHash` varchar(64) NOT NULL,
  `formId` int NOT NULL,
  `siteId` int NOT NULL,
  `config` mediumtext NOT NULL,
  `expiresAt` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kznxlvhkagksnqpggmyyauktjykyxskueqan` (`tokenHash`),
  KEY `idx_ieuhpwyygumqrmzurfqrjkpclsmkjookuwme` (`expiresAt`),
  KEY `fk_zkueghceejkjwjlpsmrzizlkarpxfwkgjodo` (`formId`),
  CONSTRAINT `fk_zkueghceejkjwjlpsmrzizlkarpxfwkgjodo` FOREIGN KEY (`formId`) REFERENCES `formie_forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_instance_configs`
--

LOCK TABLES `formie_instance_configs` WRITE;
/*!40000 ALTER TABLE `formie_instance_configs` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_instance_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_integration_run_contexts`
--

DROP TABLE IF EXISTS `formie_integration_run_contexts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_integration_run_contexts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `submissionId` int NOT NULL,
  `runUid` varchar(255) NOT NULL,
  `context` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jukgqmqzhmcvxcjwrhrpsovlopqbgnmsrsdw` (`submissionId`,`runUid`),
  CONSTRAINT `fk_shotokfsvewcwomiyexunplrsbzfdbidhnir` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_integration_run_contexts`
--

LOCK TABLES `formie_integration_run_contexts` WRITE;
/*!40000 ALTER TABLE `formie_integration_run_contexts` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_integration_run_contexts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_integrations`
--

DROP TABLE IF EXISTS `formie_integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_integrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scope` varchar(16) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'project',
  `type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `enabled` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'true',
  `settings` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `cache` longtext COLLATE utf8mb4_unicode_520_ci,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_integrations`
--

LOCK TABLES `formie_integrations` WRITE;
/*!40000 ALTER TABLE `formie_integrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_integrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_notifications`
--

DROP TABLE IF EXISTS `formie_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `formId` int NOT NULL,
  `templateId` int DEFAULT NULL,
  `pdfTemplateId` int DEFAULT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `subject` text COLLATE utf8mb4_unicode_520_ci,
  `recipients` enum('email','conditions') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'email',
  `to` text COLLATE utf8mb4_unicode_520_ci,
  `toConditions` text COLLATE utf8mb4_unicode_520_ci,
  `cc` text COLLATE utf8mb4_unicode_520_ci,
  `bcc` text COLLATE utf8mb4_unicode_520_ci,
  `replyTo` text COLLATE utf8mb4_unicode_520_ci,
  `replyToName` text COLLATE utf8mb4_unicode_520_ci,
  `from` text COLLATE utf8mb4_unicode_520_ci,
  `fromName` text COLLATE utf8mb4_unicode_520_ci,
  `sender` text COLLATE utf8mb4_unicode_520_ci,
  `content` text COLLATE utf8mb4_unicode_520_ci,
  `attachFiles` tinyint(1) DEFAULT '1',
  `attachPdf` tinyint(1) DEFAULT '0',
  `attachAssets` text COLLATE utf8mb4_unicode_520_ci,
  `enableConditions` tinyint(1) DEFAULT '0',
  `conditions` text COLLATE utf8mb4_unicode_520_ci,
  `dispatchTiming` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'default',
  `customSettings` text COLLATE utf8mb4_unicode_520_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hgdvvpceeykjwgcqrkaolhlztxjtnyflyoww` (`formId`),
  KEY `idx_airgvcroouakdalczzbfdxgpsazpwgmlhygi` (`templateId`),
  KEY `fk_kfclnkixnhofwcatoipzevhivefizucqsxhe` (`pdfTemplateId`),
  CONSTRAINT `fk_kfclnkixnhofwcatoipzevhivefizucqsxhe` FOREIGN KEY (`pdfTemplateId`) REFERENCES `formie_pdftemplates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wqjbwgzwvjiocmnaayxbjakxwemaeiyzccyz` FOREIGN KEY (`templateId`) REFERENCES `formie_emailtemplates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wzrootwtxevqihcfmtykfmnpgveosyihxibf` FOREIGN KEY (`formId`) REFERENCES `formie_forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_notifications`
--

LOCK TABLES `formie_notifications` WRITE;
/*!40000 ALTER TABLE `formie_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_paymentcapabilities`
--

DROP TABLE IF EXISTS `formie_paymentcapabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_paymentcapabilities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tokenHash` char(64) NOT NULL,
  `purpose` varchar(32) NOT NULL,
  `resourceId` int NOT NULL,
  `scope` text NOT NULL,
  `expiresAt` int NOT NULL,
  `revokedAt` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ntblobpuexwdvrkbqpkpfkndoxjtnfuhilmf` (`tokenHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_paymentcapabilities`
--

LOCK TABLES `formie_paymentcapabilities` WRITE;
/*!40000 ALTER TABLE `formie_paymentcapabilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_paymentcapabilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_payments`
--

DROP TABLE IF EXISTS `formie_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `integrationId` int DEFAULT NULL,
  `submissionId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `subscriptionId` int DEFAULT NULL,
  `amount` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci,
  `redirectUrl` text COLLATE utf8mb4_unicode_520_ci,
  `note` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `response` text COLLATE utf8mb4_unicode_520_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `version` int NOT NULL DEFAULT '0',
  `history` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `scope` text COLLATE utf8mb4_unicode_520_ci,
  `idempotencyKey` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastReconciledAt` bigint DEFAULT NULL,
  `nextReconcileAt` bigint DEFAULT NULL,
  `reconciliationAttempts` int NOT NULL DEFAULT '0',
  `amountMinor` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountFingerprint` char(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bbazhdqdhtmkxfuelmjnbrdehbpxyjkgnfry` (`idempotencyKey`),
  KEY `idx_svckbzelmugbmaapuhimxpixevncmxqlvcvd` (`integrationId`),
  KEY `idx_nwqbezpsumcapvhceibpdopxccztzsnfkndq` (`fieldId`),
  KEY `idx_ylibyuwmvicezhnvoepuqzhiwpjaxuenebeo` (`reference`),
  KEY `fk_cbcjqtfpoaladnbtlenyzzmayouibyuqqyrc` (`submissionId`),
  KEY `fk_ubpvshehhwiatrmqxxabovlfzqkbxknkdxgk` (`subscriptionId`),
  KEY `formie_payments_account_reference` (`integrationId`,`accountFingerprint`,`reference`),
  CONSTRAINT `fk_narlkoeeiprnmsyylvvxhoklusblozzxxjjz` FOREIGN KEY (`subscriptionId`) REFERENCES `formie_payments_subscriptions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_nqtfpyinvghspdwfyicvihfqpzcnaijkapwp` FOREIGN KEY (`integrationId`) REFERENCES `formie_integrations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qwrwsxdnvdmxyxityygnxuxnnlpwihxqwtty` FOREIGN KEY (`fieldId`) REFERENCES `formie_form_fields` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wxrsvksknrusfwcvztoxwbyhychwmrlfkbpz` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_payments`
--

LOCK TABLES `formie_payments` WRITE;
/*!40000 ALTER TABLE `formie_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_payments_plans`
--

DROP TABLE IF EXISTS `formie_payments_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_payments_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `integrationId` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `planData` text COLLATE utf8mb4_unicode_520_ci,
  `isArchived` tinyint(1) NOT NULL,
  `dateArchived` datetime DEFAULT NULL,
  `sortOrder` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `accountFingerprint` char(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `amountMinor` varchar(80) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `currency` varchar(3) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `interval` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `intervalCount` int NOT NULL DEFAULT '1',
  `providerStatus` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lswlblmdeyrcdawkwjgvnzrlvswxdwwqzqsm` (`integrationId`),
  KEY `idx_uzyxhizyibuwuyhasxrprvxfhjivzdrzplwe` (`reference`),
  KEY `formie_payments_plans_account_reference` (`integrationId`,`accountFingerprint`,`reference`),
  CONSTRAINT `fk_hnjwlogmkcchzsuoteczgbdopcmyvxsogfql` FOREIGN KEY (`integrationId`) REFERENCES `formie_integrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_payments_plans`
--

LOCK TABLES `formie_payments_plans` WRITE;
/*!40000 ALTER TABLE `formie_payments_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_payments_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_payments_subscriptions`
--

DROP TABLE IF EXISTS `formie_payments_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_payments_subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `integrationId` int DEFAULT NULL,
  `submissionId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `planId` int DEFAULT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `trialDays` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `version` int NOT NULL DEFAULT '0',
  `history` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `scope` text COLLATE utf8mb4_unicode_520_ci,
  `idempotencyKey` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'unknown',
  `archivedAt` datetime DEFAULT NULL,
  `providerUpdatedAt` bigint DEFAULT NULL,
  `providerStatus` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `startedAt` datetime DEFAULT NULL,
  `trialStartsAt` datetime DEFAULT NULL,
  `trialEndsAt` datetime DEFAULT NULL,
  `currentPeriodStartsAt` datetime DEFAULT NULL,
  `currentPeriodEndsAt` datetime DEFAULT NULL,
  `nextPaymentAt` datetime DEFAULT NULL,
  `pausedAt` datetime DEFAULT NULL,
  `cancelAt` datetime DEFAULT NULL,
  `cancelledAt` datetime DEFAULT NULL,
  `endedAt` datetime DEFAULT NULL,
  `cancellationMode` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountFingerprint` char(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `terms` text COLLATE utf8mb4_unicode_520_ci,
  `providerData` text COLLATE utf8mb4_unicode_520_ci,
  `lastSyncedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_aaihwouvomazkmnfhuvvmwxnjbzaxxhpeeqe` (`idempotencyKey`),
  KEY `idx_stifnjyjiemkfhcuibyvnbnopdcuzdklgjjy` (`integrationId`),
  KEY `idx_gsidtqthvuqlhuootbgprqgloiykclblccqe` (`submissionId`),
  KEY `idx_rkxympayzcsuhgodanzdhjgnfskusidqyqay` (`fieldId`),
  KEY `idx_vgtdrunkemfjldwgpfupgfrvuepyomrneiym` (`planId`),
  KEY `idx_nccxzopmpzfxvqdvdthcejxefusezpwqjdtl` (`reference`),
  KEY `idx_okpknffukoaiplxcbahaofccvuldrowwcpbf` (`nextPaymentAt`),
  KEY `idx_jgppfohbsztvzznlmubvvynyqendwrvkdiea` (`cancelAt`),
  KEY `idx_sjkxsbmsojrkzmmibbsmeofkqqisggmgroyw` (`endedAt`),
  KEY `formie_payments_subscriptions_account_reference` (`integrationId`,`accountFingerprint`,`reference`),
  CONSTRAINT `fk_aumceuuvylbmzrfquuyoqsgiqzkdsfbjjbdv` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_corxxrtmdtutyiexyagecrubnoxrtqzbdcbd` FOREIGN KEY (`integrationId`) REFERENCES `formie_integrations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_dpefuunzphnxpoixzetfgdgagdwjvlbuqjer` FOREIGN KEY (`fieldId`) REFERENCES `formie_form_fields` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vmxiywasysipzxcdmjajdoizvkezhbytagdx` FOREIGN KEY (`planId`) REFERENCES `formie_payments_plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_payments_subscriptions`
--

LOCK TABLES `formie_payments_subscriptions` WRITE;
/*!40000 ALTER TABLE `formie_payments_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_payments_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_pdftemplates`
--

DROP TABLE IF EXISTS `formie_pdftemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_pdftemplates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `template` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `filenameFormat` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_pdftemplates`
--

LOCK TABLES `formie_pdftemplates` WRITE;
/*!40000 ALTER TABLE `formie_pdftemplates` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_pdftemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_pending_uploads`
--

DROP TABLE IF EXISTS `formie_pending_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_pending_uploads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `formId` int DEFAULT NULL,
  `submissionId` int DEFAULT NULL,
  `fieldUid` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isFinalized` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `state` varchar(16) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'staged',
  `siteId` int DEFAULT NULL,
  `browserHash` char(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `contentKey` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `progressId` int DEFAULT NULL,
  `expiresAt` int DEFAULT NULL,
  `capabilities` text COLLATE utf8mb4_unicode_520_ci,
  `promotionFolderId` int DEFAULT NULL,
  `promotionFilename` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `promotionSourceFolderId` int DEFAULT NULL,
  `contentHash` char(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `promotionState` varchar(16) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `failureCode` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lzjuyrrcqlsoybnujygumcyldpqxklvsqoly` (`assetId`),
  KEY `idx_mnukstnnszoykebvnzfxwwutdthixibvnpvk` (`submissionId`),
  KEY `idx_ezddigihuhyafzhricfqkscvkptkgvqmgkte` (`isFinalized`,`dateUpdated`),
  CONSTRAINT `fk_ddntlrncmbveqzutpvtastszjytefbxiabxf` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uirecxdxikvjsbawdbreljwzyzjchesybeyt` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_pending_uploads`
--

LOCK TABLES `formie_pending_uploads` WRITE;
/*!40000 ALTER TABLE `formie_pending_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_pending_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_relations`
--

DROP TABLE IF EXISTS `formie_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wvlquqwfkjwmhycjgfwwcnbisjfqanvxocnk` (`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_bnqmfnvowsgrenovwakaracksegyveizycbo` (`sourceId`),
  KEY `idx_hhbsqkaiwxqfudxdiityegyppfemdklcmunp` (`targetId`),
  KEY `idx_hxtwgzxiiuuyytdxdqakyfljhhsqkpalugag` (`sourceSiteId`),
  CONSTRAINT `fk_gcrcrmkkestyhdiybsndeguddmntaxgonhok` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jkzpfewpjpfcxevbzladkybgdtxwygqaxwwy` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ykndgedlzjddssymntlrjapzdwoulhdhdood` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_relations`
--

LOCK TABLES `formie_relations` WRITE;
/*!40000 ALTER TABLE `formie_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_report_exports`
--

DROP TABLE IF EXISTS `formie_report_exports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_report_exports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reportId` int NOT NULL,
  `userId` int DEFAULT NULL,
  `scheduledReportId` int DEFAULT NULL,
  `source` varchar(32) NOT NULL DEFAULT 'interactive',
  `status` varchar(32) NOT NULL DEFAULT 'pending',
  `format` varchar(16) NOT NULL DEFAULT 'csv',
  `context` text,
  `filename` varchar(255) DEFAULT NULL,
  `filePath` varchar(255) DEFAULT NULL,
  `fileSize` bigint unsigned DEFAULT NULL,
  `downloadUrl` text,
  `downloadTokenHash` char(64) DEFAULT NULL,
  `notifyEmail` varchar(255) DEFAULT NULL,
  `error` text,
  `dateExpires` datetime DEFAULT NULL,
  `dateDownloaded` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fptuhhgckjrgkvznrhfmuibsfxmjovimdsud` (`reportId`),
  KEY `idx_ssmipeaqtsavevdlpavqkjsvjjuqcllxjmwl` (`status`),
  KEY `idx_dyjggxinhccecpskaoljgmiwitmsztjgeuch` (`dateExpires`),
  CONSTRAINT `fk_euflpyylunkanxvnjosjpklygvyastmiualm` FOREIGN KEY (`reportId`) REFERENCES `formie_reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_report_exports`
--

LOCK TABLES `formie_report_exports` WRITE;
/*!40000 ALTER TABLE `formie_report_exports` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_report_exports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_reports`
--

DROP TABLE IF EXISTS `formie_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lhlyjenjijuwhyzukpuzuypndcbvtdmhwfkf` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_reports`
--

LOCK TABLES `formie_reports` WRITE;
/*!40000 ALTER TABLE `formie_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_scheduled_reports`
--

DROP TABLE IF EXISTS `formie_scheduled_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_scheduled_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reportId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `lastSentAt` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nvwupjxloqhdytymdjmzfhwscjsavgbpuasb` (`reportId`),
  CONSTRAINT `fk_mqngiyyhedbqmfhgjowwyhphtqvlxtucjpwe` FOREIGN KEY (`reportId`) REFERENCES `formie_reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_scheduled_reports`
--

LOCK TABLES `formie_scheduled_reports` WRITE;
/*!40000 ALTER TABLE `formie_scheduled_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_scheduled_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_sentnotifications`
--

DROP TABLE IF EXISTS `formie_sentnotifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_sentnotifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `formId` int DEFAULT NULL,
  `submissionId` int DEFAULT NULL,
  `notificationId` int DEFAULT NULL,
  `subject` text COLLATE utf8mb4_unicode_520_ci,
  `to` text COLLATE utf8mb4_unicode_520_ci,
  `cc` text COLLATE utf8mb4_unicode_520_ci,
  `bcc` text COLLATE utf8mb4_unicode_520_ci,
  `replyTo` text COLLATE utf8mb4_unicode_520_ci,
  `replyToName` text COLLATE utf8mb4_unicode_520_ci,
  `from` text COLLATE utf8mb4_unicode_520_ci,
  `fromName` text COLLATE utf8mb4_unicode_520_ci,
  `sender` text COLLATE utf8mb4_unicode_520_ci,
  `body` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `htmlBody` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `info` text COLLATE utf8mb4_unicode_520_ci,
  `success` tinyint(1) DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci,
  `dateCreated` datetime DEFAULT NULL,
  `dateUpdated` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_umqywkewsvqofmrozfkmfvjusttspigkawqk` (`formId`),
  KEY `fk_jrvqntbawpuoaqadutegryhzuvjpearnpqoo` (`submissionId`),
  KEY `fk_ztiokbtemapdiapkbacbzjlvrtzjovhweiop` (`notificationId`),
  CONSTRAINT `fk_jrvqntbawpuoaqadutegryhzuvjpearnpqoo` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_klidziccnbqykbwmcxmpsjkobquusazfocig` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_umqywkewsvqofmrozfkmfvjusttspigkawqk` FOREIGN KEY (`formId`) REFERENCES `formie_forms` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ztiokbtemapdiapkbacbzjlvrtzjovhweiop` FOREIGN KEY (`notificationId`) REFERENCES `formie_notifications` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_sentnotifications`
--

LOCK TABLES `formie_sentnotifications` WRITE;
/*!40000 ALTER TABLE `formie_sentnotifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_sentnotifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_spam_settings`
--

DROP TABLE IF EXISTS `formie_spam_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_spam_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `scope` varchar(16) NOT NULL DEFAULT 'project',
  `saveSpam` tinyint(1) NOT NULL DEFAULT '1',
  `spamLimit` int NOT NULL DEFAULT '500',
  `spamEmailNotifications` tinyint(1) NOT NULL DEFAULT '0',
  `spamBehaviour` varchar(255) NOT NULL DEFAULT 'showSuccess',
  `spamBehaviourMessage` text,
  `spamKeywords` mediumtext,
  `enableHoneypot` tinyint(1) NOT NULL DEFAULT '1',
  `honeypotFieldName` varchar(255) NOT NULL DEFAULT 'formieHoneypot',
  `enableMinimumSubmitTime` tinyint(1) NOT NULL DEFAULT '1',
  `minimumSubmitTime` int NOT NULL DEFAULT '3',
  `enableReplayProtection` tinyint(1) NOT NULL DEFAULT '1',
  `enableBlockedEmailDomains` tinyint(1) NOT NULL DEFAULT '0',
  `blockedEmailDomains` mediumtext,
  `enableBlockFreeEmailDomains` tinyint(1) NOT NULL DEFAULT '0',
  `enableAllowedEmailDomains` tinyint(1) NOT NULL DEFAULT '0',
  `allowedEmailDomains` mediumtext,
  `enableFormSubmitExpiration` tinyint(1) NOT NULL DEFAULT '0',
  `formSubmitExpiration` int NOT NULL DEFAULT '86400',
  `enableSuspiciousTextDetection` tinyint(1) NOT NULL DEFAULT '0',
  `suspiciousTextAllowedTerms` mediumtext,
  `enableMaximumLinks` tinyint(1) NOT NULL DEFAULT '0',
  `maximumLinks` int NOT NULL DEFAULT '10',
  `enableGlobalSubmissionThrottling` tinyint(1) NOT NULL DEFAULT '0',
  `globalSubmissionThrottleLimit` int NOT NULL DEFAULT '50',
  `globalSubmissionThrottleWindowSeconds` int NOT NULL DEFAULT '60',
  `enableIpSubmissionThrottling` tinyint(1) NOT NULL DEFAULT '0',
  `ipSubmissionThrottleMinutes` int NOT NULL DEFAULT '5',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_spam_settings`
--

LOCK TABLES `formie_spam_settings` WRITE;
/*!40000 ALTER TABLE `formie_spam_settings` DISABLE KEYS */;
INSERT INTO `formie_spam_settings` VALUES (1,'project',1,500,0,'showSuccess','','',1,'formieHoneypot',1,3,1,0,NULL,0,0,NULL,0,86400,0,NULL,0,10,0,50,60,0,5,'2026-10-13 20:13:14','2026-10-13 20:13:14','719951a6-6fae-4263-8d71-854fcafd496d');
/*!40000 ALTER TABLE `formie_spam_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_stencils`
--

DROP TABLE IF EXISTS `formie_stencils`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_stencils` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scope` varchar(16) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'project',
  `data` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `templateId` int DEFAULT NULL,
  `redirectEntryId` int DEFAULT NULL,
  `redirectEntrySiteId` int DEFAULT NULL,
  `defaultStatusId` int DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ejjodlbkwfjktzvhceugoqyvwopxtelxnnrs` (`templateId`),
  KEY `idx_natpbaqhirmpaynevywxcaojalohnhjsehld` (`defaultStatusId`),
  CONSTRAINT `fk_grzardpcoehzbkmvtaalcxqkhmwiyksojfjl` FOREIGN KEY (`templateId`) REFERENCES `formie_formtemplates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wddfojlwcfxiwfnfwmjffyusagrmmuypbypw` FOREIGN KEY (`defaultStatusId`) REFERENCES `formie_submission_statuses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_stencils`
--

LOCK TABLES `formie_stencils` WRITE;
/*!40000 ALTER TABLE `formie_stencils` DISABLE KEYS */;
INSERT INTO `formie_stencils` VALUES (1,'Contact Form','contactForm','project','{\"dataRetention\":\"forever\",\"dataRetentionValue\":null,\"fileUploadsAction\":\"retain\",\"settings\":{\"collectIp\":false,\"collectUser\":false,\"dataRetention\":null,\"dataRetentionValue\":null,\"defaultEmailTemplateId\":null,\"defaultInstructionsPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"defaultLabelPosition\":\"verbb\\\\formie\\\\positions\\\\AboveInput\",\"disableCaptchas\":false,\"displayCurrentPageTitle\":false,\"displayFormTitle\":false,\"displayPageProgress\":false,\"displayPageTabs\":false,\"errorMessage\":[{\"content\":[{\"text\":\"Couldn’t save submission due to errors.\",\"type\":\"text\"}],\"type\":\"paragraph\"}],\"errorMessagePosition\":\"top-form\",\"fileUploadsAction\":null,\"limitSubmissions\":null,\"limitSubmissionsIpAddressNumber\":null,\"limitSubmissionsIpAddressType\":null,\"limitSubmissionsNumber\":null,\"limitSubmissionsType\":\"total\",\"loadingIndicator\":null,\"loadingIndicatorText\":null,\"pageRedirectUrl\":null,\"progressCalculation\":\"completion\",\"progressPosition\":\"end\",\"progressValuePosition\":\"inside-center\",\"redirectUrl\":null,\"requireUser\":false,\"requiredIndicator\":\"asterisk\",\"scheduleForm\":false,\"scheduleFormEnd\":null,\"scheduleFormStart\":null,\"scrollToTop\":true,\"submissionTitleFormat\":\"{timestamp}\",\"submitMethod\":\"page-reload\",\"validationOnFocus\":false,\"validationOnSubmit\":true,\"redirectTarget\":\"same-tab\",\"hideFormAfterSubmit\":false,\"successMessage\":[{\"content\":[{\"text\":\"Submission saved.\",\"type\":\"text\"}],\"type\":\"paragraph\"}],\"successMessageTimeout\":null,\"successMessagePosition\":\"top-form\",\"completionBehavior\":\"message\",\"completionRedirectSource\":\"url\"},\"userDeletedAction\":\"retain\"}',NULL,NULL,NULL,1,NULL,'2026-06-02 11:28:30','2026-06-02 11:28:30','06a70224-206c-457a-a344-4dbae44cce17');
/*!40000 ALTER TABLE `formie_stencils` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_submission_dispatches`
--

DROP TABLE IF EXISTS `formie_submission_dispatches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_submission_dispatches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `submissionId` int NOT NULL,
  `uid` varchar(255) NOT NULL,
  `identity` varchar(64) NOT NULL,
  `kind` varchar(32) NOT NULL,
  `status` varchar(32) NOT NULL,
  `submissionVersion` int NOT NULL,
  `command` text,
  `schedulingComplete` tinyint(1) NOT NULL DEFAULT '0',
  `failureCode` varchar(64) DEFAULT NULL,
  `scheduledAt` datetime DEFAULT NULL,
  `startedAt` datetime DEFAULT NULL,
  `completedAt` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gppegycqdblskpyiwjdywfavzxzxzeeqmftf` (`identity`),
  UNIQUE KEY `idx_uqyfhtxvbojtsrqrgnbpqinslqgmsbowbapd` (`submissionId`,`uid`),
  KEY `idx_xunkyjjiqzbfsoiycrgduomduaobuomeudyn` (`schedulingComplete`,`status`,`scheduledAt`),
  CONSTRAINT `fk_gjskrejorxaukdzlspcrtygfnubnuopugupg` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_submission_dispatches`
--

LOCK TABLES `formie_submission_dispatches` WRITE;
/*!40000 ALTER TABLE `formie_submission_dispatches` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_submission_dispatches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_submission_grants`
--

DROP TABLE IF EXISTS `formie_submission_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_submission_grants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tokenHash` varchar(80) DEFAULT NULL,
  `bindingHash` char(64) DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `progressId` int DEFAULT NULL,
  `submissionId` int DEFAULT NULL,
  `formId` int NOT NULL,
  `siteId` int NOT NULL,
  `purpose` varchar(32) NOT NULL,
  `expiresAt` int NOT NULL,
  `revokedAt` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lgddgjgjucfnlduoomtumtbwbgaiuoyzerci` (`tokenHash`),
  KEY `idx_bblursziuitpjagjjwmbargwoparszpjgtrb` (`formId`,`siteId`,`bindingHash`),
  KEY `idx_ncspzjidavitpbarimzhqqptcfninjiospye` (`expiresAt`),
  KEY `fk_mgulmcmoaczjhkxejljpmjwsdhfsovdnhsfv` (`parentId`),
  KEY `fk_dezrqwgguytxnfdwkokmcszgemebfjhyxlno` (`submissionId`),
  KEY `fk_utztlzguzkndlzmpozxtjummtaxeupwiykyn` (`siteId`),
  KEY `fk_dbgpuxkkxlhuljwapecovjdntrhhkorqfyqy` (`progressId`),
  CONSTRAINT `fk_dbgpuxkkxlhuljwapecovjdntrhhkorqfyqy` FOREIGN KEY (`progressId`) REFERENCES `formie_submission_progress` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_dezrqwgguytxnfdwkokmcszgemebfjhyxlno` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mgulmcmoaczjhkxejljpmjwsdhfsovdnhsfv` FOREIGN KEY (`parentId`) REFERENCES `formie_submission_grants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_utztlzguzkndlzmpozxtjummtaxeupwiykyn` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wdoqpjddjocbqocmzqonjhtdwichzmnzbqwk` FOREIGN KEY (`formId`) REFERENCES `formie_forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_submission_grants`
--

LOCK TABLES `formie_submission_grants` WRITE;
/*!40000 ALTER TABLE `formie_submission_grants` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_submission_grants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_submission_operations`
--

DROP TABLE IF EXISTS `formie_submission_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_submission_operations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `operationHash` char(64) NOT NULL,
  `requestHash` char(64) DEFAULT NULL,
  `fingerprint` char(64) NOT NULL,
  `formId` int NOT NULL,
  `submissionId` int DEFAULT NULL,
  `operation` varchar(32) NOT NULL,
  `state` varchar(16) NOT NULL,
  `outcome` mediumtext,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `expiresAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_itscdjbjwajxkyolnwgrcitupdzfljziypdg` (`operationHash`),
  UNIQUE KEY `idx_laqxmjldbppfohpoeiascgdotueaqiebynex` (`requestHash`),
  KEY `idx_iujehnbysvgdnnixchvjydasmasrabhxtwfq` (`expiresAt`),
  KEY `fk_chunbjghtyeubyxeuzfalwlcipruqbqypned` (`formId`),
  KEY `fk_fcvaxztoibtrpzxrxqtmasbujfailvaejsvg` (`submissionId`),
  CONSTRAINT `fk_chunbjghtyeubyxeuzfalwlcipruqbqypned` FOREIGN KEY (`formId`) REFERENCES `formie_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fcvaxztoibtrpzxrxqtmasbujfailvaejsvg` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_submission_operations`
--

LOCK TABLES `formie_submission_operations` WRITE;
/*!40000 ALTER TABLE `formie_submission_operations` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_submission_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_submission_progress`
--

DROP TABLE IF EXISTS `formie_submission_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_submission_progress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `formId` int NOT NULL,
  `siteId` int NOT NULL,
  `submissionId` int DEFAULT NULL,
  `browserHash` char(64) NOT NULL,
  `currentPageId` int DEFAULT NULL,
  `content` mediumtext,
  `version` int NOT NULL DEFAULT '0',
  `expiresAt` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sgogpeslafglearqblsvoauogqmqxcczrqwg` (`submissionId`),
  KEY `idx_uxxscoyrgkkpywyvfnokccdewinuydnyjewb` (`expiresAt`),
  KEY `fk_syfqslxtxwlommnzayjqmnwnednlfpzpvekl` (`formId`),
  KEY `fk_vzjgkmptowqmiicayaaoztnfvsesmvebmkcf` (`siteId`),
  CONSTRAINT `fk_syfqslxtxwlommnzayjqmnwnednlfpzpvekl` FOREIGN KEY (`formId`) REFERENCES `formie_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vzjgkmptowqmiicayaaoztnfvsesmvebmkcf` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wtilwxuudemnniowssjrwjxapqhqyhnfuvwr` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_submission_progress`
--

LOCK TABLES `formie_submission_progress` WRITE;
/*!40000 ALTER TABLE `formie_submission_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_submission_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_submission_quiz_results`
--

DROP TABLE IF EXISTS `formie_submission_quiz_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_submission_quiz_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `submissionId` int NOT NULL,
  `score` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `maxScore` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `percentage` decimal(8,2) NOT NULL DEFAULT '0.00',
  `passed` tinyint(1) NOT NULL DEFAULT '0',
  `questionResults` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cwwljyosjppxsbtoixnadybjyuayrtkoijwa` (`submissionId`),
  CONSTRAINT `fk_ryuxrbbmzynhdpvftwrmdkgncpkyfnlqhsqa` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_submission_quiz_results`
--

LOCK TABLES `formie_submission_quiz_results` WRITE;
/*!40000 ALTER TABLE `formie_submission_quiz_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_submission_quiz_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_submission_statuses`
--

DROP TABLE IF EXISTS `formie_submission_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_submission_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `color` enum('green','orange','red','blue','yellow','pink','purple','turquoise','light','grey','black') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'green',
  `description` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `isDefault` tinyint(1) DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_submission_statuses`
--

LOCK TABLES `formie_submission_statuses` WRITE;
/*!40000 ALTER TABLE `formie_submission_statuses` DISABLE KEYS */;
INSERT INTO `formie_submission_statuses` VALUES (1,'New','new','turquoise',NULL,1,1,NULL,'2026-06-02 11:28:30','2026-10-13 20:13:29','6d6dea9a-13d2-4658-88d5-2520c9474ad6');
/*!40000 ALTER TABLE `formie_submission_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_submission_workflow`
--

DROP TABLE IF EXISTS `formie_submission_workflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_submission_workflow` (
  `id` int NOT NULL AUTO_INCREMENT,
  `submissionId` int NOT NULL,
  `stage` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `idempotencyKey` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isDispatched` tinyint(1) NOT NULL DEFAULT '1',
  `dateDispatched` datetime NOT NULL,
  `meta` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pwqxrykppharbksddmhnfnccnjnwdrcdlwgt` (`submissionId`,`stage`,`idempotencyKey`),
  KEY `idx_glzzhryidpdjvetsvvcrglqrxpzfuqxwzasu` (`submissionId`),
  CONSTRAINT `fk_beuysqywfxqfsleuusajkxeobtwnbxdcflni` FOREIGN KEY (`submissionId`) REFERENCES `formie_submissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_submission_workflow`
--

LOCK TABLES `formie_submission_workflow` WRITE;
/*!40000 ALTER TABLE `formie_submission_workflow` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_submission_workflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_submissions`
--

DROP TABLE IF EXISTS `formie_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_submissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` json DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `formId` int NOT NULL,
  `statusId` int DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `updatedById` int DEFAULT NULL,
  `isIncomplete` tinyint(1) DEFAULT '0',
  `isSpam` tinyint(1) DEFAULT '0',
  `spamReason` text COLLATE utf8mb4_unicode_520_ci,
  `spamClass` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `snapshot` text COLLATE utf8mb4_unicode_520_ci,
  `ipAddress` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signatureAccessKey` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `legacySignatureAccess` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  `stateVersion` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tcztguhsgwgrtxuwurevbnnkeoyfyzwpneha` (`formId`),
  KEY `idx_awvpddqoficqiyabzrvfoapvebpkongvkxdx` (`statusId`),
  KEY `idx_tugowvacudklbgimtcmdfgnbzpkbslqtodws` (`userId`),
  KEY `idx_utmxkypnmoshkounoujntdwudlfruzfqurzu` (`updatedById`),
  CONSTRAINT `fk_bppcdtfpwndbvwpmrgjlpkzclkldcdryuarb` FOREIGN KEY (`updatedById`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_bqyqpmklvoukqpfbenfqdderxeykkamjkgvg` FOREIGN KEY (`formId`) REFERENCES `formie_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eqwwfxxqkyeqfeikiiibbmhmkrfwgtwbpjyp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fzkndfmfbhpkzewokvledtqkslkklhjyfsno` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xdezcgabmhucynvjkafohdlngbgdxjcgtrvx` FOREIGN KEY (`statusId`) REFERENCES `formie_submission_statuses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_submissions`
--

LOCK TABLES `formie_submissions` WRITE;
/*!40000 ALTER TABLE `formie_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_subscription_diagnostics`
--

DROP TABLE IF EXISTS `formie_subscription_diagnostics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_subscription_diagnostics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subscriptionUid` char(36) NOT NULL DEFAULT '0',
  `status` varchar(32) NOT NULL,
  `evidence` mediumtext NOT NULL,
  `observedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tnsmkrjgiytgoshnebxotwnsnajpgaajejby` (`subscriptionUid`,`observedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_subscription_diagnostics`
--

LOCK TABLES `formie_subscription_diagnostics` WRITE;
/*!40000 ALTER TABLE `formie_subscription_diagnostics` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_subscription_diagnostics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formie_webhookreceipts`
--

DROP TABLE IF EXISTS `formie_webhookreceipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formie_webhookreceipts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `identity` char(64) NOT NULL,
  `integrationId` int NOT NULL,
  `environment` varchar(80) NOT NULL,
  `eventId` varchar(255) NOT NULL,
  `bodyHash` char(64) NOT NULL,
  `eventHash` char(64) NOT NULL,
  `history` mediumtext NOT NULL,
  `body` mediumtext NOT NULL,
  `headers` text NOT NULL,
  `display` mediumtext NOT NULL,
  `status` varchar(32) NOT NULL,
  `attempts` int NOT NULL DEFAULT '0',
  `error` text,
  `receivedAt` datetime NOT NULL,
  `processedAt` datetime DEFAULT NULL,
  `integrationUid` char(36) NOT NULL DEFAULT '0',
  `accountFingerprint` char(64) NOT NULL,
  `eventType` varchar(255) NOT NULL,
  `resourceType` varchar(255) DEFAULT NULL,
  `resourceReference` varchar(255) DEFAULT NULL,
  `providerCreatedAt` bigint DEFAULT NULL,
  `payload` mediumtext NOT NULL,
  `verifiedAt` datetime NOT NULL,
  `scheduledAt` datetime DEFAULT NULL,
  `startedAt` datetime DEFAULT NULL,
  `nextAttemptAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kxgkkvmfgkufpshiaqyubqqsacnasnzohowc` (`identity`),
  KEY `idx_pxmfcawepkzfaypgrezacayzchtebfnorppu` (`status`,`nextAttemptAt`),
  KEY `idx_etjnenysixsmhquqwgxzuuxteihogluzkjxj` (`integrationUid`,`eventId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formie_webhookreceipts`
--

LOCK TABLES `formie_webhookreceipts` WRITE;
/*!40000 ALTER TABLE `formie_webhookreceipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `formie_webhookreceipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zqrzpvysveztcombcgdjlstmbrleulctdijm` (`name`),
  KEY `idx_hharxpdqtndjohjovvlvvsioihvmywtawwix` (`handle`),
  KEY `idx_msdshrtkzfldwpeqfmdjpzaywybztmjskgdt` (`fieldLayoutId`),
  KEY `idx_pmnwnnbuqjffrsugaatdwfdubepxatjnhnvv` (`sortOrder`),
  CONSTRAINT `fk_rthlfejqwqaaslhbwbgojsjriagiabvblwmh` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_uvzosmjpoodadkbpnqdzkbxbgjiwrmvdtwid` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[\"sites.dabb80e6-8dc1-4d79-838f-e45c676d1db3:read\", \"elements.drafts:read\", \"elements.revisions:read\", \"elements.inactive:read\", \"usergroups.solo:read\", \"formieForms.all:read\", \"formieForms.c5c26b24-57c5-4f36-817d-07c3bdbc01ee:read\", \"formieForms.8aa2ad87-56bc-443a-aeb7-3dba0c5bc492:read\", \"formieForms.16d2b0bf-0d0d-4831-b4a8-9c97b5a17061:read\", \"formieSubmissions.all:read\", \"formieSubmissions.c5c26b24-57c5-4f36-817d-07c3bdbc01ee:read\", \"formieSubmissions.8aa2ad87-56bc-443a-aeb7-3dba0c5bc492:read\", \"formieSubmissions.16d2b0bf-0d0d-4831-b4a8-9c97b5a17061:read\", \"formieSubmissions.all:edit\", \"formieSubmissions.all:create\", \"formieSubmissions.all:save\", \"formieSubmissions.all:delete\", \"formieSubmissions.c5c26b24-57c5-4f36-817d-07c3bdbc01ee:edit\", \"formieSubmissions.c5c26b24-57c5-4f36-817d-07c3bdbc01ee:create\", \"formieSubmissions.c5c26b24-57c5-4f36-817d-07c3bdbc01ee:save\", \"formieSubmissions.c5c26b24-57c5-4f36-817d-07c3bdbc01ee:delete\", \"formieSubmissions.8aa2ad87-56bc-443a-aeb7-3dba0c5bc492:edit\", \"formieSubmissions.8aa2ad87-56bc-443a-aeb7-3dba0c5bc492:create\", \"formieSubmissions.8aa2ad87-56bc-443a-aeb7-3dba0c5bc492:save\", \"formieSubmissions.8aa2ad87-56bc-443a-aeb7-3dba0c5bc492:delete\", \"formieSubmissions.16d2b0bf-0d0d-4831-b4a8-9c97b5a17061:edit\", \"formieSubmissions.16d2b0bf-0d0d-4831-b4a8-9c97b5a17061:create\", \"formieSubmissions.16d2b0bf-0d0d-4831-b4a8-9c97b5a17061:save\", \"formieSubmissions.16d2b0bf-0d0d-4831-b4a8-9c97b5a17061:delete\"]',1,'2026-06-02 11:28:30','2026-06-02 11:28:30','a6061a32-15c1-408a-8e4d-47f0af858dfc');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `accessToken` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dazcbouvewlsknkaoodttqbwqjqysenisgfh` (`accessToken`),
  UNIQUE KEY `idx_ruuwisqxoofjaxrvvpqeeancmllhuxydrrwv` (`name`),
  KEY `fk_ybhuyttfwwrobtxwxlmaaoowatzopvnyeoar` (`schemaId`),
  CONSTRAINT `fk_ybhuyttfwwrobtxwxlmaaoowatzopvnyeoar` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
INSERT INTO `gqltokens` VALUES (1,'Public Token','__PUBLIC__',1,NULL,'2026-10-13 20:44:25',NULL,'2026-10-13 20:40:35','2026-10-13 20:44:25','14ee0924-83ab-4856-ac6a-a82b5fb452d6');
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `format` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transformString` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kzkvlseotjvwosiqfexsjskijqlxthgmtjxn` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'none',
  `fill` varchar(11) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_amdhlahuyirssloxiykayujgydjwfxpmxtsb` (`name`),
  KEY `idx_ewoyfdtizeacclizhpkbbgrxxnabpcldiobp` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `schemaVersion` varchar(15) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'5.11.5.1','5.11.0.2',0,'wqqtrwbtwxof','3@fvjwehtkro','2026-06-02 11:28:28','2026-10-13 20:16:36','7e5f6c65-ba2f-4f37-8bee-52ea1c11939d');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dksuujcicwvmholrnpqoircknvsynbjkadcr` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'module:verbb-auth','m221127_000000_install','2026-06-02 11:28:28','2026-06-02 11:28:28','2026-06-02 11:28:28','d3b7c2ca-1789-4f65-a874-d478fe2bbe57'),(2,'plugin:formie','Install','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','310be853-d699-491d-9e02-50378b511b36'),(3,'plugin:formie','m231125_000000_craft5','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','799e372f-cca6-48ab-85c7-f7e295803ce8'),(4,'plugin:formie','m231129_000000_integrations_mapping','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','3e85b317-4dc5-4069-90e5-1e9c26acb1ce'),(5,'plugin:formie','m231130_000000_conditions_mapping','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','44fdd21f-7b8c-41b6-9d09-38a3d5b279c4'),(6,'plugin:formie','m231202_000000_auth_module','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','ec9aada3-2c93-4d72-9d17-aecca40b5081'),(7,'plugin:formie','m240130_000000_permissions','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','1e381c15-0aa5-4b76-93fc-283cfa90c22b'),(8,'plugin:formie','m240313_000000_subfields','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','a2e40e34-2ae6-414a-b0cb-3399fb212518'),(9,'plugin:formie','m240318_000000_fix_content_table','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','836de836-4b66-4186-9ba0-a73729d44e29'),(10,'plugin:formie','m240318_000000_migrate_stencils','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','f2b99bd5-8b24-45dc-b68c-81ad28ed66c4'),(11,'plugin:formie','m240318_000000_notification_fields','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','609ae6e9-2eb4-4d66-86ae-2c7ebe2f3f95'),(12,'plugin:formie','m240325_000000_notifications_custom_settings','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','931078f9-bf8b-4776-9121-466348de320a'),(13,'plugin:formie','m240407_000000_payment_fk','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','948c5fdf-50bd-49f4-9860-e774d85d34e1'),(14,'plugin:formie','m240507_000000_entry_integration_ids','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','6479a297-450f-439d-9cea-9b429fe64990'),(15,'plugin:formie','m240528_000000_payment_fk','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','63312834-eefb-42e4-90a2-74924d9ac475'),(16,'plugin:formie','m240614_000000_klaviyo','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','6779ae83-51d2-4d55-938d-497beebf41b3'),(17,'plugin:formie','m240807_000000_migrate_date_field_datetime','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','c85e33a2-6240-47b5-9474-03d7490b4d99'),(18,'plugin:formie','m241128_000000_user_group_integrations','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','17a5dfb3-4b78-4143-9b46-301b0331e1ae'),(19,'plugin:formie','m241128_100000_entry_integrations','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','dacd76fe-df5e-4e0a-9e25-739452b160ba'),(20,'plugin:formie','m250113_000000_calculations','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','7e5b6719-87be-4ae0-9f9e-95676f563155'),(21,'plugin:formie','m250114_000000_email_blocked_domains','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','39fb59b3-4550-4799-b828-5a944fc41ddc'),(22,'plugin:formie','m250117_000000_date_year_min','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','b2021aa3-96be-4b6f-ba59-0413c6c27ba5'),(23,'plugin:formie','m250516_000000_payment_redirect','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','5e0ed568-d182-4e45-814e-a4ecfd5406b9'),(24,'plugin:formie','m250711_000000_fix_element_field_source_ids','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','79143153-f369-4ae1-882a-2c7b53edb558'),(25,'plugin:formie','m250806_000000_integrations_optin','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','40b1aa26-cb44-4078-89cc-04f5f62eb900'),(26,'plugin:formie','m251014_000000_date_subfields','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','0e8a55bc-e6f3-4e98-ae6e-1c7c9469b68b'),(27,'plugin:formie','m251114_000000_email_conditions_mapping','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','b5b501e4-94f8-4c34-9475-4a21e49c3311'),(28,'plugin:formie','m260214_000000_field_references','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','a31cd3a4-b1ba-436b-aefa-730fdb30663c'),(29,'plugin:formie','m260222_000001_submission_workflow','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','bef04e04-6b08-487a-9a37-f8742e986055'),(30,'plugin:formie','m260223_000001_backfill_date_parts','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','54e1b9dd-eaaa-4cba-9b3c-9633bbc6af87'),(31,'plugin:formie','m260223_000002_pending_uploads','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','2228765e-635f-4ae3-a51c-8b351b805eb0'),(32,'plugin:formie','m260224_000004_submission_drafts','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','f40544c7-6a40-4c88-bb2f-2d26c08e5895'),(33,'plugin:formie','m260224_000005_submission_resume_tokens','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','73a399a6-c599-4ba4-b061-f400a38386ff'),(34,'plugin:formie','m260306_000006_field_reference_uniqueness','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','0f723a70-602a-4aca-b0d4-9abbd9464c98'),(35,'plugin:formie','m260320_000007_form_template_output_flags','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','b69f1af6-3120-4e1d-ae60-58f6988d1ebc'),(36,'plugin:formie','m260410_000000_rename_page_client_event_settings','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','2f49a465-b8f7-419d-8bea-ea76e14ad91a'),(37,'plugin:formie','m260418_000000_field_definitions_and_form_fields','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','fdbb8df8-4eb7-424d-983a-b699381951ea'),(38,'plugin:sprig','Install','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','8c3c1db5-56be-48ee-96f8-864c705e85ae'),(39,'craft','Install','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','6925a477-3342-47da-bc12-60e09cfd36af'),(40,'craft','m221101_115859_create_entries_authors_table','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','6edcfa7f-d64d-472b-b9f5-f614857ca8bd'),(41,'craft','m221107_112121_add_max_authors_to_sections','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','e1e40dc4-1313-4734-a6b1-a733274ed584'),(42,'craft','m221205_082005_translatable_asset_alt_text','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','738361b3-6f8a-4ae8-a98f-e78f9fe592e7'),(43,'craft','m230314_110309_add_authenticator_table','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','e82799e9-c0c2-4512-aca5-56c99bbcbe29'),(44,'craft','m230314_111234_add_webauthn_table','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','7fef6e02-e45e-4c29-8742-cf782d4a546a'),(45,'craft','m230503_120303_add_recoverycodes_table','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','4d68d903-2ecb-4c9a-8795-3d371322415b'),(46,'craft','m230511_000000_field_layout_configs','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','119fedb1-1aae-43a2-8f70-55e9ddb28f38'),(47,'craft','m230511_215903_content_refactor','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','c8465b2f-cab7-4af5-a59d-276c21d77f72'),(48,'craft','m230524_000000_add_entry_type_show_slug_field','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','c6912fa3-eeb9-4310-ae3b-f8b020cdae71'),(49,'craft','m230524_000001_entry_type_icons','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','83b272aa-2c79-4282-80cf-cec485d838ab'),(50,'craft','m230524_000002_entry_type_colors','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','ca3340fc-87ba-4e1d-b528-fe131f6640d5'),(51,'craft','m230524_220029_global_entry_types','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','fdf8cc8d-7d86-4d93-9acf-c9ce3b5e2f1d'),(52,'craft','m230531_123004_add_entry_type_show_status_field','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','8c603b18-9403-4ac0-ad4f-c64f435a0c0c'),(53,'craft','m230607_102049_add_entrytype_slug_translation_columns','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','2df5ea7c-4118-428f-b872-7907069c0148'),(54,'craft','m230616_173810_kill_field_groups','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','67442159-5f7f-4854-af84-ea7a99ce6fc0'),(55,'craft','m230616_183820_remove_field_name_limit','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','b5ed76cb-3dce-4b1b-946d-3cea74bacff1'),(56,'craft','m230617_070415_entrify_matrix_blocks','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','6f007e0a-6782-4921-a9db-7a866fba30ff'),(57,'craft','m230710_162700_element_activity','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','9b3fec28-0e57-41fb-9f04-b22654dd1240'),(58,'craft','m230820_162023_fix_cache_id_type','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','bc5bc6f1-4d71-475e-b9fd-0622ff999b4c'),(59,'craft','m230826_094050_fix_session_id_type','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','58455fde-2114-4716-884a-ed0a871f504a'),(60,'craft','m230904_190356_address_fields','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','e96d29cf-d2b1-4fa1-9c91-74aa1de8927a'),(61,'craft','m230928_144045_add_subpath_to_volumes','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','ab711281-353e-42ce-aed9-d8aa3b6c3cdb'),(62,'craft','m231013_185640_changedfields_amend_primary_key','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','d5caf16c-7476-498c-b229-bd2b835ebef9'),(63,'craft','m231213_030600_element_bulk_ops','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','4bba7777-9be2-4a00-a13a-fab0148cf930'),(64,'craft','m240129_150719_sites_language_amend_length','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','856acbcb-886f-4eaa-a82b-909d201fa346'),(65,'craft','m240206_035135_convert_json_columns','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','b6da92b8-2de1-492f-a2b9-2f710f80f354'),(66,'craft','m240207_182452_address_line_3','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','78e7bbf2-7d12-4560-a089-a430f9956faa'),(67,'craft','m240302_212719_solo_preview_targets','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','2a980f67-1d6d-4313-907c-071d55a17f37'),(68,'craft','m240619_091352_add_auth_2fa_timestamp','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','19a6d385-b5e6-429c-bbb2-ce0d70794a22'),(69,'craft','m240723_214330_drop_bulkop_fk','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','37f2e3b9-77b9-4479-a44f-756ac02c4315'),(70,'craft','m240731_053543_soft_delete_fields','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','cad88c37-6dc6-4cc7-a3a6-f0a8735a6e74'),(71,'craft','m240805_154041_sso_identities','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','517b215f-4923-4ef0-a311-7dff2d4f2509'),(72,'craft','m240926_202248_track_entries_deleted_with_section','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','3a1bd05a-d6f1-431f-859a-e3d5752486d1'),(73,'craft','m241120_190905_user_affiliated_sites','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','31db7aa9-30e6-42b9-a36a-866f1ece48b3'),(74,'craft','m241125_122914_add_viewUsers_permission','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','6a09666c-e4b2-41b1-ba6a-8a8d76c5ac22'),(75,'craft','m250119_135304_entry_type_overrides','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','3061d3fa-ce66-47fd-8c06-77a48f3c12d3'),(76,'craft','m250206_135036_search_index_queue','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','ff07044d-1395-4e57-919f-7c30a27c6abb'),(77,'craft','m250207_172349_bulkop_events','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','a696896a-bcf7-4ada-b8b7-8078b9e325a8'),(78,'craft','m250315_131608_unlimited_authors','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','76201a77-bd55-478d-983b-469036a92c7d'),(79,'craft','m250403_171253_static_statuses','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','68645a7a-13cc-4d1a-97aa-ce4d578579d1'),(80,'craft','m250512_164202_asset_mime_types','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','bab7a898-bc5e-4ef0-a560-7902c91c0dc7'),(81,'craft','m250522_090843_add_deleteEntriesForSite_and_deletePeerEntriesForSite_permissions','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','a96eaa90-f78f-41f5-9145-1cfeb0301bfb'),(82,'craft','m250531_183058_content_blocks','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','de8af2ab-440a-4514-b8a4-9122105d6dc6'),(83,'craft','m250623_105031_entry_type_descriptions','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','bea86b45-d6ae-4c89-a699-e3ba0078d824'),(84,'craft','m250910_144630_add_elements_owners_sort_order_index','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','6270c25d-fb60-4c5b-a966-5253abb5e20f'),(85,'craft','m251030_203440_drop_widgets_enabled_column','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','0c9a29ae-cb72-4101-8e57-1aae77b5b707'),(86,'craft','m251110_192405_entry_type_ui_label_formats','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','9f5451b6-517a-4a9c-a906-6b101cfa62c4'),(87,'craft','m251205_190131_drop_searchindexqueue_fk','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','c71e7fc6-2c34-43d6-87ec-f900713aec8c'),(88,'craft','m251230_192239_update_field_layouts','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','e99d41bf-bdd5-442e-b0f7-775d8059d97f'),(89,'craft','m260106_130629_directive_schema_components','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','135df0ac-9ca6-4c09-9052-e636ad5d271b'),(90,'craft','m260120_120907_line_breaks_in_titles','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','28ab3de4-9762-431f-ae2b-bd3389c4b464'),(91,'craft','m260125_233614_changeAuthorForPeerEntries_permission','2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:28:31','f9dd4a9d-4a25-4e69-b74d-6dac08968f46'),(92,'craft','m260401_155236_min_authors_setting','2026-10-13 20:12:45','2026-10-13 20:12:45','2026-10-13 20:12:45','f93b16fb-c362-4294-8344-026845b5c5cc'),(93,'craft','m260610_065719_translatable_alt_text_content','2026-10-13 20:12:45','2026-10-13 20:12:45','2026-10-13 20:12:45','2efc9b75-d798-4274-94a7-dac8e40e056c'),(94,'craft','m260812_143000_drop_elementactivity_draftid_fk','2026-10-13 20:12:46','2026-10-13 20:12:46','2026-10-13 20:12:46','285249b5-37d7-4b4e-a669-a546505f2dd1'),(95,'craft','m260817_012148_queue_reserve_index','2026-10-13 20:12:46','2026-10-13 20:12:46','2026-10-13 20:12:46','a047b74c-8442-474e-8293-f4ab6030056c'),(96,'plugin:formie','m250612_100000_integration_dispatch','2026-10-13 20:12:55','2026-10-13 20:12:56','2026-10-13 20:12:56','3d66504f-2ad1-4824-b4af-eea32ff6a015'),(97,'plugin:formie','m260603_000000_form_created_updated_by','2026-10-13 20:13:03','2026-10-13 20:13:03','2026-10-13 20:13:03','4f5aee8b-6a05-49bd-a813-44bc4f5331f2'),(98,'plugin:formie','m260604_000000_form_groups','2026-10-13 20:13:05','2026-10-13 20:13:06','2026-10-13 20:13:06','22b08b19-503f-45e7-95a9-e256b732642b'),(99,'plugin:formie','m260604_000000_migrate_field_defaults','2026-10-13 20:13:06','2026-10-13 20:13:06','2026-10-13 20:13:06','5a57d41b-96eb-454a-bf9f-ade1a94c4f38'),(100,'plugin:formie','m260605_000000_stencil_scopes','2026-10-13 20:13:06','2026-10-13 20:13:06','2026-10-13 20:13:06','299fdc29-8232-49d3-8380-b20a2a418123'),(101,'plugin:formie','m260606_000000_stencil_access_permission','2026-10-13 20:13:06','2026-10-13 20:13:06','2026-10-13 20:13:06','a36355d1-0bf8-4f05-8305-316ad5d4b9c0'),(102,'plugin:formie','m260607_000000_field_palette','2026-10-13 20:13:07','2026-10-13 20:13:07','2026-10-13 20:13:07','e4ad7bf1-109d-4d64-b503-88ccccc05234'),(103,'plugin:formie','m260612_000000_salesforce_oauth_instance_url','2026-10-13 20:13:07','2026-10-13 20:13:07','2026-10-13 20:13:07','db6b241f-8db0-4fb2-991e-0e374104add8'),(104,'plugin:formie','m260613_000000_integration_scopes','2026-10-13 20:13:08','2026-10-13 20:13:08','2026-10-13 20:13:08','7e443cfb-c126-4e9a-9d50-b7e2347af594'),(105,'plugin:formie','m260615_000000_group_permissions','2026-10-13 20:13:08','2026-10-13 20:13:08','2026-10-13 20:13:08','3e2994fb-1cb1-49c2-995d-8bc923571b49'),(106,'plugin:formie','m260616_000000_integrations_access_permission','2026-10-13 20:13:09','2026-10-13 20:13:09','2026-10-13 20:13:09','d3b55d44-7399-437f-a91f-f5aca61b4195'),(107,'plugin:formie','m260617_000000_reports','2026-10-13 20:13:10','2026-10-13 20:13:10','2026-10-13 20:13:10','73f923c3-f2c6-4455-b433-ddecf05f97d4'),(108,'plugin:formie','m260617_000000_settings_page_permissions','2026-10-13 20:13:10','2026-10-13 20:13:10','2026-10-13 20:13:10','27283e84-7d18-40ff-afcd-2805261e4ab2'),(109,'plugin:formie','m260617_000001_report_permissions','2026-10-13 20:13:10','2026-10-13 20:13:10','2026-10-13 20:13:10','c1f0b06f-199e-489b-a3e5-4907d16a6d08'),(110,'plugin:formie','m260617_000002_report_exports','2026-10-13 20:13:11','2026-10-13 20:13:11','2026-10-13 20:13:11','c7fac2ec-70e3-4994-83df-de8bb8b4f273'),(111,'plugin:formie','m260618_000000_captcha_providers','2026-10-13 20:13:12','2026-10-13 20:13:12','2026-10-13 20:13:12','2d88b0e1-1d6e-4ba1-a78f-ce3854a03fd5'),(112,'plugin:formie','m260618_000000_report_export_download_security','2026-10-13 20:13:14','2026-10-13 20:13:14','2026-10-13 20:13:14','aafff7bf-d417-46c5-9f32-ab991ba4d7a7'),(113,'plugin:formie','m260619_000000_spam_settings','2026-10-13 20:13:15','2026-10-13 20:13:15','2026-10-13 20:13:15','29d33fe5-901c-4e9d-96c1-40933b3a2ac2'),(114,'plugin:formie','m260620_000000_spam_protection_settings_page','2026-10-13 20:13:15','2026-10-13 20:13:15','2026-10-13 20:13:15','b942f9e3-5692-4ee4-8cb2-f3acc1e05abe'),(115,'plugin:formie','m260620_100000_form_site_overrides','2026-10-13 20:13:17','2026-10-13 20:13:19','2026-10-13 20:13:19','a0501b9f-cbf2-4ad9-86ea-33464d1d3082'),(116,'plugin:formie','m260621_000000_submission_guards','2026-10-13 20:13:19','2026-10-13 20:13:19','2026-10-13 20:13:19','c65bc6e4-71bf-449e-b25c-154509b684c3'),(117,'plugin:formie','m260622_000000_spam_screening_followups','2026-10-13 20:13:20','2026-10-13 20:13:20','2026-10-13 20:13:20','3b0ae71b-23c7-4d26-b110-5a895efefc2c'),(118,'plugin:formie','m260623_000000_spam_abuse_controls','2026-10-13 20:13:21','2026-10-13 20:13:21','2026-10-13 20:13:21','f7550707-d2c8-46c6-8165-4c9b3aa47bfa'),(119,'plugin:formie','m260624_000000_drop_suspicious_text_minimum_word_length','2026-10-13 20:13:21','2026-10-13 20:13:21','2026-10-13 20:13:21','38071d7f-7b10-4be4-979f-9a7fbe9b2885'),(120,'plugin:formie','m260628_000000_submission_quiz_results','2026-10-13 20:13:22','2026-10-13 20:13:22','2026-10-13 20:13:22','9e840dda-1812-4f39-9157-6684bc0322b5'),(121,'plugin:formie','m260629_000000_propagate_form_element_site_titles','2026-10-13 20:13:22','2026-10-13 20:13:22','2026-10-13 20:13:22','3aac490f-3609-48f4-a955-e17509d4e4e4'),(122,'plugin:formie','m260630_000000_remap_form_site_override_keys','2026-10-13 20:13:22','2026-10-13 20:13:22','2026-10-13 20:13:22','0c0c54ca-4dcf-43da-a23c-19f1fabf0160'),(123,'plugin:formie','m260631_000000_migrate_client_events_structure','2026-10-13 20:13:22','2026-10-13 20:13:22','2026-10-13 20:13:22','8a0653a9-b3a3-4fa6-924d-77e7dc6664c3'),(124,'plugin:formie','m260632_000000_submission_metadata','2026-10-13 20:13:24','2026-10-13 20:13:24','2026-10-13 20:13:24','3d5a5aba-6b1d-4aaf-8a20-ba07fc94d4cf'),(125,'plugin:formie','m260633_000000_form_source_site','2026-10-13 20:13:26','2026-10-13 20:13:26','2026-10-13 20:13:26','ba99d86c-b2a7-4734-bff7-b74e76115c78'),(126,'plugin:formie','m260634_000000_submission_updated_by','2026-10-13 20:13:27','2026-10-13 20:13:27','2026-10-13 20:13:27','5aa15a58-0f3f-49d3-964d-51f526c5357d'),(127,'plugin:formie','m260635_000000_email_allowlist','2026-10-13 20:13:27','2026-10-13 20:13:27','2026-10-13 20:13:27','e085da6e-0a48-46cf-8bdd-e61416803d30'),(128,'plugin:formie','m260636_000000_form_statuses','2026-10-13 20:13:29','2026-10-13 20:13:29','2026-10-13 20:13:29','d1dfb836-64c6-4abe-bc25-248c80f3f659'),(129,'plugin:formie','m260641_000000_align_default_submission_status_colors','2026-10-13 20:13:29','2026-10-13 20:13:29','2026-10-13 20:13:29','3d9ad624-65de-46f0-af8c-40361b547b73'),(130,'plugin:formie','m260644_000000_field_site_overrides','2026-10-13 20:13:32','2026-10-13 20:13:32','2026-10-13 20:13:32','b879d728-9076-49c8-a0e3-5034a8d13834'),(131,'plugin:formie','m260701_000000_ensure_integration_dispatch_columns','2026-10-13 20:13:33','2026-10-13 20:13:33','2026-10-13 20:13:33','d0735ed3-dddd-46f5-a969-f0c504567daf'),(132,'plugin:formie','m260709_000000_fix_double_encoded_submission_content','2026-10-13 20:13:33','2026-10-13 20:13:33','2026-10-13 20:13:33','10f46335-01d6-47d0-b8a8-a7acc25fbff2'),(133,'plugin:formie','m260710_000000_fix_invalid_notification_handles','2026-10-13 20:13:33','2026-10-13 20:13:33','2026-10-13 20:13:33','664a583a-fd7b-4454-a1d7-c3d820b22b8a'),(134,'plugin:formie','m260711_000000_ensure_site_overrides_tables','2026-10-13 20:13:33','2026-10-13 20:13:33','2026-10-13 20:13:33','9ec96c0a-0f7f-42b0-8a44-5aefcfcbc204'),(135,'plugin:formie','m260712_000000_lowercase_permission_names','2026-10-13 20:13:33','2026-10-13 20:13:33','2026-10-13 20:13:33','1c94c206-0820-47eb-9e1e-04d3cc4f94a5'),(136,'plugin:formie','m260828_000000_date_subfields_order','2026-10-13 20:13:33','2026-10-13 20:13:33','2026-10-13 20:13:33','62934d21-806f-45c0-8dae-594d5d4ce479'),(137,'plugin:formie','m260828_000000_page_conditions_mapping','2026-10-13 20:13:33','2026-10-13 20:13:33','2026-10-13 20:13:33','f6ba8e12-5d0a-4162-aa5d-fcaac270bade'),(138,'plugin:formie','m260909_000000_payments_submission_id_index','2026-10-13 20:13:33','2026-10-13 20:13:33','2026-10-13 20:13:33','85d933f0-ec97-4b80-9787-4b66dece108e'),(139,'plugin:formie','m260912_000000_completion_vocabulary','2026-10-13 20:13:34','2026-10-13 20:13:34','2026-10-13 20:13:34','a0d9cf42-57e7-40bb-baa6-c9756b098273'),(140,'plugin:formie','m260913_000000_notification_field_references','2026-10-13 20:13:34','2026-10-13 20:13:34','2026-10-13 20:13:34','d6d29a92-634d-47cb-892a-60077c13cce0'),(141,'plugin:formie','m260913_000001_integration_field_references','2026-10-13 20:13:34','2026-10-13 20:13:34','2026-10-13 20:13:34','4e39da11-3066-4f7d-9d15-0d308bd8c178'),(142,'plugin:formie','m260916_000000_sync_form_site_availability','2026-10-13 20:13:34','2026-10-13 20:13:34','2026-10-13 20:13:34','98b4e339-c74d-476f-9426-f19e677b7ded'),(143,'plugin:formie','m260926_000000_reference_slots','2026-10-13 20:13:34','2026-10-13 20:13:34','2026-10-13 20:13:34','4020d3aa-62d1-4277-9625-9fa4731b8cc1'),(144,'plugin:formie','m260926_000000_submission_operations','2026-10-13 20:13:41','2026-10-13 20:13:41','2026-10-13 20:13:41','a71bf566-573e-40d3-8dab-e407c0f1c9b0'),(145,'plugin:formie','m260926_010000_submission_continuity','2026-10-13 20:13:57','2026-10-13 20:13:57','2026-10-13 20:13:57','eead54b0-a763-4385-83a7-ac9f9f46b63b'),(146,'plugin:formie','m260926_020000_payment_boundary','2026-10-13 20:14:27','2026-10-13 20:14:27','2026-10-13 20:14:27','9c210145-8ca3-425f-a822-bf8345a18810'),(147,'plugin:formie','m260927_000000_delivery_attempts','2026-10-13 20:14:31','2026-10-13 20:14:31','2026-10-13 20:14:31','c979ce88-7775-413e-9c15-11e64038483d'),(148,'plugin:formie','m260927_010000_instance_configuration','2026-10-13 20:14:33','2026-10-13 20:14:33','2026-10-13 20:14:33','4b784ed9-d68a-43f1-885a-19457405e379'),(149,'plugin:formie','m260927_020000_condition_schema','2026-10-13 20:14:33','2026-10-13 20:14:33','2026-10-13 20:14:33','1fa87e26-4073-41cf-9cdf-756d97e4370e'),(150,'plugin:formie','m260927_030000_signature_access','2026-10-13 20:14:36','2026-10-13 20:14:36','2026-10-13 20:14:36','d3d97484-77e4-46b2-92d4-4f5ad2f163a0'),(151,'plugin:formie','m260927_040000_integration_run_contexts','2026-10-13 20:14:38','2026-10-13 20:14:38','2026-10-13 20:14:38','849bf34f-5856-4ace-870d-3c7297318afb'),(152,'plugin:formie','m260927_050000_submission_dispatches','2026-10-13 20:14:45','2026-10-13 20:14:46','2026-10-13 20:14:46','da166da9-4c69-4e49-b2d5-30caf1d6a74d'),(153,'plugin:formie','m260927_060000_independent_submission_grants','2026-10-13 20:14:51','2026-10-13 20:14:51','2026-10-13 20:14:51','1c2b62fb-3e8f-41cb-a747-89f807dc75f7'),(154,'plugin:formie','m260928_000000_payment_external_boundaries','2026-10-13 20:15:36','2026-10-13 20:15:36','2026-10-13 20:15:36','0b1a010d-a556-487b-9819-4d1c65319160'),(155,'plugin:formie','m260928_010000_reference_contract','2026-10-13 20:15:42','2026-10-13 20:15:42','2026-10-13 20:15:42','d8aa1665-dbc0-4886-a1fd-2c9769b4eb1d'),(156,'plugin:formie','m260928_020000_subscription_lifecycle','2026-10-13 20:16:29','2026-10-13 20:16:29','2026-10-13 20:16:29','c7f060ac-3165-406d-9048-b389366e56c8'),(157,'plugin:formie','m260929_000000_encrypt_delivery_diagnostics','2026-10-13 20:16:29','2026-10-13 20:16:29','2026-10-13 20:16:29','9d8650ad-8454-48df-aff7-2d0507e75c94'),(158,'plugin:formie','m260929_000000_form_integration_policy','2026-10-13 20:16:29','2026-10-13 20:16:29','2026-10-13 20:16:29','7215a391-d03e-4b1e-8f29-903329a43d1f'),(159,'plugin:formie','m260929_010000_payment_contracts','2026-10-13 20:16:35','2026-10-13 20:16:35','2026-10-13 20:16:35','87474ed4-1e67-473d-b711-a069a1d11bf8'),(160,'plugin:formie','m261010_000000_content_encryption','2026-10-13 20:16:35','2026-10-13 20:16:35','2026-10-13 20:16:35','63adb51e-a47c-45db-9506-f55f5e5313e4'),(161,'plugin:formie','m261010_010000_plain_integration_settings','2026-10-13 20:16:35','2026-10-13 20:16:35','2026-10-13 20:16:35','12d2d087-54a2-4410-b74e-0ae18d1de6b0'),(162,'plugin:formie','m261010_020000_operational_cryptography','2026-10-13 20:16:35','2026-10-13 20:16:35','2026-10-13 20:16:35','8959fe44-6cb6-4c83-81a5-2742860e0996');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `version` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `schemaVersion` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_oycdkjfgmeqjlhgecvwjfwfqzucmawuwzyme` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'datastar','1.0.0-RC.11','1.0.0','2026-06-02 11:28:28','2026-06-02 11:28:28','2026-06-02 11:28:28','625cb26f-e717-4afe-b980-8f3764359145'),(2,'formie','dev-beta','4.0.80','2026-06-02 11:28:28','2026-06-02 11:28:28','2026-10-13 20:16:35','5e3c7512-ee72-4a0d-98e5-402348184e27'),(3,'sprig','dev-develop','1.0.1','2026-06-02 11:28:30','2026-06-02 11:28:30','2026-06-02 11:28:30','9a114b65-86a3-4c80-9165-5b85a472f764');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('dateModified','1791922366'),('email.fromEmail','\"formie@verbb.io\"'),('email.fromName','\"Formie Starters\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('formie.fieldPalette.groups.0.fields.0.enabled','true'),('formie.fieldPalette.groups.0.fields.0.fieldClass','\"verbb\\\\formie\\\\fields\\\\SingleLineText\"'),('formie.fieldPalette.groups.0.fields.0.label','null'),('formie.fieldPalette.groups.0.fields.1.enabled','true'),('formie.fieldPalette.groups.0.fields.1.fieldClass','\"verbb\\\\formie\\\\fields\\\\MultiLineText\"'),('formie.fieldPalette.groups.0.fields.1.label','null'),('formie.fieldPalette.groups.0.fields.2.enabled','true'),('formie.fieldPalette.groups.0.fields.2.fieldClass','\"verbb\\\\formie\\\\fields\\\\Name\"'),('formie.fieldPalette.groups.0.fields.2.label','null'),('formie.fieldPalette.groups.0.fields.3.enabled','true'),('formie.fieldPalette.groups.0.fields.3.fieldClass','\"verbb\\\\formie\\\\fields\\\\Email\"'),('formie.fieldPalette.groups.0.fields.3.label','null'),('formie.fieldPalette.groups.0.fields.4.enabled','true'),('formie.fieldPalette.groups.0.fields.4.fieldClass','\"verbb\\\\formie\\\\fields\\\\Phone\"'),('formie.fieldPalette.groups.0.fields.4.label','null'),('formie.fieldPalette.groups.0.fields.5.enabled','true'),('formie.fieldPalette.groups.0.fields.5.fieldClass','\"verbb\\\\formie\\\\fields\\\\Number\"'),('formie.fieldPalette.groups.0.fields.5.label','null'),('formie.fieldPalette.groups.0.handle','\"basic\"'),('formie.fieldPalette.groups.0.name','\"Basic Fields\"'),('formie.fieldPalette.groups.0.uid','\"106c1b31-2109-404a-9372-9bebaaeb8705\"'),('formie.fieldPalette.groups.1.fields.0.enabled','true'),('formie.fieldPalette.groups.1.fields.0.fieldClass','\"verbb\\\\formie\\\\fields\\\\Radio\"'),('formie.fieldPalette.groups.1.fields.0.label','null'),('formie.fieldPalette.groups.1.fields.1.enabled','true'),('formie.fieldPalette.groups.1.fields.1.fieldClass','\"verbb\\\\formie\\\\fields\\\\Checkboxes\"'),('formie.fieldPalette.groups.1.fields.1.label','null'),('formie.fieldPalette.groups.1.fields.2.enabled','true'),('formie.fieldPalette.groups.1.fields.2.fieldClass','\"verbb\\\\formie\\\\fields\\\\Dropdown\"'),('formie.fieldPalette.groups.1.fields.2.label','null'),('formie.fieldPalette.groups.1.fields.3.enabled','true'),('formie.fieldPalette.groups.1.fields.3.fieldClass','\"verbb\\\\formie\\\\fields\\\\Agree\"'),('formie.fieldPalette.groups.1.fields.3.label','null'),('formie.fieldPalette.groups.1.fields.4.enabled','true'),('formie.fieldPalette.groups.1.fields.4.fieldClass','\"verbb\\\\formie\\\\fields\\\\Quiz\"'),('formie.fieldPalette.groups.1.fields.4.label','null'),('formie.fieldPalette.groups.1.fields.5.enabled','true'),('formie.fieldPalette.groups.1.fields.5.fieldClass','\"verbb\\\\formie\\\\fields\\\\Survey\"'),('formie.fieldPalette.groups.1.fields.5.label','null'),('formie.fieldPalette.groups.1.handle','\"option\"'),('formie.fieldPalette.groups.1.name','\"Option Fields\"'),('formie.fieldPalette.groups.1.uid','\"6eeb5e16-8ce0-4a92-ace1-be02316338c2\"'),('formie.fieldPalette.groups.2.fields.0.enabled','true'),('formie.fieldPalette.groups.2.fields.0.fieldClass','\"verbb\\\\formie\\\\fields\\\\Date\"'),('formie.fieldPalette.groups.2.fields.0.label','null'),('formie.fieldPalette.groups.2.fields.1.enabled','true'),('formie.fieldPalette.groups.2.fields.1.fieldClass','\"verbb\\\\formie\\\\fields\\\\Address\"'),('formie.fieldPalette.groups.2.fields.1.label','null'),('formie.fieldPalette.groups.2.fields.2.enabled','true'),('formie.fieldPalette.groups.2.fields.2.fieldClass','\"verbb\\\\formie\\\\fields\\\\FileUpload\"'),('formie.fieldPalette.groups.2.fields.2.label','null'),('formie.fieldPalette.groups.2.fields.3.enabled','true'),('formie.fieldPalette.groups.2.fields.3.fieldClass','\"verbb\\\\formie\\\\fields\\\\Password\"'),('formie.fieldPalette.groups.2.fields.3.label','null'),('formie.fieldPalette.groups.2.fields.4.enabled','true'),('formie.fieldPalette.groups.2.fields.4.fieldClass','\"verbb\\\\formie\\\\fields\\\\Hidden\"'),('formie.fieldPalette.groups.2.fields.4.label','null'),('formie.fieldPalette.groups.2.fields.5.enabled','true'),('formie.fieldPalette.groups.2.fields.5.fieldClass','\"verbb\\\\formie\\\\fields\\\\Recipients\"'),('formie.fieldPalette.groups.2.fields.5.label','null'),('formie.fieldPalette.groups.2.fields.6.enabled','true'),('formie.fieldPalette.groups.2.fields.6.fieldClass','\"verbb\\\\formie\\\\fields\\\\Signature\"'),('formie.fieldPalette.groups.2.fields.6.label','null'),('formie.fieldPalette.groups.2.fields.7.enabled','true'),('formie.fieldPalette.groups.2.fields.7.fieldClass','\"verbb\\\\formie\\\\fields\\\\Calculations\"'),('formie.fieldPalette.groups.2.fields.7.label','null'),('formie.fieldPalette.groups.2.fields.8.enabled','true'),('formie.fieldPalette.groups.2.fields.8.fieldClass','\"verbb\\\\formie\\\\fields\\\\Payment\"'),('formie.fieldPalette.groups.2.fields.8.label','null'),('formie.fieldPalette.groups.2.handle','\"advanced\"'),('formie.fieldPalette.groups.2.name','\"Advanced Fields\"'),('formie.fieldPalette.groups.2.uid','\"6a1e0264-5202-4884-86c7-08b1944989e5\"'),('formie.fieldPalette.groups.3.fields.0.enabled','true'),('formie.fieldPalette.groups.3.fields.0.fieldClass','\"verbb\\\\formie\\\\fields\\\\Repeater\"'),('formie.fieldPalette.groups.3.fields.0.label','null'),('formie.fieldPalette.groups.3.fields.1.enabled','true'),('formie.fieldPalette.groups.3.fields.1.fieldClass','\"verbb\\\\formie\\\\fields\\\\Group\"'),('formie.fieldPalette.groups.3.fields.1.label','null'),('formie.fieldPalette.groups.3.fields.2.enabled','true'),('formie.fieldPalette.groups.3.fields.2.fieldClass','\"verbb\\\\formie\\\\fields\\\\Table\"'),('formie.fieldPalette.groups.3.fields.2.label','null'),('formie.fieldPalette.groups.3.handle','\"dynamic\"'),('formie.fieldPalette.groups.3.name','\"Dynamic Fields\"'),('formie.fieldPalette.groups.3.uid','\"78c0dae2-7fac-4113-9c32-ecead7595ef7\"'),('formie.fieldPalette.groups.4.fields.0.enabled','true'),('formie.fieldPalette.groups.4.fields.0.fieldClass','\"verbb\\\\formie\\\\fields\\\\Heading\"'),('formie.fieldPalette.groups.4.fields.0.label','null'),('formie.fieldPalette.groups.4.fields.1.enabled','true'),('formie.fieldPalette.groups.4.fields.1.fieldClass','\"verbb\\\\formie\\\\fields\\\\Section\"'),('formie.fieldPalette.groups.4.fields.1.label','null'),('formie.fieldPalette.groups.4.fields.2.enabled','true'),('formie.fieldPalette.groups.4.fields.2.fieldClass','\"verbb\\\\formie\\\\fields\\\\Html\"'),('formie.fieldPalette.groups.4.fields.2.label','null'),('formie.fieldPalette.groups.4.fields.3.enabled','true'),('formie.fieldPalette.groups.4.fields.3.fieldClass','\"verbb\\\\formie\\\\fields\\\\Content\"'),('formie.fieldPalette.groups.4.fields.3.label','null'),('formie.fieldPalette.groups.4.fields.4.enabled','true'),('formie.fieldPalette.groups.4.fields.4.fieldClass','\"verbb\\\\formie\\\\fields\\\\Note\"'),('formie.fieldPalette.groups.4.fields.4.label','null'),('formie.fieldPalette.groups.4.fields.5.enabled','true'),('formie.fieldPalette.groups.4.fields.5.fieldClass','\"verbb\\\\formie\\\\fields\\\\Summary\"'),('formie.fieldPalette.groups.4.fields.5.label','null'),('formie.fieldPalette.groups.4.handle','\"cosmetic\"'),('formie.fieldPalette.groups.4.name','\"Cosmetic Fields\"'),('formie.fieldPalette.groups.4.uid','\"2b0649b7-74a5-4e62-8860-55c5890253ca\"'),('formie.fieldPalette.groups.5.fields.0.enabled','true'),('formie.fieldPalette.groups.5.fields.0.fieldClass','\"verbb\\\\formie\\\\fields\\\\Entries\"'),('formie.fieldPalette.groups.5.fields.0.label','null'),('formie.fieldPalette.groups.5.fields.1.enabled','true'),('formie.fieldPalette.groups.5.fields.1.fieldClass','\"verbb\\\\formie\\\\fields\\\\Categories\"'),('formie.fieldPalette.groups.5.fields.1.label','null'),('formie.fieldPalette.groups.5.fields.2.enabled','true'),('formie.fieldPalette.groups.5.fields.2.fieldClass','\"verbb\\\\formie\\\\fields\\\\Tags\"'),('formie.fieldPalette.groups.5.fields.2.label','null'),('formie.fieldPalette.groups.5.handle','\"element\"'),('formie.fieldPalette.groups.5.name','\"Element Fields\"'),('formie.fieldPalette.groups.5.uid','\"d7066c10-8725-4a64-83d1-4bf254005a35\"'),('formie.fieldPalette.groups.6.fields.0.enabled','true'),('formie.fieldPalette.groups.6.fields.0.fieldClass','\"verbb\\\\formie\\\\fields\\\\CustomField\"'),('formie.fieldPalette.groups.6.fields.0.label','null'),('formie.fieldPalette.groups.6.handle','\"custom\"'),('formie.fieldPalette.groups.6.name','\"Custom Fields\"'),('formie.fieldPalette.groups.6.uid','\"63043294-a249-4c1a-89db-ce59f4ef0f2d\"'),('formie.fieldPalette.version','1'),('formie.formStatuses.2b0409e9-cb72-417d-b656-da63f03f9c04.color','\"grey\"'),('formie.formStatuses.2b0409e9-cb72-417d-b656-da63f03f9c04.description','null'),('formie.formStatuses.2b0409e9-cb72-417d-b656-da63f03f9c04.handle','\"archived\"'),('formie.formStatuses.2b0409e9-cb72-417d-b656-da63f03f9c04.isDefault','false'),('formie.formStatuses.2b0409e9-cb72-417d-b656-da63f03f9c04.name','\"Archived\"'),('formie.formStatuses.2b0409e9-cb72-417d-b656-da63f03f9c04.sortOrder','3'),('formie.formStatuses.4654273e-e095-4a0f-8fd7-f02f57a0174a.color','\"orange\"'),('formie.formStatuses.4654273e-e095-4a0f-8fd7-f02f57a0174a.description','null'),('formie.formStatuses.4654273e-e095-4a0f-8fd7-f02f57a0174a.handle','\"draft\"'),('formie.formStatuses.4654273e-e095-4a0f-8fd7-f02f57a0174a.isDefault','false'),('formie.formStatuses.4654273e-e095-4a0f-8fd7-f02f57a0174a.name','\"Draft\"'),('formie.formStatuses.4654273e-e095-4a0f-8fd7-f02f57a0174a.sortOrder','2'),('formie.formStatuses.614368ed-97b8-481a-a515-a102fb8f0537.color','\"turquoise\"'),('formie.formStatuses.614368ed-97b8-481a-a515-a102fb8f0537.description','null'),('formie.formStatuses.614368ed-97b8-481a-a515-a102fb8f0537.handle','\"active\"'),('formie.formStatuses.614368ed-97b8-481a-a515-a102fb8f0537.isDefault','true'),('formie.formStatuses.614368ed-97b8-481a-a515-a102fb8f0537.name','\"Active\"'),('formie.formStatuses.614368ed-97b8-481a-a515-a102fb8f0537.sortOrder','1'),('formie.statuses.6d6dea9a-13d2-4658-88d5-2520c9474ad6.color','\"turquoise\"'),('formie.statuses.6d6dea9a-13d2-4658-88d5-2520c9474ad6.description','null'),('formie.statuses.6d6dea9a-13d2-4658-88d5-2520c9474ad6.handle','\"new\"'),('formie.statuses.6d6dea9a-13d2-4658-88d5-2520c9474ad6.isDefault','true'),('formie.statuses.6d6dea9a-13d2-4658-88d5-2520c9474ad6.name','\"New\"'),('formie.statuses.6d6dea9a-13d2-4658-88d5-2520c9474ad6.sortOrder','1'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.0','\"data\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.0.0','\"dataRetention\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.0.1','\"forever\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.2.0','\"fileUploadsAction\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.2.1','\"retain\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.0','\"settings\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.0.0','\"collectIp\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.0.1','false'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.1.0','\"collectUser\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.1.1','false'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.10.0','\"displayPageProgress\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.10.1','false'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.11.0','\"displayPageTabs\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.11.1','false'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.12.0','\"errorMessage\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.12.1.0.__assoc__.0.0','\"content\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.12.1.0.__assoc__.0.1.0.__assoc__.0.0','\"text\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.12.1.0.__assoc__.0.1.0.__assoc__.0.1','\"Couldn’t save submission due to errors.\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.12.1.0.__assoc__.0.1.0.__assoc__.1.0','\"type\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.12.1.0.__assoc__.0.1.0.__assoc__.1.1','\"text\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.12.1.0.__assoc__.1.0','\"type\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.12.1.0.__assoc__.1.1','\"paragraph\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.13.0','\"errorMessagePosition\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.13.1','\"top-form\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.19.0','\"limitSubmissionsType\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.19.1','\"total\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.23.0','\"progressCalculation\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.23.1','\"completion\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.24.0','\"progressPosition\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.24.1','\"end\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.25.0','\"progressValuePosition\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.25.1','\"inside-center\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.27.0','\"requireUser\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.27.1','false'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.28.0','\"requiredIndicator\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.28.1','\"asterisk\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.29.0','\"scheduleForm\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.29.1','false'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.32.0','\"scrollToTop\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.32.1','true'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.33.0','\"submissionTitleFormat\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.33.1','\"{timestamp}\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.34.0','\"submitMethod\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.34.1','\"page-reload\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.35.0','\"validationOnFocus\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.35.1','false'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.36.0','\"validationOnSubmit\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.36.1','true'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.37.0','\"redirectTarget\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.37.1','\"same-tab\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.38.0','\"hideFormAfterSubmit\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.38.1','false'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.39.0','\"successMessage\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.39.1.0.__assoc__.0.0','\"content\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.39.1.0.__assoc__.0.1.0.__assoc__.0.0','\"text\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.39.1.0.__assoc__.0.1.0.__assoc__.0.1','\"Submission saved.\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.39.1.0.__assoc__.0.1.0.__assoc__.1.0','\"type\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.39.1.0.__assoc__.0.1.0.__assoc__.1.1','\"text\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.39.1.0.__assoc__.1.0','\"type\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.39.1.0.__assoc__.1.1','\"paragraph\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.41.0','\"successMessagePosition\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.41.1','\"top-form\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.42.0','\"completionBehavior\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.42.1','\"message\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.43.0','\"completionRedirectSource\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.43.1','\"url\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.5.0','\"defaultInstructionsPosition\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.5.1','\"verbb\\\\formie\\\\positions\\\\AboveInput\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.6.0','\"defaultLabelPosition\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.6.1','\"verbb\\\\formie\\\\positions\\\\AboveInput\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.7.0','\"disableCaptchas\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.7.1','false'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.8.0','\"displayCurrentPageTitle\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.8.1','false'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.9.0','\"displayFormTitle\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.3.1.__assoc__.9.1','false'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.4.0','\"userDeletedAction\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.0.1.__assoc__.4.1','\"retain\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.1.0','\"defaultStatus\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.1.1','\"6d6dea9a-13d2-4658-88d5-2520c9474ad6\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.2.0','\"handle\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.2.1','\"contactForm\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.3.0','\"name\"'),('formie.stencils.06a70224-206c-457a-a344-4dbae44cce17.__assoc__.3.1','\"Contact Form\"'),('graphql.publicToken.enabled','true'),('graphql.publicToken.expiryDate','null'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.isPublic','true'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.name','\"Public Schema\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.0','\"sites.dabb80e6-8dc1-4d79-838f-e45c676d1db3:read\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.1','\"elements.drafts:read\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.10','\"formieSubmissions.c5c26b24-57c5-4f36-817d-07c3bdbc01ee:read\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.11','\"formieSubmissions.8aa2ad87-56bc-443a-aeb7-3dba0c5bc492:read\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.12','\"formieSubmissions.16d2b0bf-0d0d-4831-b4a8-9c97b5a17061:read\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.13','\"formieSubmissions.all:edit\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.14','\"formieSubmissions.all:create\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.15','\"formieSubmissions.all:save\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.16','\"formieSubmissions.all:delete\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.17','\"formieSubmissions.c5c26b24-57c5-4f36-817d-07c3bdbc01ee:edit\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.18','\"formieSubmissions.c5c26b24-57c5-4f36-817d-07c3bdbc01ee:create\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.19','\"formieSubmissions.c5c26b24-57c5-4f36-817d-07c3bdbc01ee:save\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.2','\"elements.revisions:read\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.20','\"formieSubmissions.c5c26b24-57c5-4f36-817d-07c3bdbc01ee:delete\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.21','\"formieSubmissions.8aa2ad87-56bc-443a-aeb7-3dba0c5bc492:edit\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.22','\"formieSubmissions.8aa2ad87-56bc-443a-aeb7-3dba0c5bc492:create\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.23','\"formieSubmissions.8aa2ad87-56bc-443a-aeb7-3dba0c5bc492:save\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.24','\"formieSubmissions.8aa2ad87-56bc-443a-aeb7-3dba0c5bc492:delete\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.25','\"formieSubmissions.16d2b0bf-0d0d-4831-b4a8-9c97b5a17061:edit\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.26','\"formieSubmissions.16d2b0bf-0d0d-4831-b4a8-9c97b5a17061:create\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.27','\"formieSubmissions.16d2b0bf-0d0d-4831-b4a8-9c97b5a17061:save\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.28','\"formieSubmissions.16d2b0bf-0d0d-4831-b4a8-9c97b5a17061:delete\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.3','\"elements.inactive:read\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.4','\"usergroups.solo:read\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.5','\"formieForms.all:read\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.6','\"formieForms.c5c26b24-57c5-4f36-817d-07c3bdbc01ee:read\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.7','\"formieForms.8aa2ad87-56bc-443a-aeb7-3dba0c5bc492:read\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.8','\"formieForms.16d2b0bf-0d0d-4831-b4a8-9c97b5a17061:read\"'),('graphql.schemas.a6061a32-15c1-408a-8e4d-47f0af858dfc.scope.9','\"formieSubmissions.all:read\"'),('meta.__names__.2b0409e9-cb72-417d-b656-da63f03f9c04','\"Archived\"'),('meta.__names__.4654273e-e095-4a0f-8fd7-f02f57a0174a','\"Draft\"'),('meta.__names__.614368ed-97b8-481a-a515-a102fb8f0537','\"Active\"'),('meta.__names__.6d6dea9a-13d2-4658-88d5-2520c9474ad6','\"New\"'),('meta.__names__.a6061a32-15c1-408a-8e4d-47f0af858dfc','\"Public Schema\"'),('meta.__names__.dabb80e6-8dc1-4d79-838f-e45c676d1db3','\"Formie Starters\"'),('meta.__names__.e46fecf3-996b-4205-b776-e11ebaa738d6','\"Formie Starters\"'),('plugins.datastar.edition','\"standard\"'),('plugins.datastar.enabled','true'),('plugins.datastar.schemaVersion','\"1.0.0\"'),('plugins.formie.edition','\"standard\"'),('plugins.formie.enabled','true'),('plugins.formie.licenseKey','\"RQQH7631BOOKHSEA4T2UA2UH\"'),('plugins.formie.schemaVersion','\"4.0.80\"'),('plugins.formie.settings.ajaxTimeout','10'),('plugins.formie.settings.alertEmails','null'),('plugins.formie.settings.alertEmailsUserGroup','null'),('plugins.formie.settings.allowedOrigins.0','\"http://localhost:3001\"'),('plugins.formie.settings.allowedOrigins.1','\"http://127.0.0.1:3001\"'),('plugins.formie.settings.allowedOrigins.10','\"http://localhost:5173\"'),('plugins.formie.settings.allowedOrigins.11','\"http://127.0.0.1:5173\"'),('plugins.formie.settings.allowedOrigins.12','\"http://localhost:5174\"'),('plugins.formie.settings.allowedOrigins.13','\"http://127.0.0.1:5174\"'),('plugins.formie.settings.allowedOrigins.14','\"http://localhost:5175\"'),('plugins.formie.settings.allowedOrigins.15','\"http://127.0.0.1:5175\"'),('plugins.formie.settings.allowedOrigins.2','\"http://localhost:3002\"'),('plugins.formie.settings.allowedOrigins.3','\"http://127.0.0.1:3002\"'),('plugins.formie.settings.allowedOrigins.4','\"http://localhost:4173\"'),('plugins.formie.settings.allowedOrigins.5','\"http://127.0.0.1:4173\"'),('plugins.formie.settings.allowedOrigins.6','\"http://localhost:4174\"'),('plugins.formie.settings.allowedOrigins.7','\"http://127.0.0.1:4174\"'),('plugins.formie.settings.allowedOrigins.8','\"http://localhost:4175\"'),('plugins.formie.settings.allowedOrigins.9','\"http://127.0.0.1:4175\"'),('plugins.formie.settings.allowedSubmitMethods','\"both\"'),('plugins.formie.settings.allowLegacySignatureImageUrls','true'),('plugins.formie.settings.allowMultiSelectDropdowns','true'),('plugins.formie.settings.allowPhoneCountrySelector','true'),('plugins.formie.settings.allowPublicVolumes','true'),('plugins.formie.settings.anonymousClientBootstrapRateLimit','30'),('plugins.formie.settings.anonymousClientRateWindowSeconds','60'),('plugins.formie.settings.anonymousClientRefreshRateLimit','120'),('plugins.formie.settings.compatibilityMode','true'),('plugins.formie.settings.completionQueryAllowlist.0','\"utm_source\"'),('plugins.formie.settings.completionQueryAllowlist.1','\"utm_medium\"'),('plugins.formie.settings.completionQueryAllowlist.2','\"utm_campaign\"'),('plugins.formie.settings.completionQueryAllowlist.3','\"utm_term\"'),('plugins.formie.settings.completionQueryAllowlist.4','\"utm_content\"'),('plugins.formie.settings.defaultCpSubmissionFieldConditions','\"follow\"'),('plugins.formie.settings.defaultEmailTemplate','\"\"'),('plugins.formie.settings.defaultErrorMessagePosition','\"verbb\\\\formie\\\\positions\\\\BelowInput\"'),('plugins.formie.settings.defaultExportFolder','\"@storage/formie-export\"'),('plugins.formie.settings.defaultFormStencil','\"\"'),('plugins.formie.settings.defaultFormTemplate','\"\"'),('plugins.formie.settings.defaultInstructionsPosition','\"verbb\\\\formie\\\\positions\\\\AboveInput\"'),('plugins.formie.settings.defaultLabelPosition','\"verbb\\\\formie\\\\positions\\\\AboveInput\"'),('plugins.formie.settings.defaultPage','\"forms\"'),('plugins.formie.settings.deliveryEvidenceRetentionDays','30'),('plugins.formie.settings.emptyValuePlaceholder','\"No response.\"'),('plugins.formie.settings.enableBackSubmission','true'),('plugins.formie.settings.enableCsrfValidationForGuests','true'),('plugins.formie.settings.enableLargeFieldStorage','false'),('plugins.formie.settings.enableMultiPageForms','true'),('plugins.formie.settings.enableUnloadWarning','true'),('plugins.formie.settings.encryptionKey','null'),('plugins.formie.settings.errorAriaLive','\"polite\"'),('plugins.formie.settings.filterIntegrationMapping','true'),('plugins.formie.settings.includeDraftElementUsage','false'),('plugins.formie.settings.includeFlatpickrCss','true'),('plugins.formie.settings.includeRevisionElementUsage','false'),('plugins.formie.settings.integrationAlertEmails','null'),('plugins.formie.settings.integrationAlertEmailsUserGroup','null'),('plugins.formie.settings.integrationApiErrorHandling.0.__assoc__.0.0','\"severity\"'),('plugins.formie.settings.integrationApiErrorHandling.0.__assoc__.0.1','\"rate_limited\"'),('plugins.formie.settings.integrationApiErrorHandling.0.__assoc__.1.0','\"action\"'),('plugins.formie.settings.integrationApiErrorHandling.0.__assoc__.1.1','\"logWarning\"'),('plugins.formie.settings.integrationApiErrorHandling.1.__assoc__.0.0','\"severity\"'),('plugins.formie.settings.integrationApiErrorHandling.1.__assoc__.0.1','\"rejected\"'),('plugins.formie.settings.integrationApiErrorHandling.1.__assoc__.1.0','\"action\"'),('plugins.formie.settings.integrationApiErrorHandling.1.__assoc__.1.1','\"logWarning\"'),('plugins.formie.settings.integrationApiErrorHandling.2.__assoc__.0.0','\"severity\"'),('plugins.formie.settings.integrationApiErrorHandling.2.__assoc__.0.1','\"failure\"'),('plugins.formie.settings.integrationApiErrorHandling.2.__assoc__.1.0','\"action\"'),('plugins.formie.settings.integrationApiErrorHandling.2.__assoc__.1.1','\"failQueue\"'),('plugins.formie.settings.maxEmailAttachmentSizeMb','15'),('plugins.formie.settings.maxIncompleteSubmissionAge','30'),('plugins.formie.settings.maxSentNotificationsAge','30'),('plugins.formie.settings.maxStagedUploadBytes','67108864'),('plugins.formie.settings.maxStagedUploadFiles','50'),('plugins.formie.settings.outputConsoleMessages','true'),('plugins.formie.settings.paymentWebhookProxyUrl','null'),('plugins.formie.settings.pdfPaperOrientation','\"portrait\"'),('plugins.formie.settings.pdfPaperSize','\"letter\"'),('plugins.formie.settings.plainTextHtmlSanitizationMode','\"preserve\"'),('plugins.formie.settings.pluginName','\"Formie\"'),('plugins.formie.settings.queuePriority','null'),('plugins.formie.settings.redirectUri','null'),('plugins.formie.settings.reportAsyncExportRowThreshold','1000'),('plugins.formie.settings.reportExportSingleUseDownload','true'),('plugins.formie.settings.reportInteractiveExportExpiryHours','72'),('plugins.formie.settings.reportScheduledExportExpiryHours','48'),('plugins.formie.settings.reportTablePageSize','100'),('plugins.formie.settings.saveResumeTokenTtlDays','14'),('plugins.formie.settings.sendEmailAlerts','false'),('plugins.formie.settings.sendIntegrationAlerts','false'),('plugins.formie.settings.sentNotifications','true'),('plugins.formie.settings.setOnlyCurrentPagePayload','false'),('plugins.formie.settings.staticCacheRefreshOnLoad','false'),('plugins.formie.settings.submissionsBehaviour','\"all\"'),('plugins.formie.settings.submissionSidebarFormOrder','\"dateCreatedDesc\"'),('plugins.formie.settings.submissionStateRetentionDays','30'),('plugins.formie.settings.useCssLayers','false'),('plugins.formie.settings.useQueueForIntegrations','true'),('plugins.formie.settings.useQueueForNotifications','true'),('plugins.formie.settings.validateCustomTemplates','true'),('plugins.sprig.edition','\"standard\"'),('plugins.sprig.enabled','true'),('plugins.sprig.schemaVersion','\"1.0.1\"'),('siteGroups.e46fecf3-996b-4205-b776-e11ebaa738d6.name','\"Formie Starters\"'),('sites.dabb80e6-8dc1-4d79-838f-e45c676d1db3.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.dabb80e6-8dc1-4d79-838f-e45c676d1db3.enabled','true'),('sites.dabb80e6-8dc1-4d79-838f-e45c676d1db3.handle','\"default\"'),('sites.dabb80e6-8dc1-4d79-838f-e45c676d1db3.hasUrls','true'),('sites.dabb80e6-8dc1-4d79-838f-e45c676d1db3.language','\"en\"'),('sites.dabb80e6-8dc1-4d79-838f-e45c676d1db3.name','\"Formie Starters\"'),('sites.dabb80e6-8dc1-4d79-838f-e45c676d1db3.primary','true'),('sites.dabb80e6-8dc1-4d79-838f-e45c676d1db3.siteGroup','\"e46fecf3-996b-4205-b776-e11ebaa738d6\"'),('sites.dabb80e6-8dc1-4d79-838f-e45c676d1db3.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Formie Starters\"'),('system.schemaVersion','\"5.11.0.2\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `idx_ajbjzgrprxzilromgznlruzonojmqugyxqyy` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_scbyfybebbbxxqjxazkxugtnxlovsadquiiq` (`channel`,`fail`,`timeUpdated`,`delay`),
  KEY `idx_yqnqvmljkaydbawphpqytvnlvlljanhwanrx` (`channel`,`fail`,`timeUpdated`,`priority`,`id`,`timePushed`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text COLLATE utf8mb4_unicode_520_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bdvknodwqaawiyywvebybinsibywtjqogpfk` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_klziwyilmnhrgnioonheohcsdbefhkiewpsj` (`sourceId`),
  KEY `idx_ovodcizzetokcrlbjcgiddaxwahklnixwzri` (`targetId`),
  KEY `idx_ujhshxttomtwpftmvwgvvfrkcftxgdhtvuuz` (`sourceSiteId`),
  CONSTRAINT `fk_jbdjbjwxkedsfxpwswbevstadlnzlixpeata` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_lvrmfxmhosbhopovstovgdlicsxpjpyhtqjw` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pujtgokqadafoqvunvchnjimoasdyaofidqr` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('30961b7c','@putyourlightson/datastar/resources/lib/datastar/1.0.0-RC.7');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ofymehwllftifaubaxyfxsfattjyzmljyavz` (`canonicalId`,`num`),
  KEY `fk_tdtukysacbziqpvomjpeibinbbxieyndbtwa` (`creatorId`),
  CONSTRAINT `fk_snhvbporqljpnacjymfxhjslsogivmbrfxkx` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tdtukysacbziqpvomjpeibinbbxieyndbtwa` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_hhqjympbtddqlqiosliziqrmfgsnukjidehp` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' web verbb io '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'handle',0,1,' singlepage '),(2,'slug',0,1,''),(2,'title',0,1,' single page '),(3,'handle',0,1,' multipage '),(3,'slug',0,1,''),(3,'title',0,1,' multi page '),(4,'handle',0,1,' advanced '),(4,'slug',0,1,''),(4,'title',0,1,' advanced '),(5,'slug',0,1,''),(5,'title',0,1,' 2026 06 02 04 29 29 ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindexqueue`
--

DROP TABLE IF EXISTS `searchindexqueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `reserved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_umprutmznimlteojpsdfyqqikivlskybepoz` (`elementId`,`siteId`,`reserved`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindexqueue`
--

LOCK TABLES `searchindexqueue` WRITE;
/*!40000 ALTER TABLE `searchindexqueue` DISABLE KEYS */;
/*!40000 ALTER TABLE `searchindexqueue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindexqueue_fields`
--

DROP TABLE IF EXISTS `searchindexqueue_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue_fields` (
  `jobId` int NOT NULL,
  `fieldHandle` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`jobId`,`fieldHandle`),
  UNIQUE KEY `idx_nusczdvedxxatjchqcvwonfeajmzeksgnxrn` (`jobId`,`fieldHandle`),
  CONSTRAINT `fk_nfapsnsexfoewpcekozpcvvyvuolkbbcfsri` FOREIGN KEY (`jobId`) REFERENCES `searchindexqueue` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindexqueue_fields`
--

LOCK TABLES `searchindexqueue_fields` WRITE;
/*!40000 ALTER TABLE `searchindexqueue_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `searchindexqueue_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` enum('single','channel','structure') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `minAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `maxAuthors` smallint unsigned DEFAULT NULL,
  `propagationMethod` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pfejbbegekfdixhdeenusbleseavedwbqhtk` (`handle`),
  KEY `idx_cqxbsconiytmceiktkggjgwabauknerqbygz` (`name`),
  KEY `idx_leuulxkgqghneipclxjuihvqextubivkxgqz` (`structureId`),
  KEY `idx_ntwgomponvkefsaxfrbtyajtbcxgclbpbkda` (`dateDeleted`),
  CONSTRAINT `fk_zpqjgkcjmcfffshooyzdmbqvreoirsmkkvbs` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_lbqxpldhxvgpcjzocmsselogcxszxlifiome` (`typeId`),
  CONSTRAINT `fk_efqsorcnwkjrkuknoyqwlbedosnraayzjjel` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lbqxpldhxvgpcjzocmsselogcxszxlifiome` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text COLLATE utf8mb4_unicode_520_ci,
  `template` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mbslwrwghillhsuanntqfjggzemjppqdosid` (`sectionId`,`siteId`),
  KEY `idx_ihphifubtrpyvjyxyjabmrjsvwguvexfztxv` (`siteId`),
  CONSTRAINT `fk_muovmdlccmtvyuhdwzffywbuczgohqtjxwxy` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wlszqmpijsdalulxhwezdzsukeqdawtbobgs` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gpunclwnfnnitgpstwxfcxztfrygsvjzfaqz` (`uid`),
  KEY `idx_iackiphdsrarobddoebpczrjxnbixybksfmu` (`token`),
  KEY `idx_tsseqbjqwdxhbvbioqjmgjppysdtzcwvyyqa` (`dateUpdated`),
  KEY `idx_sdeiostmdkhwowktmlqyaxktchsdqfafwnqw` (`userId`),
  CONSTRAINT `fk_tokkqkqaijivkcswkwppetbmoudhixoxxcgp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_owvgtmypkgsqmyktjhkgmkkxcgtobynpgzoo` (`userId`,`message`),
  CONSTRAINT `fk_sziltoxsmuaetbuqwmbaniaervrzjxujucpy` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_awmdjupntnmouetkppxybshsvsvtyxxmviov` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Formie Starters','2026-06-02 11:28:28','2026-06-02 11:28:28',NULL,'e46fecf3-996b-4205-b776-e11ebaa738d6');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'true',
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `language` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vcizjkmrbrewtkbxiogeevopahofxuomlrtw` (`dateDeleted`),
  KEY `idx_gjslcohxibulgjkgcdgedzuvhjlgcgguaztd` (`handle`),
  KEY `idx_owrwshoqsuyngjhnpocmsbvhdwdlsjwshqmq` (`sortOrder`),
  KEY `fk_hwfijlpjzuaxmfekufkfcduffrdvyxlwopsb` (`groupId`),
  CONSTRAINT `fk_hwfijlpjzuaxmfekufkfcduffrdvyxlwopsb` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'1','Formie Starters','default','en',1,'$PRIMARY_SITE_URL',1,'2026-06-02 11:28:28','2026-06-02 11:28:30',NULL,'dabb80e6-8dc1-4d79-838f-e45c676d1db3');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sprig_playgrounds`
--

DROP TABLE IF EXISTS `sprig_playgrounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sprig_playgrounds` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `component` text COLLATE utf8mb4_unicode_520_ci,
  `variables` text COLLATE utf8mb4_unicode_520_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sprig_playgrounds`
--

LOCK TABLES `sprig_playgrounds` WRITE;
/*!40000 ALTER TABLE `sprig_playgrounds` DISABLE KEYS */;
/*!40000 ALTER TABLE `sprig_playgrounds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `identityId` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `fk_drsnvxkcqobmpjsnpvknbziqiuejntyypnsd` (`userId`),
  CONSTRAINT `fk_drsnvxkcqobmpjsnpvknbziqiuejntyypnsd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hlubaaoqloljweaxjuoouulpojjcjzgpzvxa` (`structureId`,`elementId`),
  KEY `idx_ipafzvzuejpenrkzezxxucfraoiibsgsngwz` (`root`),
  KEY `idx_verkavhyrrqkuitepbotqflrdimktpevlcrq` (`lft`),
  KEY `idx_wuwabppukjzixaimliqhcsgrhpoptvejitwb` (`rgt`),
  KEY `idx_jwdajwthoacardhqtqchwnjvewasjjqcdxyo` (`level`),
  KEY `idx_mvpcaztsknjnkvezfguxdqpvkrkbztphkaxk` (`elementId`),
  CONSTRAINT `fk_ilfrvgvomwzapcuzgbabwmpaddjdtvnmziul` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xainanpeqhxvcrjogxbuzkbwxqexzxupvxuk` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `subject` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lgidiwpaitjkrlymvymdrtllftjfzrnjreri` (`key`,`language`),
  KEY `idx_ajpwwrobnrmhihohggunsnfbixlqeazjawvv` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sruvqavezuvcozfilcrwvbveuhkpmzpfwybr` (`name`),
  KEY `idx_ajzdcposhvspqymcypyrnpyjywunxwcxfrxg` (`handle`),
  KEY `idx_ookdlkniyfexoxbeaedrttgdbysqmemkfktp` (`dateDeleted`),
  KEY `fk_zzdmnihsxaoinzruatrbujpgvrrmslnpwnra` (`fieldLayoutId`),
  CONSTRAINT `fk_zzdmnihsxaoinzruatrbujpgvrrmslnpwnra` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qadqaigrswqzlpmjdmnykgssqgaeyhvvhoud` (`groupId`),
  CONSTRAINT `fk_kiszdqthpvyitwxdzyjhjyareidrwxphjgia` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lcllbmlwsndmbmokduxyfbrohxcxtnuttgrb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `route` text COLLATE utf8mb4_unicode_520_ci,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kiyhotnynxezbhbjgfbwwwwmwfdnbsiaytxj` (`token`),
  KEY `idx_mauhbvjoljctxzgkehzovmzvpshinnrkhuth` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_520_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xivhholxoiqxssilcneulgqyagpsipjdpetk` (`handle`),
  KEY `idx_nyvssdpgfrerdxbzrebnfoatnrlsdomslugo` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_weverbrqvpikiraqxyroralitlgwufgodhhm` (`groupId`,`userId`),
  KEY `idx_hlsxflyiivkezmgjjgsvshhdergvludtcygk` (`userId`),
  CONSTRAINT `fk_dtdbtzktwkbzwphbfmzpcdiuwruwphrfhavq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_evlmjauvtikwbufibbuyidlztasezlqixrcg` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rkccbyngsgardrnsxjdfebqfupzkilmbjguy` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
INSERT INTO `userpermissions` VALUES (1,'formie-accessstencils','2026-10-13 20:13:06','2026-10-13 20:13:06','82fa28ce-a749-4461-8ecd-3da10dea53d0'),(2,'formie-accessintegrations','2026-10-13 20:13:09','2026-10-13 20:13:09','db5439e2-07df-4bfa-82bc-aab70cbc1834'),(3,'formie-accessreports','2026-10-13 20:13:10','2026-10-13 20:13:10','5edcf6fc-ab1f-4920-af5c-4d4d9b5981cb'),(4,'formie-exportsubmissions','2026-10-13 20:13:10','2026-10-13 20:13:10','f978b66b-1c1b-46c6-96df-e030d2239da4'),(5,'formie-settingsspamprotection','2026-10-13 20:13:15','2026-10-13 20:13:15','b5af25fe-8e48-482c-b43e-7ea68c7d6360');
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vxultvzgdlwnnfjopxkxbtpddarpxdpjijiz` (`permissionId`,`groupId`),
  KEY `idx_lafxpgxaxqyvttiuitbsmhyytglpjqpgucfd` (`groupId`),
  CONSTRAINT `fk_wjcygornptpfbcvhsdunjzaygluecfebslgg` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xlgbfqymtjecicnucacukkxmfngygjkrbodp` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_whbiumakemhzbjnkrojcjykafyiwyoqumobl` (`permissionId`,`userId`),
  KEY `idx_ckoooaniruwnddpgwrzibrspkssiykcqpzwk` (`userId`),
  CONSTRAINT `fk_nbxjyqviuhzspctltxyxrguqquhrhievklcp` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pwfrkyvopptruswnselinnptziueuwswonzh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_uclmnujitaxnzpbvoyrnuncryjaplivqnops` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `affiliatedSiteId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `fullName` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_xpquernikribmsgeligwgcdvkdfbhmkhfyvl` (`active`),
  KEY `idx_qphgchcikfvlxgllvkuqkwmcxofzqlgrprfm` (`locked`),
  KEY `idx_geqjmhmasxzzpfritselktjwflbmxyugfiew` (`pending`),
  KEY `idx_lxmtqwkrvfmhyjvgpzyyairrrzdeqvhohfmf` (`suspended`),
  KEY `idx_gtzzugybgmafoffnkuqedfndyqfmyaucbkxz` (`verificationCode`),
  KEY `idx_eeabapmwvzhxgvbaxpwzcwpstggvxtlflktp` (`email`),
  KEY `idx_xkzrfrleqoagewsxqvlosyrutzxxdvruckwd` (`username`),
  KEY `fk_caexhlzeixxflvdauncurldpuavcmoykcuui` (`photoId`),
  KEY `fk_dpfmcdynjqmgrexnxmieyszqegjdascclgmq` (`affiliatedSiteId`),
  CONSTRAINT `fk_caexhlzeixxflvdauncurldpuavcmoykcuui` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_dpfmcdynjqmgrexnxmieyszqegjdascclgmq` FOREIGN KEY (`affiliatedSiteId`) REFERENCES `sites` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_oexusgmusjqkhsaiuajgkabhjpnhifupysaa` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'web@verbb.io','$2y$13$M1spxhM3AitGtNBSRTMDj.y9AD/KqM2BSLVNl26lO4EJ5JqAezmUC','2026-06-02 11:29:10',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2026-06-02 11:28:31','2026-06-02 11:28:31','2026-06-02 11:29:10');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_frpklinavqxxzmuvlsjehdigetphbnerjdav` (`name`,`parentId`,`volumeId`),
  KEY `idx_otrskwjrknlugwxdsabjgnhseycsigboonsp` (`parentId`),
  KEY `idx_oerknslhokpmdyhmrxervwpavtzutheamxaz` (`volumeId`),
  CONSTRAINT `fk_lzeddjgijvbajbtsorqjvxrvvsgtajeniwuo` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qvnfrogawmyilaeyapobivwhgetzhyixpueq` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,NULL,'Temporary Uploads',NULL,'2026-06-02 11:29:36','2026-06-02 11:29:36','c9f5a0c3-e044-4324-bbf0-d9344806d078'),(2,1,NULL,'user_1','user_1/','2026-06-02 11:29:36','2026-06-02 11:29:36','b6b78474-cb5d-4167-b4ea-473b9d56a57d');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `fs` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `subpath` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transformFs` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transformSubpath` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `titleTranslationMethod` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text COLLATE utf8mb4_unicode_520_ci,
  `altTranslationMethod` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text COLLATE utf8mb4_unicode_520_ci,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rtgmpztyihmqbbkzkoaowkscpueoneazxrym` (`name`),
  KEY `idx_xngbwmfpoamckzjdgpfmfzhwhdcfuixbimrv` (`handle`),
  KEY `idx_nutzmsyiojymltikbdgudyeeotcabllwgkdi` (`fieldLayoutId`),
  KEY `idx_iuxnafhjdqaiohviasilbdmjutlkztlhsmpo` (`dateDeleted`),
  CONSTRAINT `fk_benpigorgotvkxhfabbkvqgskifrcnzorjyl` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `credential` text COLLATE utf8mb4_unicode_520_ci,
  `credentialName` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_xhjgsetbxgzwrbeyxkrrjgzyplnzbqrbximv` (`userId`),
  CONSTRAINT `fk_xhjgsetbxgzwrbeyxkrrjgzyplnzbqrbximv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sphovhxntnwyjfdvpetvnikwujdmharveivh` (`userId`),
  CONSTRAINT `fk_kvjkaayoqsamdouuzqhucteucfdocdqhuumh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}','2026-06-02 11:29:10','2026-06-02 11:29:10','32d4af7a-975f-4711-acf9-430cf0c6a24c'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]','2026-06-02 11:29:10','2026-06-02 11:29:10','39abdd5e-1dc0-4535-ab32-d17f84f64f39'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]','2026-06-02 11:29:10','2026-06-02 11:29:10','67c54ad0-930e-4ed2-8e3f-64059b9ce219'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}','2026-06-02 11:29:10','2026-06-02 11:29:10','73019a90-6c6a-41e8-9efe-33aa44b97acc');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-14  7:52:07
